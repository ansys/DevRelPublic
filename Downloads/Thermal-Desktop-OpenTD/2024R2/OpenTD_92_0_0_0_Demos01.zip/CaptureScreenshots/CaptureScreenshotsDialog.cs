// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using OpenTD;

namespace OpenTDDemos
{
    public partial class CaptureScreenshotsDialog : Form
    {
        public CaptureScreenshotsDialog()
        {
            InitializeComponent();
        }

        private string Output { set { toolStripStatusLabel1.Text = value; } }

        private ThermalDesktop td;
        
        private void OpenButton_Click(object sender, EventArgs e)
        {
            OpenButton.Enabled = false;
            string dwg = @"captureScreenshotsDemo.dwg";
            string dwgPathname = Path.Combine(Script.WorkingDirectory, dwg);
            if (!File.Exists(dwgPathname))
            {
                Output = "Could not find " + dwg + " in directory " + Script.WorkingDirectory;
                return;
            }

            td = new ThermalDesktop(dwgPathname);
            td.Connect();
        }

        private void GetNextScreenshotButton_Click(object sender, EventArgs e)
        {
            string view = GetNextView();
            td.RestoreView(view);
            Bitmap bmp = td.CaptureGraphicsArea();
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.Image = bmp;
            ViewnameLabel.Text = view;
        }

        private List<string> views = new List<string>
            {
                "demo_arrays",
                "demo_isoTop",
                "demo_radiator"
            };
        private int viewIndex = 0; 
        private string GetNextView()
        {
            if (viewIndex >= views.Count)
                viewIndex = 0;
            return views[viewIndex++];
        }

        private void CaptureScreenshotsDialog_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (td != null)
                try { td.Quit(); } catch { }
        }
    }
}
