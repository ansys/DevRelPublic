// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using OpenTD;

namespace OpenTDDemos
{
    public class CaptureScreenshots : Script
    {
        public override string GetName()
        {
            return "Screenshot capture";
        }
        public override string GetDescription()
        {
            return "Create pics of model at various angles";
        }
        public override string GetKeywords()
        {
            return "postprocessing post-processing view bmp png bitmap picture";
        }

        public override void Run()
        {
            CaptureScreenshotsDialog d = new CaptureScreenshotsDialog();
            d.ShowDialog();
        }
    }
}
