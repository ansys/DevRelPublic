// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using OpenTD;
using OpenTD.FloCAD;
using OpenTD.RadCAD;
using OpenTD.RadCAD.FdSolid;

namespace OpenTDDemos
{
    public class Comprehensive : Script
    {
        public override string GetName()
        {
            return "Comprehensive";
        }
        public override string GetDescription()
        {
            return "Demonstrates several OpenTD features";
        }
        public override string GetKeywords()
        {
            return "nodes conductors sinda cases casesets symbols autocad variables layers fem solids fd finite difference"
                + " create delete submodel units text notes radiation analysis group user code array logic objects"
                + " correspondance thermophysical material optical property properties stack merge clone get set"
                + " thermal desktop filter heat load heatload heater fluid rename delete lumps ports paths cappmps"
                + " ties fties ifaces lines pipes handles rectangles meshfd contactors tecs ortho visual style quit save"
                + " measures";
        }

        public override void Run()
        {
            Console.WriteLine("Trying to connect to TD...");
            ThermalDesktop td = new ThermalDesktop();
            td.Connect();
            Console.WriteLine(String.Format("Connected to TD at address {0}.", td.ConnectConfig.PipeEndpointNameUsed));

            // Uncomment to run a case:
            //Node node1 = td.CreateNode();
            //Node node2 = td.CreateNode();
            //node1.NodeType = Node.NodeTypes.BOUNDARY;
            //node1.Submodel = "MAIN";
            //node1.Id = 1;
            //node2.Submodel = "MAIN";
            //node2.Id = 2;
            //node1.Update();
            //node2.Update();
            //Conductor cond1 = td.CreateConductor();
            //cond1.FromHandles.Add(node1.Handle);
            //cond1.ToHandles.Add(node2.Handle);
            //cond1.Update();
            //CaseSet aCase = td.CreateCaseSet();
            //aCase.Name = "aCase";
            //td.SetCaseSet(aCase);
            //td.RunCaseSet("aCase");
            //return;

            td.Print("Printing a message to the TD commandline\n");

            Console.WriteLine("Calling GetAutocadVariable...");
            int filedia;
            td.GetAutocadVariable("filedia", out filedia);
            Console.WriteLine("  FILEDIA = " + filedia);
            double cdate;
            td.GetAutocadVariable("cdate", out cdate);
            Console.WriteLine("  CDATE = " + cdate);
            string acadver;
            td.GetAutocadVariable("acadver", out acadver);
            Console.WriteLine("  ACADVER = " + acadver);
            string clayer;
            td.GetAutocadVariable("clayer", out clayer);
            Console.WriteLine("  CLAYER = " + clayer);

            Console.WriteLine("Calling SetAutocadVariable...");
            td.SetAutocadVariable("filedia", 0);

            Console.WriteLine("Creating layers...");
            for (int i = 1; i <= 10; i++)
            {
                Layer layer = td.CreateLayer("Layer " + i);
                layer.Off = true;
                layer.Update();
            }

            Console.WriteLine("Calling GetLayers...");
            List<Layer> someLayers = td.GetLayers();
            foreach (Layer aLayer in someLayers)
            {
                Console.WriteLine("  " + aLayer);
            }

            Console.WriteLine("Calling DeleteLayer...");
            td.DeleteLayer(someLayers[someLayers.Count - 1].Name);

            Console.WriteLine("Calling CreateSubmodel...");
            td.CreateSubmodel("deleteMe");
            td.CreateSubmodel("dontDeleteMe");

            Console.WriteLine("Calling DeleteSubmodel...");
            td.DeleteSubmodel("DeLeTeMe");

            Console.WriteLine("Calling GetSubmodels...");
            foreach (Submodel aSubmodel in td.GetSubmodels())
                Console.WriteLine("  " + aSubmodel);

            Console.WriteLine("Setting units...");
            Units.WorkingUnits.temp = UnitsData.Temp.C;
            Units.WorkingUnits.modelLength = UnitsData.ModelLength.CM;
            Units.WorkingUnits.mass = UnitsData.Mass.KG;
            Units.WorkingUnits.energy = UnitsData.Energy.KJ;

            Console.WriteLine("Creating Text...");
            Text tdText = td.CreateText("CreateText output");
            tdText.Origin = new Point3d(0, -5, 0);
            tdText.UseBackgroundMask = 0;
            string textLayer = "text layer";
            td.CreateLayer(textLayer);
            tdText.Layer = textLayer;
            tdText.Text += " -- updated.";
            tdText.Update();

            Console.WriteLine("Calling GetTexts...");
            foreach (Text aTdText in td.GetTexts())
                Console.WriteLine("  '" + aTdText + "'");

            Console.WriteLine("Editing notes...");
            Notes notes = td.GetNotes();
            notes.Titles.Add("Note 0 Title");
            notes.Texts.Add("Note 0 Line 1\nNote 0 Line 2");
            notes.Passwords.Add("");
            notes.Titles.Add("Note 1 Title");
            notes.Texts.Add("Note 1 Line 1\nNote 1 Line 2");
            notes.Passwords.Add("password");
            notes.Update();

            Console.WriteLine("Editing notes again, with incorrect password for one note...");
            notes.Clear();
            notes.Titles.Add("Note 0 Title - Modified");
            notes.Texts.Add("Note 0 - Modified\nLine 2");
            notes.Passwords.Add("");
            notes.Titles.Add("Note 1 Title - Modified");
            notes.Texts.Add("Note 1 - Modified\nLine 2");
            notes.Passwords.Add("incorrect");
            notes.Titles.Add("Note 2 Title");
            notes.Texts.Add("Note 2\nLine 2");
            notes.Passwords.Add("");
            try
            {
                notes.Update();
            }
            catch (OpenTDException ex)
            {
                Console.WriteLine("  There was a problem: " + ex.Message);
            }

            Console.WriteLine("Getting and printing notes...");
            Notes someNotes = td.GetNotes();
            Console.WriteLine(someNotes.ToString());

            Console.WriteLine("Calling CreateSubmodel...");
            td.CreateSubmodel("testthermalsubmodel");

            Console.WriteLine("Calling RenameSubmodel...");
            var submodel = td.CreateSubmodel("RenameMe");
            submodel.Rename("renamed");

            Console.WriteLine("Calling GetSubmodels...");
            foreach (Submodel aSubmodel in td.GetSubmodels())
                Console.WriteLine("  " + aSubmodel);

            Console.WriteLine("Adding radiation analysis group...");
            td.RadiationAnalysisGroupManager.CreateOrUpdate("rad1", "test group named rad1\nline2\nline3");
            td.RadiationAnalysisGroupManager.CreateOrUpdate("rad1", "new comment\nnew line 2");

            Console.WriteLine("Get the radiation analysis groups...");
            foreach (Tuple<string, string> item in td.RadiationAnalysisGroupManager.GetRadiationGroups())
                Console.WriteLine(string.Format("  {0} -- {1}", item.Item1, item.Item2));

            Console.WriteLine("Get single radiation analysis group...");
            Tuple<string, string> rad1 = td.RadiationAnalysisGroupManager.GetRadiationGroup("rad1");

            Console.WriteLine("Set default radiation analysis group...");
            td.RadiationAnalysisGroupManager.CreateOrUpdate("shouldbedefault");
            td.RadiationAnalysisGroupManager.SetDefault("shouldbedefault");

            Console.WriteLine("Creating symbols...");
            Symbol radius = td.CreateSymbol("radius", "18");
            radius.Description = "hobbit hole door radius, inches";
            radius.Group = "hobbit_hole_door";
            radius.Update();
            Symbol dia = td.CreateSymbol("diameter", "2 * radius");
            dia.Group = "hobbit_hole_door";
            dia.Update();
            Symbol registerAsSymbol = td.CreateSymbol("timeplus1000", "TIMEN + 1000");
            registerAsSymbol.CheckConsistentUnitsUse = false;
            registerAsSymbol.OutputAsRegister = true;
            registerAsSymbol.Output = Symbol.OutputType.EXPRESSION;
            registerAsSymbol.DisableWarnings = true;
            registerAsSymbol.Update();

            Console.WriteLine("Calling GetSymbols...");
            List<Symbol> symbols = td.GetSymbols();
            foreach (Symbol s in symbols)
            {
                Console.WriteLine(String.Format("  name = {0}, value = {1}", s.Name, s.Value));
            }

            Console.WriteLine("Calling GetSymbol...");
            Symbol timeplus1000 = td.GetSymbol("timeplus1000");
            if (timeplus1000 != null)
                Console.WriteLine("   Success.");

            Console.WriteLine("Calling RenameSymbol...");
            timeplus1000.Rename("timeplus1000renamed");

            Console.WriteLine("Calling DeleteSymbol...");
            td.DeleteSymbol("diameter");

            Console.WriteLine("Creating UserCode...");
            UserCode userCode = td.CreateUserCode();
            userCode.Submodel = "main";
            userCode.Comment = "SINDA code";
            userCode.Code = "c first line\nc second line";
            userCode.Declarations = "c first line\nc second line";
            userCode.Routine = LogicObjectRoutineTypes.OPERATIONS;
            userCode.Update();

            Console.WriteLine("Creating UserArray...");
            UserArray userArray = td.CreateUserArray("main", 100, new List<double> { 0, 0 });
            userArray.Comment = "a SINDA array";
            userArray.ArrayType = UserArray.ArrayTypes.DOUBLET;
            userArray.DoubletArrayUnitsTypeX = UnitsData.UnitsType.TIME;
            userArray.DoubletArrayUnitsTypeY = UnitsData.UnitsType.TEMP;
            userArray.DoubletArrayXExp.expression = new List<string> { "0+0", "1+1", "2+2" };
            userArray.DoubletArrayXExp.disableWarning = 1;
            userArray.DoubletArrayXExp.outputToSinda = 1;
            userArray.DoubletArrayYExp.expression = new List<string> { "10+10", "11+11", "12+12" };
            userArray.DoubletArrayYExp.disableWarning = 0; // this will be superceded by the value for DoubletArrayXExp
            userArray.DoubletArrayYExp.outputToSinda = 0; // this will be superceded by the value for DoubletArrayXExp
            userArray.SingletArray_SI = new ListSI { 4, 5, 6 };
            userArray.UseDataMultColumn0 = 1;
            userArray.DataMultColumn0 = "#DATA * 2";
            userArray.Update();

            Console.WriteLine("Deleting Logic Objects...");
            UserCode userCodeDelete = td.CreateUserCode();
            td.DeleteLogicObject(userCodeDelete.Handle);
            UserArray userArrayDelete = td.CreateUserArray("main", 1, new List<double> { 0, 0 });
            td.DeleteLogicObject(userArrayDelete.Handle);

            Console.WriteLine("Calling OpenOpticalPropDB...");
            string opticalPropsDBPath = System.IO.Path.Combine(WorkingDirectory, "opentd_test.rco");
            System.IO.File.Delete(opticalPropsDBPath);
            td.OpenOpticalPropDB(opticalPropsDBPath);

            Console.WriteLine("Calling OpenThermoPropDB...");
            string thermoPropsDBPath = System.IO.Path.Combine(WorkingDirectory, "opentd_test.tdp");
            System.IO.File.Delete(thermoPropsDBPath);
            td.OpenThermoPropDB(thermoPropsDBPath);

            Console.WriteLine("Creating ThermoProps...");
            ThermoProps thermoProps = td.CreateThermoProps("test_material");
            thermoProps.SpecificHeat = 1.0;
            thermoProps.Update();

            Console.WriteLine("Calling RenameThermoProps...");
            ThermoProps thermoPropsRename = td.CreateThermoProps("rename me");
            thermoPropsRename.Rename("renamed thermo");

            Console.WriteLine("Calling GetThermopropss...");
            foreach (ThermoProps aThermoProps in td.GetThermoPropss())
                Console.WriteLine("  " + aThermoProps);

            Console.WriteLine("Calling DeleteThermoProps...");
            string deleteThermoName = "delete me";
            ThermoProps deleteThermo = td.CreateThermoProps(deleteThermoName);
            td.DeleteThermoProps(deleteThermoName);

            Console.WriteLine("Creating ThermoProp alias...");
            td.ThermoPropAliasManager.CreateOrUpdateAlias("alias1", "dummyMaterial");
            td.ThermoPropAliasManager.CreateOrUpdateAlias("alias1", "test_material");

            Console.WriteLine("Getting ThermoProp aliases...");
            foreach (Tuple<string, string> item in td.ThermoPropAliasManager.GetAliases())
                Console.WriteLine(string.Format("  {0} -- {1}", item.Item1, item.Item2));

            Console.WriteLine("Getting specific ThermoProp alias...");
            Tuple<string, string> alias1 = td.ThermoPropAliasManager.GetAlias("alias1");

            Console.WriteLine("Creating OpticalProps...");
            OpticalProps whitePaint = td.CreateOpticalProps("white paint");
            whitePaint.Emis = 0.90;
            whitePaint.Alph = 0.08;
            whitePaint.Update();

            Console.WriteLine("Calling GetOpticalPropss...");
            foreach (OpticalProps anOpticalProps in td.GetOpticalPropss())
                Console.WriteLine("  " + anOpticalProps);

            Console.WriteLine("Calling RenameOpticalProps...");
            OpticalProps opticalRename = td.CreateOpticalProps("rename me");
            opticalRename.Rename("renamed optical");

            Console.WriteLine("Creating OpticalProp alias...");
            td.OpticalPropAliasManager.CreateOrUpdateAlias("opticalAlias1", "dummyOpticalProp");
            td.OpticalPropAliasManager.CreateOrUpdateAlias("opticalAlias1", "white paint");

            Console.WriteLine("Getting OpticalProp aliases...");
            foreach (Tuple<string, string> item in td.OpticalPropAliasManager.GetAliases())
                Console.WriteLine(string.Format("  {0} -- {1}", item.Item1, item.Item2));

            Console.WriteLine("Getting specific OpticalProp alias...");
            Tuple<string, string> opticalAlias1 = td.OpticalPropAliasManager.GetAlias("opticalAlias1");

            Console.WriteLine("Calling SetMaterialStack...");
            MaterialStack stack = td.CreateMaterialStack("cake");
            stack.Layers = new List<MaterialStackLayerData>
            {
                new MaterialStackLayerData() { Material = "batter", NumNodes = 5, Thickness = 0.05 },
                new MaterialStackLayerData() { Material = "icing", NumNodes = 2, Thickness = 0.02 }
            };
            stack.Update();

            Console.WriteLine("Calling GetMaterialStack...");
            try { MaterialStack cake = td.GetMaterialStack("cake"); Console.WriteLine("  Found 'cake'"); }
            catch { Console.WriteLine("  There was a problem finding material stack 'cake'"); }

            Console.WriteLine("Calling GetMaterialStacks...");
            foreach (MaterialStack aStack in td.GetMaterialStacks())
                Console.WriteLine("  " + aStack);

            Console.WriteLine("Calling DeleteMaterialStack...");
            MaterialStack stackToDelete = td.CreateMaterialStack("deleteMe");
            td.DeleteMaterialStack(stackToDelete.Name);

            Console.WriteLine("Calling RenameMaterialStack...");
            MaterialStack stackToRename = td.CreateMaterialStack("renameMe");
            stackToRename.Rename("renamed");

            Console.WriteLine("Calling AddNodeCorrespondence...");
            Node sindaNode = td.CreateNode();
            Node radcadNode = td.CreateNode();
            sindaNode.Submodel = "SINDANODE";
            sindaNode.Id = 1;
            radcadNode.Submodel = "radcadnode";
            radcadNode.Id = 1;
            sindaNode.Update();
            radcadNode.Update();
            td.AddNodeCorrespondence(new NameData("sindanode", 1), new NameData("radcadnode", 1));
            td.SetNodeCorrespondenceState(true);

            Console.WriteLine("Creating nodes...");
            List<Node> someNodes = new List<Node>();
            for (int i = 1; i <= 10; i++)
            {
                Node n = td.CreateNode();
                n.Submodel = "thermaltest";
                n.Comment = "This is a node comment";
                n.Layer = "thermaltest nodes";
                n.NodeType = Node.NodeTypes.BOUNDARY;
                n.Id = i;

                n.Origin.X = -10 + 10 * i;
                n.Origin.Y = 0;
                n.Origin.Z = 0;

                n.MassVolExp.units.energy = UnitsData.Energy.KJ;
                n.MassVolExp.Value = "8+2";

                n.UseVersusTime = 1;
                n.TimeArray = new List<double>() { 0, 1, 2 };
                n.ValueArray = new List<double>() { 100, 150, 150 };

                n.TCode.Variables0 = "C Variables0";
                n.TCode.Variables1 = "C Variables1";
                n.TCode.Variables2 = "C Variables2";
                n.TCode.AfterBuild = "C After Build";
                n.TCode.BeforeBuild = "C Before Build";
                n.TCode.Operations = "C Operations";
                n.TCode.Output = "C Output";
                n.TCode.PostSolution = "C Post Solution";
                n.TCode.Comment = "a comment";

                try
                {
                    n.Update();
                    someNodes.Add(n);
                    Console.WriteLine("   Success.");
                }
                catch (OpenTDException ex)
                {
                    Console.WriteLine("   There was a problem: " + ex.Message);
                }
            }

            Console.WriteLine("Creating a clone node...");
            Node cloneNode = td.CreateNode();
            cloneNode.NodeType = Node.NodeTypes.CLONE;
            cloneNode.Submodel = "THERMALTEST";
            cloneNode.Id = 1;
            cloneNode.Origin.X = 0;
            cloneNode.Origin.Y = -10;
            cloneNode.Origin.X = 0;
            cloneNode.Update();

            Console.WriteLine("Trying to merge some nodes...");
            List<string> handlesToTryMerging = new List<string>();
            Point3d mergeNodeOriginCM = new Point3d(20, -10, 0);
            double mergeNodeIncrementCM = 1;
            for (int i = 0; i < 20; ++i)
            {
                Node n = td.CreateNode();
                handlesToTryMerging.Add(n.Handle);
                n.Origin = new Point3d(mergeNodeOriginCM);
                n.Submodel = "TRYMERGE";
                n.Id = i + 1;
                n.Update();
                mergeNodeOriginCM = mergeNodeOriginCM + new Point3d(mergeNodeIncrementCM, 0, 0);
            }
            td.MergeNodes(new MergeNodesOptionsData
            {
                NodeHandles = handlesToTryMerging,
                KeepMethod = MergeNodesOptionsData.KeepMethods.FIRST_SELECTED,
                Tolerance = 1.1
            });

            Console.WriteLine("Calling GetNodes to get all nodes...");
            List<Node> nodes = td.GetNodes();
            if (nodes.Count != 0)
            {
                foreach (Node node in nodes)
                {
                    Console.WriteLine("  " + node);
                }
            }
            else
            {
                Console.WriteLine("   Could not find any nodes in TD model.");
                return;
            }

            Console.WriteLine("Filtering node list to get a subset...");
            List<Node> nodesXHigh = td.Filter<Node>(nodes, a => a.Origin.X > 40);
            if (nodesXHigh.Count != 0)
            {
                foreach (Node node in nodesXHigh)
                {
                    Console.WriteLine("  " + node);
                }
            }
            else
            {
                Console.WriteLine("   Could not find any nodes in filtered list.");
                return;
            }

            Console.WriteLine("Updating a node...");
            Node nodeUpdate = nodes[5];
            nodeUpdate.Submodel = "updatedsubmodel";
            nodeUpdate.Update();

            Console.WriteLine("Creating a HeatLoad...");
            List<Connection> heatloadApply = new List<Connection> { someNodes[0] };
            HeatLoad heatLoad = td.CreateHeatLoad(heatloadApply);
            heatLoad.AppliedType = HeatLoad.AppliedTypeBoundaryConds.NODE;
            heatLoad.Layer = "Testing Heatloads";
            heatLoad.Name = "Test HeatLoad";
            heatLoad.Submodel = "heatload";
            heatLoad.HeatLoadTransientType = HeatLoad.HeatLoadTransientTypes.CONSTANT_HEAT_LOAD;
            heatLoad.Value = 10;
            heatLoad.Name = "Updated comment";
            heatLoad.Update();

            Console.WriteLine("Calling GetHeatLoads...");
            List<HeatLoad> someHeatLoads = td.GetHeatLoads();
            if (someHeatLoads.Count > 0)
            {
                foreach (HeatLoad aHeatLoad in someHeatLoads)
                    Console.WriteLine("  " + aHeatLoad);
            }
            else
                Console.WriteLine("  No heatloads found.");

            Console.WriteLine("Creating a heater...");
            List<Connection> applyConnections = new List<Connection> { someNodes[1] };
            List<Connection> sensorConnections = new List<Connection> { someNodes[2] };
            Heater heater = td.CreateHeater(applyConnections, sensorConnections);
            heater.Layer = "heaters";
            heater.Submodel = "heater";
            heater.Name = "Updated name";
            heater.Update();

            Console.WriteLine("Calling GetRcHeaters...");
            List<Heater> someHeaters = td.GetHeaters();
            if (someHeaters.Count > 0)
            {
                foreach (Heater aHeater in someHeaters)
                    Console.WriteLine("  " + aHeater);
            }
            else
                Console.WriteLine("  No heaters found.");

            Console.WriteLine("Creating Conductors...");
            for (int i = 0; i < 9; i++)
            {
                Conductor c = td.CreateConductor(someNodes[i], someNodes[i + 1]);
                c.Submodel = "random2";
                c.Name = "This is a conductor name";
                c.Layer = "testing conductors";
                c.TCode.Variables0 = "C Variables 0";
                c.IsRadiation = 1;
                c.Value = 3;
                c.Update();
                c.Name = "Updated conductor name";
                c.Update();
            }

            Console.WriteLine("Calling GetRcConductors...");
            List<Conductor> someConductors = td.GetConductors();
            if (someConductors.Count > 0)
            {
                foreach (Conductor aConductor in someConductors)
                    Console.WriteLine("  " + aConductor);
            }
            else
                Console.WriteLine("  No conductors found.");

            Units.WorkingUnits.SetToEng();
            Units.WorkingUnits.modelLength = UnitsData.ModelLength.CM;

            Console.WriteLine("Creating FluidSubmodel...");
            td.CreateFluidSubmodel("FLUIDTEST");

            Console.WriteLine("Calling RenameFluidSubmodel...");
            var fluidSubmodel = td.CreateFluidSubmodel("RenameMe");
            fluidSubmodel.Rename("NewName");

            Console.WriteLine("Calling CreateFluidSubmodel with same submodel name again...");
            FluidSubmodel fluidTest = td.CreateFluidSubmodel("FLUIDTEST");
            // use these lists to specify fluids:
            fluidTest.ClearFluidLists();
            string inc6081 = @"C:\Program Files\Cullimore and Ring\SindaFluint\insert_files\r6081_r507a.inc";
            if (System.IO.File.Exists(inc6081))
            {
                fluidTest.FluidIds.Add(6081);
                fluidTest.FluidLetters.Add(25);
                fluidTest.FluidFilenames.Add(inc6081);
            }
            fluidTest.FluidIds.Add(8729);
            fluidTest.FluidLetters.Add(0);
            fluidTest.FluidFilenames.Add(""); // since this is blank, it will be set to "Air", based on ID 8729
            fluidTest.FluidIds.Add(6070);
            fluidTest.FluidLetters.Add(1);
            fluidTest.FluidFilenames.Add(""); // since this is blank, it will be set to "Water", based on ID 6070 (Fogbugz case 7580)
            fluidTest.FluidIds.Add(8729);
            fluidTest.FluidLetters.Add(2);
            fluidTest.FluidFilenames.Add("userAir.inc"); // this will remain unchanged, since it's not blank (Fogbugz case 6914)
            fluidTest.Update();

            Console.WriteLine("Renaming a fluid submodel to existing submodel throws an exception...");
            try
            {
                FluidSubmodel renameTo = td.CreateFluidSubmodel("TryRenameTo");
                FluidSubmodel renameFrom = td.CreateFluidSubmodel("TryRenameFrom");
                renameFrom.Rename("TryRenameTo");
            }
            catch (OpenTDException ex)
            {
                Console.WriteLine("  " + ex.Message);
            }

            Console.WriteLine("Calling DeleteFluidSubmodel...");
            td.CreateFluidSubmodel("deLeteme");
            td.DeleteFluidSubmodel("DelEtemE");

            Console.WriteLine("Calling GetFluidSubmodels...");
            foreach (FluidSubmodel aFluidSubmodel in td.GetFluidSubmodels())
                Console.WriteLine("  " + aFluidSubmodel);

            Console.WriteLine("Creating UserCode for a fluid submodel...");
            UserCode userCodeFluid = td.CreateUserCode();
            userCodeFluid.Submodel = "FLUIDTEST";
            userCodeFluid.Comment = "FLUINT code";
            userCodeFluid.Code = "c first line\nc second line";
            userCodeFluid.Declarations = "c first line\nc second line";
            userCodeFluid.Routine = LogicObjectRoutineTypes.SUBROUTINE_or_NODE_or_FLOW;
            userCodeFluid.Update();

            Console.WriteLine("Calling GetLogicObjects()...");
            List<LogicObject> someRcLogics = td.GetLogicObjects();
            foreach (LogicObject item in someRcLogics)
                Console.WriteLine("  " + item);

            Console.WriteLine("Creating new lumps...");
            List<Lump> someLumps = new List<Lump>();
            for (int i = 1; i <= 10; i++)
            {
                Lump L = td.CreateLump();
                L.Layer = "lumps";
                L.Submodel = "FLUIDTEST";
                L.Comment = "This is a lump comment";
                L.LumpType = Lump.LumpTypes.TANK;
                L.CxUser = 3;
                L.TCode.Comment = "comment first line\ncomment second line";
                L.TCode.Flogic0 = "c flogic0 line 1\nc flogic0 line 2";

                L.Ult = 1;

                L.Origin.X = -10 + 10 * i;
                L.Origin.Y = 10;
                L.Origin.Z = 0;

                L.Update();
                someLumps.Add(L);
                Console.WriteLine("   Success.");
            }

            Console.WriteLine("Creating a clone lump...");
            Lump cloneLump = td.CreateLump();
            cloneLump.Origin.X = -10;
            cloneLump.Origin.Y = 10;
            cloneLump.Origin.Z = 0;
            cloneLump.LumpType = Lump.LumpTypes.CLONE;
            cloneLump.ParentHandle = someLumps[0].Handle;
            cloneLump.Update();

            Console.WriteLine("Calling GetLumps...");
            List<Lump> lumpsInModel = td.GetLumps();
            foreach (Lump lumpInModel in lumpsInModel)
            {
                Console.WriteLine(String.Format("  {0}", lumpInModel));
            }

            Console.WriteLine("Updating a lump...");
            Lump updatedLump = lumpsInModel[0];
            updatedLump.Comment = "Updated comment";
            updatedLump.Update();

            Console.WriteLine("Creating ports...");
            Port upPort = td.CreatePort(someLumps[0].Handle);
            upPort.Origin.X = 0;
            upPort.Origin.Y = 20;
            upPort.Origin.Z = 0;
            upPort.Comment = "upPort";
            upPort.Update();
            Port downPort = td.CreatePort(someLumps[9].Handle);
            downPort.Origin.X = 90;
            downPort.Origin.Y = 20;
            downPort.Origin.Z = 0;
            downPort.Comment = "downPort";
            downPort.Update();

            Console.WriteLine("Calling GetPorts...");
            foreach (Port aPort in td.GetPorts())
                Console.WriteLine("  " + aPort);

            Console.WriteLine("Calling SetRcPath...");
            List<Path> somePaths = new List<Path>();
            // tube:
            Path tube = td.CreatePath(someLumps[0], someLumps[1]);
            tube.Submodel = "FLUIDTEST";
            tube.Comment = "This is a path comment";
            tube.isTube = false; // stube
            tube.TCode.Flogic0 = "C FLOGIC0";
            tube.UserList = new List<string> { "c first line\nc second line", "c third line" };
            tube.Update();
            somePaths.Add(tube);
            Console.WriteLine("   Success.");
            // loss:
            Path loss = td.CreatePath(someLumps[1], someLumps[2], Path.PathTypes.LOSS);
            loss.Submodel = "FLUIDTEST";
            loss.ThroatArea = 4;
            loss.useThroatArea = true;
            loss.Aori_t = 10;
            loss.Update();
            // setflow:
            Path setflow = td.CreatePath(someLumps[2], someLumps[3], Path.PathTypes.SETFLOW);
            setflow.Submodel = "FLUIDTEST";
            setflow.MassFlowRate = 4;
            setflow.VolumeFlowRate = 5;
            setflow.Mch = 1;
            setflow.Update();
            // orifice:
            Path orifice = td.CreatePath(someLumps[3], someLumps[4], Path.PathTypes.ORIFICE);
            orifice.Submodel = "FLUIDTEST";
            orifice.FlowArea = 10;
            orifice.Modo = 1;
            orifice.Update();
            // compress:
            Path compress = td.CreatePath(someLumps[4], someLumps[5], Path.PathTypes.COMPRESS);
            compress.Submodel = "FLUIDTEST";
            compress.FlowArea = 10;
            compress.Sscf = 5;
            compress.CompressType = Path.CompressTypes.CMAP;
            compress.HVsGgArraysExp.outputToSinda = 1;
            compress.HVsGgArraysExp.sindaUnits = 1; // this overrides HVsGhArraysExp.sindaUnits
            compress.HVsGgArraysExp.expression = new List<List<string>> { new List<string> { "1", "2" }, new List<string> { "3", "4" } };
            compress.HVsGhArraysExp.outputToSinda = 1;
            compress.HVsGhArraysExp.sindaUnits = 1; // this is unnecessary, I think
            compress.HVsGhArraysExp.expression = new List<List<string>> { new List<string> { "8", "7" }, new List<string> { "6", "5" } };
            compress.SpeedArrayExp.expression = new List<string> { "100", "200" };
            compress.Update();
            // pump:
            Path pump = td.CreatePath(someLumps[5], someLumps[6], Path.PathTypes.PUMP);
            pump.Submodel = "FLUIDTEST";
            pump.FlowArea = 10;
            pump.EffType = Path.EfficiencyTypes.ONECURVEEFFICIENCY;
            pump.EffvArrayExp.outputToSinda = 1;
            pump.EffArrayExp.expression = new List<string> { "0.1", "0.2" };
            pump.EffGArrayExp.outputToSinda = 1;
            pump.EffGArrayExp.expression = new List<string> { "10", "11" };
            pump.Update();

            Console.WriteLine("Creating a Cappmp...");
            Cappmp cappmp = td.CreateCappmp(someLumps[8], someLumps[9], someNodes[9]);
            cappmp.Comment = "Updated comment";
            cappmp.Update();

            Console.WriteLine("Calling GetCappmps...");
            List<Cappmp> someCappmps = td.GetCappmps();
            if (someCappmps.Count > 0)
            {
                foreach (Cappmp aCappmp in someCappmps)
                    Console.WriteLine("  " + aCappmp);
            }
            else
                Console.WriteLine("  No cappmps found.");

            Console.WriteLine("Creating tie...");
            List<Connection> tieNodes = new List<Connection>();
            List<Connection> tieLumps = new List<Connection>();
            List<string> tiePaths = new List<string> { somePaths[0].Handle };
            for (int i = 0; i < 10; i++)
            {
                tieNodes.Add(someNodes[i].Handle);
                tieLumps.Add(someLumps[i].Handle);
            }
            Tie tie = td.CreateTie(tieNodes, tieLumps, tiePaths);
            tie.Submodel = "FLUIDTEST";
            tie.Comment = "This is a tie comment";
            tie.Id.Add(100);
            tie.Id.Add(101);
            tie.NetworkLogic.Flogic0 = "C FLOGIC0";
            tie.Update();

            Console.WriteLine("Calling GetTies...");
            List<Tie> ties = td.GetTies();
            if (ties.Count > 0)
            {
                foreach (Tie t in ties)
                    Console.WriteLine(t.ToString());
            }
            else
                Console.WriteLine("  Could not find ties in TD model.");

            Console.WriteLine("Creating an FTie...");
            FTie ftie = td.CreateFTie(someLumps[1].Handle, someLumps[2].Handle, Connection.Empty);
            ftie.Comment = "This is an ftie comment";
            ftie.Update();

            Console.WriteLine("Calling GetFTies...");
            foreach (FTie ftieInModel in td.GetFTies())
            {
                Console.WriteLine(String.Format("  {0}", ftieInModel));
            }

            Console.WriteLine("Creating an IFace...");
            IFace createdIFace = td.CreateIFace(someLumps[1].Handle, someLumps[2].Handle);

            Console.WriteLine("Updating IFace...");
            createdIFace.Comment = "This is an iface comment";
            createdIFace.Update();

            Console.WriteLine("Calling GetIFaces...");
            List<IFace> someIFaces = td.GetIFaces();
            if (someIFaces.Count > 0)
            {
                foreach (IFace anIFace in someIFaces)
                    Console.WriteLine("  " + anIFace);
            }
            else
                Console.WriteLine("  No IFaces found.");

            Console.WriteLine("Creating a line...");
            Line pipeCenterline = td.CreateLine(new Point3d(0, 20, 0), new Point3d(90, 20, 0));
            pipeCenterline.pointB = new Point3d(90, 30, 0);
            pipeCenterline.Update();

            Console.WriteLine("Calling GetLines...");
            foreach (Line aLine in td.GetLines())
                Console.WriteLine("  " + aLine);

            Console.WriteLine("Calling GetLine...");
            Line specificLine = td.GetLine(pipeCenterline.Handle);
            Console.WriteLine("  " + specificLine);

            Console.WriteLine("Creating pipes...");
            Pipe pipe = td.CreatePipe(new List<string> { pipeCenterline.Handle });
            pipe.WallGeometryType = Pipe.WallGeometryTypes.STANDARD_PIPE;
            PipeStdUtility pipeStds = new PipeStdUtility(td);
            pipe.Comment = "pipe comment";
            pipe.StandardPipeSignature = pipeStds.GetPipeStdSignature("aluminum", "10", "50");
            pipe.UpPort = upPort.Handle;
            pipe.DownPort = downPort.Handle;
            pipe.Submodel = "FLUIDTEST";
            pipe.BreakdownU.Num = 4;
            pipe.BreakdownV.Num = 10;
            pipe.EndNodeSubmodel = "endnodesubmodel";
            pipe.EndNodeInSubmodel = "endnodeinsubmodel";
            pipe.CondSubmodel = "PIPECONDSUB";
            pipe.Update();

            if (pipe.LumpHandles.Count > 0)
            {
                if (pipe.LumpHandles.Contains(pipe.UpPort.Handle))
                    Console.WriteLine("  LumpHandles contains UpPortHandle");
                else
                    Console.WriteLine("  LumpHandles does not contain UpPortHandle");
            }
            else
                Console.WriteLine("  pipe.Update() did not update lump handles.");
            Console.WriteLine("Calling GetTie to get first tie created by pipe...");
            Tie pipeTie = null;
            if (pipe.TieHandles.Count > 0)
            {
                pipeTie = td.GetTie(pipe.TieHandles[0]);
                if (pipeTie != null)
                    Console.WriteLine("  " + pipeTie);
                else
                    Console.WriteLine("  Could not get tie from handle.");
            }
            else
                Console.WriteLine("  pipe does not contain tie handles.");
            Console.WriteLine("Updating first tie created by SetRcPipe...");
            if (pipeTie != null)
            {
                pipeTie.Comment = "I have been updated.";
                pipeTie.Update();
            }
            else
                Console.WriteLine("  Could not get tie from pipe.");

            Console.WriteLine("Calling GetPipes...");
            List<Pipe> somePipes = td.GetPipes();
            foreach (Pipe aPipe in somePipes)
                Console.WriteLine(string.Format("  {0}", aPipe));

            Console.WriteLine("Calling GetLumps...");
            lumpsInModel = td.GetLumps();
            foreach (Lump lumpInModel in lumpsInModel)
            {
                Console.WriteLine(String.Format("  {0}", lumpInModel));
            }

            Console.WriteLine("Creating a multi-conductor to pipe...");
            Node nodeToPipe = td.CreateNode();
            nodeToPipe.Submodel = "multicond";
            nodeToPipe.Origin.X = 45;
            nodeToPipe.Origin.Y = 40;
            nodeToPipe.Update();
            Conductor condToPipe = td.CreateConductor(nodeToPipe, pipe);
            condToPipe.Submodel = "multicond";
            condToPipe.ValueExp.Value = "12";
            condToPipe.IsPerArea = 1;
            condToPipe.Update();

            Console.WriteLine("Applying a heatload to a pipe...");
            HeatLoad heatloadToPipe = td.CreateHeatLoad(new List<Connection> { pipe.Handle });
            heatloadToPipe.AppliedType = HeatLoad.AppliedTypeBoundaryConds.SURFACE;
            heatloadToPipe.Update();

            Console.WriteLine("Creating case set...");
            CaseSet case1 = td.CreateCaseSet("Case 1 original name", "", "case1Stuff");
            case1.SindaOptions.User2FileActive = true;
            case1.SindaControl.outptfExp.Value = "34 + 56";
            case1.SolverControl.nlooprExp.Value = "7+8";
            case1.Update();
            Console.WriteLine("   Success.");

            Console.WriteLine("Creating a detailed case...");
            CaseSet caseA = td.CreateCaseSet("Case A original name");

            RadiationTaskData radTask = new RadiationTaskData();
            radTask.AnalGroup = "GROUP1";
            caseA.RadiationTasks.Add(radTask);

            caseA.Comment = "This is the first line of a comment.\nThis is the second line.\n\nThis is the fourth line.";
            caseA.SindaFilenames = "testCaseA";
            caseA.SindaOptions.SaveFilename = "overrideSaveName.sav";
            caseA.SindaOptions.User1FileActive = true;
            caseA.SindaOptions.User1Filename = "aUser1File.us1";
            caseA.SindaControl.patmos = 300;
            caseA.SindaControl.timeoExp.Value = "1+2";
            caseA.SindaControl.timend = 5;
            caseA.SindaControl.opeitr = 1;
            caseA.SindaControl.solutionType = SindaControlData.SolutionType.AMG_MATRIX_SINGLE;
            caseA.SindaControl.dtsizf = 0.2;
            caseA.SindaControl.dttubf = 0.2;

            caseA.SindaControl.accelx = 10;
            caseA.SindaControl.accely = 11;
            caseA.SindaControl.accelz = 12;
            caseA.SindaControl.accelFromPreferences = false;

            caseA.SindaControl.AdditionalUserInput = "C additional sinda control input\nC line two";
            caseA.SolverControl.Object = "MAIN.T1";
            caseA.SolverControl.aerrr = 56;
            caseA.SindaOper = "C Testing Operations\nC Line 2";
            caseA.SindaOther = "C Testing Other";
            caseA.SindaSubroutine = "C Testing Subroutine\n";
            caseA.SymbolNames = new List<string> { "radius", "somethingIncorrect" };
            caseA.SymbolValues = new List<string> { "25", "4", };
            caseA.SymbolComments = new List<string> { "radius comment", "somethingIncorrect comment" };
            caseA.AsciiG = 1;
            caseA.L2Tab = 1;
            caseA.OutputSubmodel = "OUTPUTSUB";
            caseA.PostProcessOption = CaseSet.PostProcessOptionTypes.LAST_TIME;

            ThermalLogicData logicWING = new ThermalLogicData();
            logicWING.Variables1 = "C Testing WING Variable1\nC Test line 2\n";
            caseA.ThermalLogic.Add("WING", logicWING);

            ThermalLogicData logicSTRUT = new ThermalLogicData();
            logicSTRUT.Variables1 = "C Testing STRUT Variables1\nC Test line 2\n";
            logicSTRUT.Node = "C Testing STRUT Node Data\nC Test line 2\n";
            caseA.ThermalLogic.Add("STRUT", logicSTRUT);

            FluintLogicData fluidLogicFUEL = new FluintLogicData();
            fluidLogicFUEL.Flow = "C Testing FUEL Flow";
            caseA.FluintLogic.Add("FUEL", fluidLogicFUEL);

            RegisterData TheTime = new RegisterData();
            TheTime.Name = "THETIME";
            TheTime.valueType = RegisterData.ValueType.USERVALUE;
            TheTime.UserValue = "TIMEN";
            caseA.SindaRegisterVars.Add(TheTime);

            caseA.InsertFilenames.Add("an_insert_file.txt");
            caseA.InsertFilenames.Add("another_insert_file.txt");

            caseA.Update();
            Console.WriteLine("   Success.");

            Console.WriteLine("Renaming a case set...");
            caseA.Rename("Case A new name", "TestGroup");

            Console.WriteLine("Calling DeleteCaseSet...");
            td.DeleteCaseSet(case1.Name);

            Console.WriteLine("Calling GetCaseSets() to get all case sets...");
            List<CaseSet> caseSets = td.GetCaseSets();
            if (caseSets.Count > 0)
                foreach (CaseSet caseSet in caseSets)
                    Console.WriteLine(caseSet.ToString());
            else
                Console.WriteLine("  GetCaseSets was not successful.");

            Console.WriteLine("Creating an orbit...");
            Orbit anOrbit = td.CreateOrbit("anOrbit");

            Console.WriteLine("Modifying an orbit...");
            anOrbit.Comment = "Modified";
            anOrbit.Planet = Orbit.Planets.MARS;
            anOrbit.Update();

            Console.WriteLine("Creating a case set with an associated orbit...");
            CaseSet caseWithOrbit = td.CreateCaseSet("case with orbit");
            RadiationTaskData radTask2 = new RadiationTaskData();
            radTask2.TypeCalc = RadiationTaskData.calcType.HEATRATE;
            radTask2.AnalGroup = "BASE";
            radTask2.OrbitName = "anOrbit";
            caseWithOrbit.RadiationTasks.Add(radTask2);
            caseWithOrbit.Update();

            Console.WriteLine("Renaming an orbit...");
            anOrbit.Rename("aModifiedOrbit");

            Console.WriteLine("Deleting an orbit...");
            Orbit deleteMe = td.CreateOrbit("deleteMe");
            td.DeleteOrbit("deleteMe");

            Console.WriteLine("Getting orbits...");
            foreach (Orbit o in td.GetOrbits())
                Console.WriteLine("  " + o);

            Console.WriteLine("Creating some surfaces...");
            td.SetUnits(Units.SI);
            Rectangle rect = td.CreateRectangle();
            rect.BaseTrans.SetToRotZ(45); // rotate the surface using acad
            rect.BaseTrans.SetOrigin(new Point3d(0, 0.4, 0)); // position the surface using acad
            rect.LocalTrans.Axis1 = 1;  // rotate about surface's Y axis (Rot/Trans tab)
            rect.LocalTrans.Rot1 = -15; // magnitude of rotation on Rot/Trans tab
            rect.XMax = 0.25;
            rect.YMax = 0.10;
            rect.Layer = "surfaces";
            rect.CondSubmodel = "surfaces";
            rect.TopStartSubmodel = "surfaces";
            rect.BreakdownU.Num = 10;
            rect.BreakdownV.Num = 5;
            rect.Update();
            Rectangle rect2 = td.CreateRectangle();
            rect2.BaseTrans.SetToRotZ(45); // rotate the surface using acad
            rect2.BaseTrans.SetOrigin(new Point3d(0, 0.4, 0.03)); // position the surface using acad
            rect2.LocalTrans.Axis1 = 1;  // rotate about surface's Y axis (Rot/Trans tab)
            rect2.LocalTrans.Rot1 = -15; // magnitude of rotation on Rot/Trans tab
            rect2.XMax = 0.25;
            rect2.YMax = 0.10;
            rect2.Layer = "surfaces";
            rect2.CondSubmodel = "surfaces";
            rect2.TopStartSubmodel = "surfaces";
            rect2.BreakdownU.Num = 10;
            rect2.BreakdownV.Num = 5;
            rect2.Update();

            Console.WriteLine("Creating a MeshFD...");
            var meshFDpoints = new List<Point3d>
            {
                new Point3d(-0.1, 0.9, 0),
                new Point3d(0.15, 0.8, 0.1),
                new Point3d(0.15, 1.0, 0),
                new Point3d(0.2, 0.9, 0),
            };
            var meshFDfaces = new List<Face>
            {
                new Face() {VertexIndices = new List<int> {0, 1, 2}},
                new Face() {VertexIndices = new List<int> {1, 3, 2}},
            };
            MeshFD meshFD = td.CreateMeshFD(meshFDfaces, meshFDpoints);
            meshFD.TopStartSubmodel = "surfaces";
            meshFD.CondSubmodel = "surfaces";
            meshFD.Comment = "updated";
            meshFD.Update();

            Console.WriteLine("Creating a polygon...");
            Polygon poly = td.CreatePolygon(new List<Point3d> {
                new Point3d(0.15, 0.5, 0), new Point3d(0.25, 0.5, 0), new Point3d(0.25, 0.6, 0) });
            poly.TopStartSubmodel = "surfaces";
            poly.CondSubmodel = "surfaces";
            poly.Comment = "updated";
            poly.Update();

            #region FD Solids

            Console.WriteLine("Creating some FD Solids...");
            {
                string solidSubmodel = "solidsubmodel";
                {
                    SolidBrick x = td.CreateSolidBrick();
                    x.StartSubmodel = solidSubmodel;
                    x.CondSubmodel = solidSubmodel;
                    x.StartId = 100;
                    x.BreakdownU.Num = 5;
                    x.BreakdownV.Num = 7;
                    x.BreakdownW.Num = 10;
                    x.XMax = 0.1;
                    x.YMax = 0.2;
                    x.ZMax = 0.3;
                    x.BaseTrans.SetOrigin(new Point3d(0.3, 0.4, 0.0));
                    x.Update();
                }

                {
                    SolidCylinder x = td.CreateSolidCylinder();
                    x.StartSubmodel = solidSubmodel;
                    x.CondSubmodel = solidSubmodel;
                    x.StartId = 100;
                    x.BreakdownU.Num = 5;
                    x.BreakdownV.Num = 7;
                    x.BreakdownW.Num = 10;
                    x.Height = 0.2;
                    x.Rmax = 0.1;
                    x.BaseTrans.SetOrigin(new Point3d(0.4, 0.9, -0.1));
                    x.Update();
                }

                {
                    SolidEllipsoid x = td.CreateSolidEllipsoid();
                    x.StartSubmodel = solidSubmodel;
                    x.CondSubmodel = solidSubmodel;
                    x.StartId = 100;
                    x.BreakdownU.Num = 5;
                    x.BreakdownV.Num = 7;
                    x.BreakdownW.Num = 10;
                    x.OuterXRadius = 0.2;
                    x.OuterYRadius = 0.1;
                    x.OuterZRadius = 0.15;
                    x.OuterMinHeight = 0.0;
                    x.OuterMaxHeight = 0.1;
                    x.StartAngle = 0.0;
                    x.EndAngle = 270.0;
                    x.InnerXRadius = 0.05;
                    x.InnerYRadius = 0.05;
                    x.InnerZRadius = 0.05;
                    x.InnerMinHeight = 0.0;
                    x.InnerMaxHeight = 0.03;
                    x.BaseTrans.SetOrigin(new Point3d(0.5, 0.6, -0.2));
                    x.Update();
                }

                {
                    SolidSphere x = td.CreateSolidSphere();
                    x.StartSubmodel = solidSubmodel;
                    x.CondSubmodel = solidSubmodel;
                    x.StartId = 100;
                    x.BreakdownU.Num = 5;
                    x.BreakdownV.Num = 7;
                    x.BreakdownW.Num = 10;
                    x.Rmax = 0.05;
                    x.Bmax = 180.0;
                    x.BaseTrans.SetOrigin(new Point3d(0.6, 0.7, -0.3));
                    x.Update();
                }

                {
                    SolidCone x = td.CreateSolidCone();
                    x.StartSubmodel = solidSubmodel;
                    x.CondSubmodel = solidSubmodel;
                    x.StartId = 100;
                    x.BreakdownU.Num = 5;
                    x.BreakdownV.Num = 7;
                    x.BreakdownW.Num = 10;
                    x.Height = 0.1;
                    x.BaseRmax = 0.1;
                    x.TopRmax = 0.0;
                    x.StartAngle = 0.0;
                    x.EndAngle = 270.0;
                    x.BaseTrans.SetOrigin(new Point3d(0.7, 0.8, -0.3));
                    x.Update();
                }
            }

            #endregion

            #region FEM LinearElements

            Console.WriteLine("Creating some FEM linear elements...");
            {
                string femSubmodel = "FEM_SUBMODEL";

                var nodeCoords = new List<Tuple<double, double, double>>()
                {
                    new Tuple<double, double, double>( 0, 0, 0 ),
                    new Tuple<double, double, double>(-0.4745648  ,    0.3566875    ,      0.07    ),
                    new Tuple<double, double, double>(-0.4725032  ,     0.292862    ,      0.07    ),
                    new Tuple<double, double, double>(-0.4811792  ,   0.07537512    ,      0.05    ),
                    new Tuple<double, double, double>(-0.4803823  ,   0.00803286    ,      0.05    ),
                    new Tuple<double, double, double>(-0.4803823  ,   0.00803286    ,        0.0    ),
                    new Tuple<double, double, double>(-0.3677674  ,    0.1286399    ,       0.1    ),
                    new Tuple<double, double, double>(-0.3305769  ,    0.1091637    ,        0.0   ),
                    new Tuple<double, double, double>(-0.4811792  ,   0.07537512    ,        0.0    ),
                    new Tuple<double, double, double>(-0.4019455  ,    0.1104917    ,        0.0    ),
                    new Tuple<double, double, double>(-0.2388378  ,    0.2914264    ,      0.07    ),
                    new Tuple<double, double, double>(-0.2388378  ,    0.2914264    ,        0.0    ),
                    new Tuple<double, double, double>(-0.2512646  ,    0.1959643    ,        0.0    ),
                    new Tuple<double, double, double>(-0.2901826  ,    0.2542076    ,        0.0    ),
                    new Tuple<double, double, double>(-0.3234554  ,    0.1939001    ,        0.0    ),
                    new Tuple<double, double, double>(-0.4728871  ,    0.1922868    ,        0.0    ),
                    new Tuple<double, double, double>(-0.3677767  ,    0.1597929    ,        0.0    ),
                    new Tuple<double, double, double>(-0.4074083  ,    0.1934696    ,        0.0    ),
                    new Tuple<double, double, double>(-0.4093696  ,    0.2485145    ,        0.0    ),
                    new Tuple<double, double, double>(-0.4725032  ,     0.292862    ,        0.0    ),
                    new Tuple<double, double, double>(-0.4745648  ,    0.3566875    ,        0.0    ),
                    new Tuple<double, double, double>(-0.4756967  ,    0.2490214    ,        0.0    ),
                    new Tuple<double, double, double>(  -0.23256  ,   0.07192255    ,      0.05    ),
                    new Tuple<double, double, double>(-0.2245568  , 0.0009138394    ,      0.05    ),
                    new Tuple<double, double, double>(-0.2245568  , 0.0009138394    ,        0.0    ),
                    new Tuple<double, double, double>(  -0.23256  ,   0.07192255    ,        0.0    ),
                };

                var ns = new List<Node>();
                foreach (var c in nodeCoords)
                {
                    var n = td.CreateNode();
                    n.Origin = new Point3d(c.Item1, c.Item2, c.Item3);
                    n.Submodel = femSubmodel;
                    n.Update();
                    ns.Add(n);
                }

                td.CreateLinearTri(new List<string> { ns[12].Handle, ns[13].Handle, ns[14].Handle });
                td.CreateLinearQuad(new List<string> { ns[17].Handle, ns[18].Handle, ns[21].Handle, ns[15].Handle });
                td.CreateLinearTet(new List<string> { ns[9].Handle, ns[7].Handle, ns[6].Handle, ns[16].Handle });
                td.CreateLinearWedge(new List<string> { ns[10].Handle, ns[1].Handle, ns[2].Handle,
                                                        ns[11].Handle, ns[20].Handle, ns[19].Handle });
                td.CreateLinearBrick(new List<string> { ns[23].Handle, ns[22].Handle, ns[3].Handle, ns[4].Handle,
                                                        ns[24].Handle, ns[25].Handle, ns[8].Handle, ns[5].Handle });
            }

            #endregion

            Console.WriteLine("Creating a contactor...");
            Contactor contact = td.CreateContactor(new List<Connection> { rect }, new List<Connection> { rect2 });
            contact.CondSubmodel = "surfaces";
            contact.ContactCond = 3.0;
            contact.Update();

            Console.WriteLine("Creating a TEC...");
            Tec tec = td.CreateTec(new List<Connection> { rect }, new List<Connection> { rect2 });
            tec.CondSubmodel = "surfaces";
            tec.Name = "updated";
            tec.Update();

            #region tee

            Console.WriteLine("Creating a tee...");
            Lump teeMainUpLump = td.CreateLump();
            Lump teeMidLump = td.CreateLump();
            Lump teeMainDownLump = td.CreateLump();
            Lump teeBranchLump = td.CreateLump();

            teeMainUpLump.Origin = new Point3d(0.5, -0.1, 0);
            teeMidLump.Origin = new Point3d(0.6, -0.1, 0);
            teeMainDownLump.Origin = new Point3d(0.7, -0.1, 0);
            teeBranchLump.Origin = new Point3d(0.6, -0.2, 0);

            teeMainUpLump.Update();
            teeMidLump.Update();
            teeMainDownLump.Update();
            teeBranchLump.Update();

            Path teeMain1Path = td.CreatePath(teeMainUpLump, teeMidLump);
            Path teeMain2Path = td.CreatePath(teeMidLump, teeMainDownLump);
            Path teeBranchPath = td.CreatePath(teeBranchLump, teeMidLump);

            Tee tee = td.CreateTee(new List<string> { teeMain1Path.Handle, teeMain2Path.Handle }, teeBranchPath.Handle);

            // edit tee
            Lump newTeeBranchLump = td.CreateLump();
            newTeeBranchLump.Origin = new Point3d(0.63, -0.2, 0);
            newTeeBranchLump.Update();
            Path newTeeBranchPath = td.CreatePath(newTeeBranchLump, teeMidLump);
            tee.BranchPath = newTeeBranchPath;
            tee.Comment = "Repositioned branch path";
            tee.Update();
            // delete old branch path
            td.DeleteEntity(teeBranchPath);
            td.DeleteEntity(teeBranchLump);

            // get tees
            var tees = td.GetTees();

            #endregion

            #region FkLocator

            Console.WriteLine("Creating an FkLocator");
            Lump fkUpLump = td.CreateLump();
            Lump fkDownLump = td.CreateLump();

            fkUpLump.Origin = new Point3d(0.8, -0.1, 0);
            fkDownLump.Origin = new Point3d(0.9, -0.15, 0);

            fkUpLump.Update();
            fkDownLump.Update();

            Path fkPath = td.CreatePath(fkUpLump, fkDownLump);

            FkLocator fk = td.CreateFkLocator(fkPath.Handle, new Point3d(0.87, -0.1, 0));

            // edit the fk
            Lump fknewDownLump = td.CreateLump();
            fknewDownLump.Origin = new Point3d(0.9, -0.2, 0);
            fknewDownLump.Update();
            Path fkNeWPath = td.CreatePath(fkUpLump, fknewDownLump);
            fk.AttachedObjects = new List<Connection>() { fkNeWPath };
            fk.Comment = "updated";
            fk.Update();

            // get FkLocators
            var fks = td.GetFkLocators();

            #endregion

            #region Arc

            Console.WriteLine("Creating an arc...");
            var arc = td.CreateArc();
            arc.Center = new Point3d(1.2, 0, 0);
            arc.Radius = 0.1;
            arc.EndAngle = 135;
            arc.Normal = new Vector3d(1, 1, 0);
            arc.Update();

            Console.WriteLine("Getting arcs...");
            foreach (Arc a in td.GetArcs())
                Console.WriteLine("  " + a);

            #endregion

            #region Circle

            Console.WriteLine("Creating an Circle...");
            var Circle = td.CreateCircle();
            Circle.Center = new Point3d(1.2, 0, 0);
            Circle.Radius = 0.15;
            Circle.Normal = new Vector3d(1, 0, 0);
            Circle.Update();

            Console.WriteLine("Getting Circles...");
            foreach (Circle a in td.GetCircles())
                Console.WriteLine("  " + a);

            #endregion

            #region AcEllipse

            Console.WriteLine("Creating an AcEllipse...");
            var AcEllipse = td.CreateAcEllipse();
            AcEllipse.Center = new Point3d(1.2, 0, 0);
            AcEllipse.RadiusRatio = 0.5;
            AcEllipse.Normal = new Vector3d(1, 0, 0);
            AcEllipse.MajorAxis = new Vector3d(0, 0.1, 0);
            AcEllipse.Update();

            Console.WriteLine("Getting AcEllipses...");
            foreach (AcEllipse a in td.GetAcEllipses())
                Console.WriteLine("  " + a);

            #endregion

            #region Spline

            Console.WriteLine("Creating a Spline...");
            var Spline = td.CreateSpline();
            Spline.NurbsData.ControlPoints = new List<Point3d>
            {
                new Point3d(1.2, -0.2, 0.2),
                new Point3d(1.2, -0.1, 0.5),
                new Point3d(1.2, 0.0, 0.0),
                new Point3d(1.2, 0.1, 0.4)
            };
            Spline.Update();

            Console.WriteLine("Getting Splines...");
            foreach (Spline a in td.GetSplines())
                Console.WriteLine("  " + a);

            #endregion

            #region Helix

            Console.WriteLine("Creating a Helix...");
            var Helix = td.CreateHelix();
            Helix.BaseCenter = new Point3d(1.2, 0, 0);
            Helix.BaseRadius = 0.2;
            Helix.Height = 0.5;
            Helix.TopRadius = 0.1;
            Helix.NumTurns = 3.5;
            Helix.Axis = new Vector3d(1, 1, 1);
            Helix.Update();

            Console.WriteLine("Getting Helices...");
            foreach (Helix a in td.GetHelices())
                Console.WriteLine("  " + a);

            #endregion

            #region Polyline

            Console.WriteLine("Creating a Polyline...");
            var polyline = td.CreatePolyline();
            polyline.Vertices = new List<PolylineVertex>
            {
                new PolylineVertex(-0.9, 0.1),
                new PolylineVertex(-1.0, 0.1, 0.0, 0.010, 0.015),
                new PolylineVertex(-1.1, 0.2, -0.5)
            };
            polyline.Normal = new Vector3d(1, 1, 1);
            polyline.Elevation = 1.0;
            polyline.ExtrusionThickness = 0.05;
            polyline.Closed = true;
            polyline.Update();

            Console.WriteLine("Getting Polylines...");
            foreach (Polyline a in td.GetPolylines())
                Console.WriteLine("  " + a);

            #endregion

            #region Compartment
            {
                Console.WriteLine("Creating compartment...");
                var compartmentOrigin = new Point3d(0, -0.5, 0);
                var nodeLocs = new List<Point3d>
                {
                    compartmentOrigin + new Point3d(0,0,0),
                    compartmentOrigin + new Point3d(0.1,0,0),
                    compartmentOrigin + new Point3d(0.1,0.1,0),
                    compartmentOrigin + new Point3d(0,0.1,0),
                    compartmentOrigin + new Point3d(0,0,0.1),
                    compartmentOrigin + new Point3d(0.1,0,0.1),
                    compartmentOrigin + new Point3d(0.1,0.1,0.1),
                    compartmentOrigin + new Point3d(0,0.1,0.1),
                };

                var compartmentNodes = new List<Node>();
                foreach (Point3d origin in nodeLocs)
                {
                    var node = td.CreateNode(origin);
                    compartmentNodes.Add(node);
                }

                var brick = td.CreateLinearBrick(compartmentNodes.Select(n => n.Handle).ToList());

                var compartment = td.CreateCompartment(
                    new List<List<Connection>>
                    {
                        new List<Connection>
                        {
                            new Connection(brick)
                        }
                    });

                compartment.Comment = "compartment comment";
                compartment.Update();

                var compartments = td.GetCompartments();
            }
            #endregion

            #region User Preferences

            Console.WriteLine("Changing the primary acceleration vector...");
            Units.SaveWorkingUnitsAndSetToSI();
            var accel = td.UserPreferences.GetAcceleration();
            accel.Magnitude = 9.81;
            accel.XDir = 0;
            accel.YDir = 0;
            accel.ZDir = -1;
            accel.Update();
            Units.RestoreWorkingUnits();

            #endregion

            #region Measures

            Console.WriteLine("Creating measures...");
            {
                var measure = td.CreateMeasure();
                measure.Origin = new Point3d( 0.0029, 0.4312, 0.04 );
                measure.Size = 0.01;
                measure.Update();
                td.UpdateMeasures();
                td.SnapMeasures(new List<string> { measure.Handle });
            }


            #endregion

            Console.WriteLine("Changing view to ortho left and waiting 4 seconds...");
            td.RestoreOrthoView(OrthoViews.LEFT);
            td.ZoomExtents();
            td.ZoomExtents();
            System.Threading.Thread.Sleep(4000);

            Console.WriteLine("Changing view to iso SW...");
            td.RestoreIsoView(IsoViews.SW);
            td.ZoomExtents();

            Console.WriteLine("Setting visual style...");
            td.SetVisualStyle(VisualStyles.THERMAL_PP);

            Console.WriteLine("Updating and resetting graphics...");
            td.UpdateGraphics();
            td.ResetGraphics();

            Console.WriteLine("Saving dwg file...");
            string basePathname = @"c:\temp\opentd_test";
            string outFilename = basePathname + ".dwg";
            td.SaveAs(outFilename);

            // Uncomment to quit TD:
            //td.Quit();
            
        }

        void p()
        {
            System.Windows.Forms.MessageBox.Show("pause");
        }
    }
}
