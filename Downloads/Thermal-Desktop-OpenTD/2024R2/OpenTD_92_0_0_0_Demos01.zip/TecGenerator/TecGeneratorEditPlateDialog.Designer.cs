// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

namespace OpenTDDemos
{
    partial class TecGeneratorEditPlateDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TecGeneratorEditPlateDialog));
            this.label1 = new System.Windows.Forms.Label();
            this.XmmNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.YmmNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.Thickness_mmNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.MaterialTextBox = new System.Windows.Forms.TextBox();
            this.OkButton = new System.Windows.Forms.Button();
            this.CancelButton1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.XmmNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YmmNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Thickness_mmNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(67, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "X (mm):";
            // 
            // XmmNumericUpDown
            // 
            this.XmmNumericUpDown.Location = new System.Drawing.Point(130, 14);
            this.XmmNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.XmmNumericUpDown.Name = "XmmNumericUpDown";
            this.XmmNumericUpDown.Size = new System.Drawing.Size(120, 22);
            this.XmmNumericUpDown.TabIndex = 1;
            this.XmmNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // YmmNumericUpDown
            // 
            this.YmmNumericUpDown.Location = new System.Drawing.Point(130, 44);
            this.YmmNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.YmmNumericUpDown.Name = "YmmNumericUpDown";
            this.YmmNumericUpDown.Size = new System.Drawing.Size(120, 22);
            this.YmmNumericUpDown.TabIndex = 3;
            this.YmmNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(67, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Y (mm):";
            // 
            // Thickness_mmNumericUpDown
            // 
            this.Thickness_mmNumericUpDown.Location = new System.Drawing.Point(130, 75);
            this.Thickness_mmNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.Thickness_mmNumericUpDown.Name = "Thickness_mmNumericUpDown";
            this.Thickness_mmNumericUpDown.Size = new System.Drawing.Size(120, 22);
            this.Thickness_mmNumericUpDown.TabIndex = 5;
            this.Thickness_mmNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Thickness (mm):";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(62, 109);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "Material:";
            // 
            // MaterialTextBox
            // 
            this.MaterialTextBox.Location = new System.Drawing.Point(130, 106);
            this.MaterialTextBox.Name = "MaterialTextBox";
            this.MaterialTextBox.Size = new System.Drawing.Size(120, 22);
            this.MaterialTextBox.TabIndex = 7;
            // 
            // OkButton
            // 
            this.OkButton.Location = new System.Drawing.Point(97, 153);
            this.OkButton.Name = "OkButton";
            this.OkButton.Size = new System.Drawing.Size(75, 27);
            this.OkButton.TabIndex = 8;
            this.OkButton.Text = "OK";
            this.OkButton.UseVisualStyleBackColor = true;
            this.OkButton.Click += new System.EventHandler(this.OkButton_Click);
            // 
            // CancelButton1
            // 
            this.CancelButton1.Location = new System.Drawing.Point(178, 153);
            this.CancelButton1.Name = "CancelButton1";
            this.CancelButton1.Size = new System.Drawing.Size(75, 27);
            this.CancelButton1.TabIndex = 9;
            this.CancelButton1.Text = "Cancel";
            this.CancelButton1.UseVisualStyleBackColor = true;
            this.CancelButton1.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // TecGeneratorEditPlateDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(265, 192);
            this.Controls.Add(this.CancelButton1);
            this.Controls.Add(this.OkButton);
            this.Controls.Add(this.MaterialTextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Thickness_mmNumericUpDown);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.YmmNumericUpDown);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.XmmNumericUpDown);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TecGeneratorEditPlateDialog";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Edit TEC Plate";
            ((System.ComponentModel.ISupportInitialize)(this.XmmNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YmmNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Thickness_mmNumericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown XmmNumericUpDown;
        private System.Windows.Forms.NumericUpDown YmmNumericUpDown;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown Thickness_mmNumericUpDown;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox MaterialTextBox;
        private System.Windows.Forms.Button OkButton;
        private System.Windows.Forms.Button CancelButton1;
    }
}