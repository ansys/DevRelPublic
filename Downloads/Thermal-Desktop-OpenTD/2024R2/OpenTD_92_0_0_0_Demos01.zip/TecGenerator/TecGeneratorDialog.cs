// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using System.IO;
using System.Windows.Forms;
using OpenTD;

namespace OpenTDDemos
{
    public partial class TecGeneratorDialog : Form
    {
        public TecGeneratorDialog()
        {
            InitializeComponent();
            tec = new TecSpec();
            tecPath = null;
            UpdateForm();
        }

        private void UpdateForm()
        {
            TecName = tec.Name;

            ListBox.ObjectCollection Layup = LayupListBox.Items;
            Layup.Clear();
            for (int i = tec.Stages.Count - 1; i >= 0; --i)
            {
                Layup.Add(tec.Stages[i].TopPlate);
                Layup.Add(tec.Stages[i].Couples);
            }
            Layup.Add(tec.BasePlate);

            useEpoxy = tec.useEpoxy;
            SubmodelName = tec.SubmodelName;
            LayerName = tec.LayerName;
        }
        private void UpdateTec()
        {
            tec.Name = TecName;

            // no need to update BasePlate or Stages, since Layup points to same objects

            tec.useEpoxy = useEpoxy;
            tec.SubmodelName = SubmodelName;
            tec.LayerName = LayerName;
        }

        private TecSpec tec { get; set; }
        private string tecPath
        {
            get { return _tecPath; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                    OkayToSave = false;
                _tecPath = value;
            }
        }
        private string _tecPath;

        private string TecName
        {
            get { return NameTextBox.Text; }
            set { NameTextBox.Text = value; }
        }
        private SubmodelNameData SubmodelName
        {
            get { return SubmodelTextBox.Text; }
            set { SubmodelTextBox.Text = value; }
        }
        private string LayerName
        {
            get { return LayerTextBox.Text; }
            set { LayerTextBox.Text = value; }
        }
        private bool useEpoxy
        {
            get { return EpoxyFillCheckBox.Checked; }
            set { EpoxyFillCheckBox.Checked = value; }
        }
        private object SelectedLayer
        {
            get { return LayupListBox.SelectedItem; }
        }
        private bool OkayToSave
        {
            get { return _OkayToSave; }
            set
            {
                SaveButton.Enabled = value;
                _OkayToSave = value;
            }
        }
        private bool _OkayToSave;

        private void loadTec()
        {
            try
            {
                tec = TecGenerator.Deserialize(tecPath);
                UpdateForm();
                OkayToSave = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was a problem loading '" + tecPath + "':" + ex.Message,
                    "Error loading TEC Definition", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void saveTec()
        {
            try
            {
                UpdateTec();
                TecGenerator.Serialize(tec, tecPath);
                MessageBox.Show("Saved TEC definition to '" + tecPath + "'",
                    "TEC definition saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
                OkayToSave = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("There was a problem saving '" + tecPath + "':" + ex.Message,
                    "Error saving TEC definition", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void LoadButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog d = new OpenFileDialog();
            d.Title = "Choose an xml file containing a TEC definition";
            d.Filter = @"TEC Definition XML Files|*.xml";
            if (!string.IsNullOrWhiteSpace(tecPath))
                d.InitialDirectory = Path.GetFullPath(Path.GetDirectoryName(tecPath));
            if (d.ShowDialog() == DialogResult.OK)
                tecPath = d.FileName;
            else
                return;

            loadTec();
        }

        private void SaveAsButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog d = new SaveFileDialog();
            d.Title = "Where would you like to save the TEC definition?";
            d.Filter = @"TEC definition XML Files|*.xml";
            d.AddExtension = true;
            d.DefaultExt = "xml";
            if (d.ShowDialog() == DialogResult.OK)
                tecPath = d.FileName;
            else
                return;

            saveTec();
        }

        private void MakeButton_Click(object sender, EventArgs e)
        {
            try
            {
                SubmodelName.Check();
            }
            catch (OpenTDException ex)
            {
                MessageBox.Show(ex.Message, "Problem with Submodel Name",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            if (tec.Stages.Count < 1)
            {
                MessageBox.Show("No TEC stages defined.", "Problem with TEC specification",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            ThermalDesktop td = new ThermalDesktop();
            td.Connect();

            UpdateTec();
            TecGenerator.MakeTec(td, tec, new Point3d(0,0,0));

            td.RestoreOrthoView(OrthoViews.FRONT);
            td.ZoomExtents();
        }
     

        private void AddStageButton_Click(object sender, EventArgs e)
        {
            if (tec.BasePlate == null)
                tec.BasePlate = new Plate();

            // copy the current top stage, if one exists
            if (tec.Stages.Count > 0)
                tec.Stages.Add(new Stage(tec.Stages[tec.Stages.Count - 1]));
            else
                tec.Stages.Add(new Stage());

            UpdateForm();
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            if (SelectedLayer == null)
            {
                MessageBox.Show("Please select a layer first, then click Edit");
                return;
            }

            if (SelectedLayer is Plate)
            {
                TecGeneratorEditPlateDialog edit
                    = new TecGeneratorEditPlateDialog((Plate)SelectedLayer);
                edit.StartPosition = FormStartPosition.CenterParent;
                edit.ShowDialog();
            }
            else if (SelectedLayer is Couples)
            {
                TecGeneratorEditCouplesDialog edit
                    = new TecGeneratorEditCouplesDialog((Couples)SelectedLayer);
                edit.StartPosition = FormStartPosition.CenterParent;
                edit.ShowDialog();
            }
            else
                throw new Exception("Unkonwn layer type: " + SelectedLayer.GetType());
            
            UpdateForm();
        }

        private void LayupListBox_DoubleClick(object sender, EventArgs e)
        {
            EditButton_Click(sender, e);
        }

        private void DeleteStageButton_Click(object sender, EventArgs e)
        {
            if (SelectedLayer == null)
            {
                MessageBox.Show("Please select a part of a stage first, then click Delete");
                return;
            }

            if (SelectedLayer == tec.BasePlate)
            {
                MessageBox.Show("Cannot delete baseplate.");
                return;
            }

            int SelectedStageIndex = -1;
            for (int i = 0; i < tec.Stages.Count; ++i)
            {
                if (tec.Stages[i].TopPlate == SelectedLayer)
                    SelectedStageIndex = i;
                else if (tec.Stages[i].Couples == SelectedLayer)
                    SelectedStageIndex = i;
            }

            if (SelectedStageIndex == -1)
                throw new Exception("Could not find selected stage in the TEC layup definition.");

            tec.Stages.RemoveAt(SelectedStageIndex);
            UpdateForm();
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            saveTec();
        }
    }
}
