// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System.IO;
using OpenTD;
using OpenTD.Results.Dataset;
using OpenTD.Results.Plot;

namespace OpenTDDemos.ExploringResultsExamples
{
    public class DataSetSliceExample : Example
    {
        public override string Description
        {
            get
            {
                return "A DataSetSlice is a type of DerivedDataSet. DerivedDataSets act just like DataSets, but " +
                       "instead of getting their data from a save file or CSR, they contain a list of other DataSets and combine " +
                       "that data somehow. In this example, a DataSetSlice takes a single DataSet (the ConcatenatedDataSet from another " +
                       "example) and slices it, returning only the data between 2000 s and 4000 s, even though the input DataSet contains " +
                       "7200 s of data.";
            }
        }

        public override string Name { get { return "Use a DataSetSlice to only look at data in the middle of a ConcatenatedDataset"; } }

        public override void Run()
        {
            // DatasetSlice.BeginTime and EndTime are entered in the current working units,
            // so we'll set the time units to seconds. (We'll use Save- and RestoreWorkingUnits
            // to revert back to whatever system we were in before calling this Run method.
            Units.SaveWorkingUnits();
            Units.WorkingUnits.time = UnitsData.Time.SEC;

            // create a ConcatenatedDataset that stitches together two save files:
            string resultsDir = Path.Combine(Script.WorkingDirectory, "exploringResultsSav");
            var tvac1a = DatasetFactory.Load(Path.Combine(resultsDir, "TVAC1A.sav"));
            var tvac1b = DatasetFactory.Load(Path.Combine(resultsDir, "TVAC1B.sav"));
            var tvac = new ConcatenatedDataset();
            tvac.InputDatasets.Add(tvac1a);
            tvac.InputDatasets.Add(tvac1b);

            // use a DatasetSlice to only work with a part of the ConcatenatedDataset created above:
            var tvacSlice = new DatasetSlice();
            tvacSlice.InputDatasets.Add(tvac);
            tvacSlice.BeginTime = 2000;
            tvacSlice.EndTime = 4000;

            var T = tvacSlice.GetData("AVIONICS1.T1");
            var plot = new SimplePlot();
            plot.AddSeries(T);
            plot.Show();

            Units.RestoreWorkingUnits();
        }
    }
}
