// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System.IO;
using OpenTD;
using OpenTD.Results.Dataset;
using OpenTD.Results.Plot;

namespace OpenTDDemos.ExploringResultsExamples
{
    public class SteadyState : Example
    {
        public override string Description
        {
            get
            {
                return "Plot temperatures from a steady-state Dataset. SimplePlot will" +
                    " automatically enable markers on series with only one data point.";
            }
        }

        public override string Name
        {
            get
            {
                return "Try plotting steady-state data";
            }
        }

        public override void Run()
        {
            string resultsDir = Path.Combine(Script.WorkingDirectory, "exploringResultsSav");
            var data = DatasetFactory.Load(Path.Combine(resultsDir, "steady.sav"));

            data.GetThermalSubmodels();

            var Avionics1Ts = data.GetData("AVIONICS1.T1", "AVIONICS2.T1", "AVIONICS3.T1");
            var plot = new SimplePlot();
            plot.AddSeries(Avionics1Ts);
            plot.Show();
        }
    }
}
