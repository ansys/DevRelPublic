// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System.IO;
using OpenTD;
using OpenTD.Results.Dataset;
using OpenTD.Results.Plot;

namespace OpenTDDemos.ExploringResultsExamples
{
    public class SingleNodeSingleCase : Example
    {
        public override string Description
        {
            get
            {
                return "Get node T and Q from a single case and plot in a SimplePlot with default names and formatting. " +
                       "Note that axes for different dimensions are automatically created. Data is returned from Datasets " +
                       "in the form of DataArrays, which know their dimension, keep track of units, know what Dataset they came from, " +
                       "and create suggested names for themselves. You can always override this by changing the Name property. Also " +
                       "note that only y values were added to create the series. The plot assumed we wanted time as the x data and got it " +
                       "from the correct DataSet.";
            }
        }

        public override string Name
        {
            get
            {
                return "Single node data from single case";
            }
        }

        public override void Run()
        {
            string resultsDir = Path.Combine(Script.WorkingDirectory, "exploringResultsSav");
            var beta0 = DatasetFactory.Load(Path.Combine(resultsDir, "hot_beta0.sav"));
            var TandQ = beta0.GetData("AVIONICS1.T6", "AVIONICS1.Q6");
            var plot = new SimplePlot();
            plot.AddSeries(TandQ); // will automatically use time as x data
            plot.Show();
        }
    }
}
