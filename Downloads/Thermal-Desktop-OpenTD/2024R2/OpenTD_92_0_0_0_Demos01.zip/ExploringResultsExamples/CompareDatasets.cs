// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using System.IO;
using OpenTD;
using OpenTD.Results.Dataset;
using OpenTD.UserInterface;

namespace OpenTDDemos.ExploringResultsExamples
{
    class CompareDatasets : Example
    {
        public override string Description
        {
            get
            {
                return "Use the Comparer family of classes to compare datasets.";
            }
        }

        public override string Name { get { return "Compare datasets"; } }

        public override void Run()
        {
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("***                        OpenTD Comparer Demo                       ***");
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("***   This program demonstrates how to use the OpenTD Comparer class  ***");
            Console.WriteLine("***   to compare Thermal Desktop results from save files and CSR's.   ***");
            Console.WriteLine("*************************************************************************");


            // *** Load Datasets ***
            Console.WriteLine();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("Loading datasets...");
            string resultsDir = Path.Combine(Script.WorkingDirectory, @"exploringResultsSav\comparer");

            var baseline = DatasetFactory.Load(Path.Combine(resultsDir, "baseline.sav"));
            Console.WriteLine("   Baseline save file: {0} loaded", baseline);

            var baselineCopy = DatasetFactory.Load(Path.Combine(resultsDir, "baselineCopy.sav"));
            Console.WriteLine("   A copy of baseline: {0} ", baselineCopy);

            var differentOrbit = DatasetFactory.Load(Path.Combine(resultsDir, "differentOrbit.sav"));
            Console.WriteLine("   Same as baseline, but with a different orbit: {0} ", differentOrbit);

            var missingNode = DatasetFactory.Load(Path.Combine(resultsDir, "missingNode.sav"));
            Console.WriteLine("   Same as baseline, but with a missing node: {0} ", missingNode);

            // *** Examine Comparer defaults:
            {
                Console.WriteLine();
                Console.WriteLine("*************************************************************************");
                Console.WriteLine("Set the Comparer.DataToCompare list to control what kinds of data will be compared.");
                Console.WriteLine("By default, the following types of data will be compared:");
                var dummy = new Comparer(baseline, baselineCopy);
                foreach (FullStandardDataSubtype x in dummy.DataToCompare)
                    Console.WriteLine(x);

                Console.WriteLine();
                Console.WriteLine("**********************************************************************");
                Console.WriteLine("Use the Comparer.ComparisonMethods and DefaultComparisonMethod members to control");
                Console.WriteLine("what algorithms are used to compare each type of data. By default, all types of");
                Console.WriteLine("data are compared with a simple PercentDifferenceCompareData algorithm with a");
                Console.WriteLine($"tolerance of {((PercentDifferenceCompareData)dummy.DefaultComparisonMethod).PercentTol}%");
                Console.WriteLine();
            }

            // *** use a single Comparer:
            Console.WriteLine();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("Here we'll use a single Comparer to compare baseline and baselineCopy:");
            Console.WriteLine();
            var compareBaselineToCopy = new Comparer(baseline, baselineCopy);
            if (compareBaselineToCopy.Run())
                Console.WriteLine(compareBaselineToCopy + " found datasets to be the same.");
            else
                Console.WriteLine(compareBaselineToCopy + " found datasets to be different.");
            Console.WriteLine(compareBaselineToCopy + " Message:");
            Console.WriteLine(compareBaselineToCopy.Message);

            // *** create Exceedence Plots:
            Console.WriteLine();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("Here we'll compare baseline and differentOrbit then plot exceedences:");
            Console.WriteLine();
            var compareBaselineToDifferentOrbit = new Comparer(baseline, differentOrbit);
            if (compareBaselineToDifferentOrbit.Run())
                Console.WriteLine(compareBaselineToDifferentOrbit + " found datasets to be the same.");
            else
            {
                Console.WriteLine(compareBaselineToDifferentOrbit + " found datasets to be different.");
                compareBaselineToDifferentOrbit.PlotExceedances();
            }
            Console.WriteLine(compareBaselineToDifferentOrbit + " Message:");
            Console.WriteLine(compareBaselineToDifferentOrbit.Message);

            // *** use a CompareSuite:
            Console.WriteLine();
            Console.WriteLine("*************************************************************************");
            Console.WriteLine("Use a CompareSuite to make lots of comparisons and test assertions about them:");
            Console.WriteLine();
            var compareSuite = new CompareSuite()
            {
                new CompareAssertion(baseline, baselineCopy, assertDatasetsSame: true),
                new CompareAssertion(baseline, differentOrbit, assertDatasetsSame: false),
                new CompareAssertion(baseline, missingNode, assertDatasetsSame: false),
            };
            compareSuite.Run(); // returns a Tuple<int, int> indicating successful assertions and total CompareAssertions run
            Console.WriteLine(compareSuite.Log); // or you can just read the log to see detailed info
        }
    }
}
