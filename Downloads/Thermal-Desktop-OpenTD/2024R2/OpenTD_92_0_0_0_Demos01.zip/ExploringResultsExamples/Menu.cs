// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;

namespace OpenTDDemos.ExploringResultsExamples
{
    public partial class Menu : Form
    {
        public Menu(List<Example> examples)
        {
            InitializeComponent();
            examplesAvailable = new BindingList<Example>();
            foreach (Example ex in examples)
                examplesAvailable.Add(ex);
            examplesListBox.DataSource = examplesAvailable;
        }

        string description { set { descriptionTextBox.Text = value; } }
        Example selectedExample { get { return (Example)examplesListBox.SelectedItem; } }

        BindingList<Example> examplesAvailable { get; set; }

        private void runButton_Click(object sender, EventArgs e)
        {
            selectedExample.Run();
        }

        private void examplesListBox_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            runButton_Click(sender, e);
        }

        private void examplesListBox_SelectedValueChanged(object sender, EventArgs e)
        {
            description = selectedExample.Description;
        }
    }
}
