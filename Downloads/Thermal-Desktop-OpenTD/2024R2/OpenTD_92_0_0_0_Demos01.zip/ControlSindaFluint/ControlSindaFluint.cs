// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using OpenTD;
using OpenTD.CoSolver;

namespace OpenTDDemos.ControlSindaFluint
{
    public class ControlSindaFluint : Script
    {
        public override string GetDescription()
        {
            return "Control a Sinda text-based model (similar to old COM controller)";
        }

        public override string GetName()
        {
            return "Control Sinda";
        }
        public override string GetKeywords()
        {
            return "symbol register matlab com";
        }
        public override void Run()
        {
            // We'll open the working directory in File Explorer (or other default viewer) for convenience:
            var workingDir = Path.Combine(Script.WorkingDirectory, "controlSindaFluint");
            Console.WriteLine("Opening the working directory '" + workingDir + "' in default viewer...");
            try
            {
                Process.Start(workingDir);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ignoring problem opening working directory: " + ex.Message);
            }

            // If you'd just like to run a Sinda model, use an SF_Launcher:
            string justRunPath = Path.Combine(workingDir, "justRun.inp");
            var justRunLauncher = new SF_Launcher(justRunPath);

            // SF_Launcher.Run() creates a new process to run the model. Use WaitForExit()
            // if you'd like to wait for it to finish before proceeding:
            Console.WriteLine("Running Sinda model '" + justRunPath + "'...");
            var justRunProcess = justRunLauncher.Run();
            justRunProcess.WaitForExit();
            Console.WriteLine("Done.");


            // If you'd like finer control over the Sinda run, use an SF_CoSolver:
            string controlPath = Path.Combine(workingDir, "control.inp");
            var controlCoSolver = new SF_CoSolver(controlPath);

            Console.WriteLine("Controlling Sinda model '" + controlPath + "'...");
            
            // Calling Initialize() will start the Sinda run and connect to it.
            controlCoSolver.Initialize();

            // At various points during the run, Sinda will pause and wait for
            // SF_CoSolver. In the inp file, we called
            // OPENSF just before calling TRANSIENT, so the first pause will
            // occur after the transient run has been set up. We can query
            // and modify the model here:
            // Note: there are limitations on what can be set during a Sinda
            // run. It's always okay to set register values, but you'll need
            // to be cautious setting other entities directly.
            Console.WriteLine("Paused at beginning of transient.");
            double TIMEO = controlCoSolver.GetValue("TIMEO");
            double TIMEND = controlCoSolver.GetValue("TIMEND");
            double duration = TIMEND - TIMEO;
            if (duration <= 0.0)
                throw new Exception(string.Format("TIMEND ({0}) - TIMEO ({1}) must be positive.", TIMEND, TIMEO));

            // During the run, Sinda will pause after each CouplingTimeStep.
            // This is independent of any other timestep in the Sinda model.
            int numCouplingTimesteps = 10;
            double timestep = duration / numCouplingTimesteps;
            Console.WriteLine("Setting coupling timestep to {0} for a total of {1} timesteps.", timestep, numCouplingTimesteps);
            controlCoSolver.CouplingTimeStep = timestep;

            // The input deck set a value for the register 'airtemp', but
            // we can change it if we wish:
            double oldAirtemp = controlCoSolver.GetRegisterValue("airtemp");
            double newAirtemp = 15.0;
            Console.WriteLine("Register 'airtemp' was {0}. Setting to {1}.", oldAirtemp, newAirtemp);
            controlCoSolver.SetRegisterExpression("airtemp", newAirtemp);
            Console.WriteLine("Sinda reports airtemp is now " + controlCoSolver.GetRegisterValue("airtemp"));

            // Use Continue() to tell Sinda to advance the solution to the 
            // next coupling time step, where it will pause and we can
            // query or set values. Continue() returns a code that
            // indicates the state of the solution. We'll loop until the
            // code equals -1 (Sinda disconnected) or 99 (Sinda terminating).
            // We're also going to read TIMEN and MAIN.T1. We'll wrap
            // the GetValue calls in a try/catch block since OpenTD will
            // throw an exception if we try to read these values at the
            // wrong solution states.
            int solutionState;
            do
            {
                try
                {
                    double TIMEN = controlCoSolver.GetValue("TIMEN");
                    Console.WriteLine("Pausing. TIMEN = " + TIMEN);
                    double mainT1 = controlCoSolver.GetValue("MAIN", 1, "T");
                    double mainT1allow = 280;
                    if (mainT1 > mainT1allow)
                        Console.WriteLine("MAIN.T1 exceeds " + mainT1allow);
                }
                catch { }
                solutionState = controlCoSolver.Continue();
                Console.WriteLine($"solutionState = {solutionState}");
            }
            while (solutionState != -1 && solutionState != 99);

            // Let's make sure the Sinda run has finished. We
            // can do this by querying SF_CoSolver.SindaFluintProcess:
            Console.WriteLine("Waiting for Sinda to finish...");
            int giveUpTimeMs = 10000;
            int waitTimeMs = 100;
            int waitTimeElapsedMs = 0;
            while (!controlCoSolver.SindaFluintProcess.HasExited
                && waitTimeElapsedMs < giveUpTimeMs)
            {
                Thread.Sleep(waitTimeMs);
                waitTimeElapsedMs += waitTimeMs;
            }
            if (controlCoSolver.SindaFluintProcess.HasExited)
                Console.WriteLine("Sinda has finished.");
            else
            {
                Console.WriteLine("It looks like the Sinda process is still executing.");
            }
        }
    }
}
