// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using OpenTD;

namespace OpenTDDemos
{
    public class ReducedModel : Script
    {
        public override string GetName()
        {
            return "Reduced Model";
        }
        public override string GetDescription()
        {
            return "Create reduced model from a lump/path network";
        }

        public override string GetKeywords()
        {
            return "thermal desktop results save csr sinda multiple model fluid network";
        }
        public override void Run()
        {
            Console.WriteLine("Passing control to dialog...");
            ReducedModelDialog d = new ReducedModelDialog();
            d.ShowDialog();
        }
    }
}
