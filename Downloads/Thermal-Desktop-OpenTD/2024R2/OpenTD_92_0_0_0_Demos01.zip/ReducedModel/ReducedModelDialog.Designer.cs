// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

namespace OpenTDDemos
{
    partial class ReducedModelDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReducedModelDialog));
            this.label1 = new System.Windows.Forms.Label();
            this.inputDwgTextBox = new System.Windows.Forms.TextBox();
            this.browseButton = new System.Windows.Forms.Button();
            this.openInputDwgButton = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.CopyButton = new System.Windows.Forms.Button();
            this.LumpListBox = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.PathListBox = new System.Windows.Forms.ListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.EndLumpLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.BegLumpLabel = new System.Windows.Forms.Label();
            this.ReduceButton = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.ReduceGroupBox = new System.Windows.Forms.GroupBox();
            this.ScanGroupBox = new System.Windows.Forms.GroupBox();
            this.statusStrip1.SuspendLayout();
            this.ReduceGroupBox.SuspendLayout();
            this.ScanGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Input Dwg:";
            // 
            // inputDwgTextBox
            // 
            this.inputDwgTextBox.Location = new System.Drawing.Point(92, 23);
            this.inputDwgTextBox.Name = "inputDwgTextBox";
            this.inputDwgTextBox.Size = new System.Drawing.Size(381, 22);
            this.inputDwgTextBox.TabIndex = 1;
            this.inputDwgTextBox.Text = ".\\model\\reducedModelDemo.dwg";
            // 
            // browseButton
            // 
            this.browseButton.Location = new System.Drawing.Point(479, 23);
            this.browseButton.Name = "browseButton";
            this.browseButton.Size = new System.Drawing.Size(75, 23);
            this.browseButton.TabIndex = 2;
            this.browseButton.Text = "Browse...";
            this.browseButton.UseVisualStyleBackColor = true;
            this.browseButton.Click += new System.EventHandler(this.browseButton_Click);
            // 
            // openInputDwgButton
            // 
            this.openInputDwgButton.Location = new System.Drawing.Point(112, 71);
            this.openInputDwgButton.Name = "openInputDwgButton";
            this.openInputDwgButton.Size = new System.Drawing.Size(131, 28);
            this.openInputDwgButton.TabIndex = 3;
            this.openInputDwgButton.Text = "Open Input Dwg";
            this.openInputDwgButton.UseVisualStyleBackColor = true;
            this.openInputDwgButton.Click += new System.EventHandler(this.openInputDwgButton_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 751);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(574, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // CopyButton
            // 
            this.CopyButton.Location = new System.Drawing.Point(249, 71);
            this.CopyButton.Name = "CopyButton";
            this.CopyButton.Size = new System.Drawing.Size(203, 28);
            this.CopyButton.TabIndex = 5;
            this.CopyButton.Text = "Copy Dwg To New Session";
            this.CopyButton.UseVisualStyleBackColor = true;
            this.CopyButton.Click += new System.EventHandler(this.CopyButton_Click);
            // 
            // LumpListBox
            // 
            this.LumpListBox.FormattingEnabled = true;
            this.LumpListBox.ItemHeight = 16;
            this.LumpListBox.Location = new System.Drawing.Point(7, 44);
            this.LumpListBox.Name = "LumpListBox";
            this.LumpListBox.Size = new System.Drawing.Size(244, 404);
            this.LumpListBox.TabIndex = 7;
            this.LumpListBox.SelectedValueChanged += new System.EventHandler(this.LumpListBox_SelectedValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "Lumps:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(290, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "Paths:";
            // 
            // PathListBox
            // 
            this.PathListBox.FormattingEnabled = true;
            this.PathListBox.ItemHeight = 16;
            this.PathListBox.Location = new System.Drawing.Point(293, 44);
            this.PathListBox.Name = "PathListBox";
            this.PathListBox.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.PathListBox.Size = new System.Drawing.Size(244, 404);
            this.PathListBox.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 17);
            this.label4.TabIndex = 14;
            this.label4.Text = "Begin Lump:";
            // 
            // EndLumpLabel
            // 
            this.EndLumpLabel.AutoSize = true;
            this.EndLumpLabel.Location = new System.Drawing.Point(111, 76);
            this.EndLumpLabel.Name = "EndLumpLabel";
            this.EndLumpLabel.Size = new System.Drawing.Size(126, 17);
            this.EndLumpLabel.TabIndex = 12;
            this.EndLumpLabel.Text = "Select in above list";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 76);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 17);
            this.label5.TabIndex = 15;
            this.label5.Text = "End Lump:";
            // 
            // BegLumpLabel
            // 
            this.BegLumpLabel.AutoSize = true;
            this.BegLumpLabel.Location = new System.Drawing.Point(111, 45);
            this.BegLumpLabel.Name = "BegLumpLabel";
            this.BegLumpLabel.Size = new System.Drawing.Size(126, 17);
            this.BegLumpLabel.TabIndex = 11;
            this.BegLumpLabel.Text = "Select in above list";
            // 
            // ReduceButton
            // 
            this.ReduceButton.Location = new System.Drawing.Point(56, 116);
            this.ReduceButton.Name = "ReduceButton";
            this.ReduceButton.Size = new System.Drawing.Size(134, 28);
            this.ReduceButton.TabIndex = 16;
            this.ReduceButton.Text = "Reduce Section";
            this.ReduceButton.UseVisualStyleBackColor = true;
            this.ReduceButton.Click += new System.EventHandler(this.ReduceButton_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(158, 17);
            this.label6.TabIndex = 13;
            this.label6.Text = "Define reduced section:";
            // 
            // ReduceGroupBox
            // 
            this.ReduceGroupBox.Controls.Add(this.label6);
            this.ReduceGroupBox.Controls.Add(this.label4);
            this.ReduceGroupBox.Controls.Add(this.ReduceButton);
            this.ReduceGroupBox.Controls.Add(this.EndLumpLabel);
            this.ReduceGroupBox.Controls.Add(this.BegLumpLabel);
            this.ReduceGroupBox.Controls.Add(this.label5);
            this.ReduceGroupBox.Location = new System.Drawing.Point(15, 588);
            this.ReduceGroupBox.Name = "ReduceGroupBox";
            this.ReduceGroupBox.Size = new System.Drawing.Size(298, 158);
            this.ReduceGroupBox.TabIndex = 17;
            this.ReduceGroupBox.TabStop = false;
            // 
            // ScanGroupBox
            // 
            this.ScanGroupBox.Controls.Add(this.label3);
            this.ScanGroupBox.Controls.Add(this.PathListBox);
            this.ScanGroupBox.Controls.Add(this.label2);
            this.ScanGroupBox.Controls.Add(this.LumpListBox);
            this.ScanGroupBox.Location = new System.Drawing.Point(15, 114);
            this.ScanGroupBox.Name = "ScanGroupBox";
            this.ScanGroupBox.Size = new System.Drawing.Size(545, 468);
            this.ScanGroupBox.TabIndex = 18;
            this.ScanGroupBox.TabStop = false;
            // 
            // ReducedModelDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(574, 773);
            this.Controls.Add(this.ScanGroupBox);
            this.Controls.Add(this.ReduceGroupBox);
            this.Controls.Add(this.CopyButton);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.openInputDwgButton);
            this.Controls.Add(this.browseButton);
            this.Controls.Add(this.inputDwgTextBox);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ReducedModelDialog";
            this.Text = "Reduced Model Demo";
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ReduceGroupBox.ResumeLayout(false);
            this.ReduceGroupBox.PerformLayout();
            this.ScanGroupBox.ResumeLayout(false);
            this.ScanGroupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox inputDwgTextBox;
        private System.Windows.Forms.Button browseButton;
        private System.Windows.Forms.Button openInputDwgButton;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Button CopyButton;
        private System.Windows.Forms.ListBox LumpListBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox PathListBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label EndLumpLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label BegLumpLabel;
        private System.Windows.Forms.Button ReduceButton;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox ReduceGroupBox;
        private System.Windows.Forms.GroupBox ScanGroupBox;
    }
}