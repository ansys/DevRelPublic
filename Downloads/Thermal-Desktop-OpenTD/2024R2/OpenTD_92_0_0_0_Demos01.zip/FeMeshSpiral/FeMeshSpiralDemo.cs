// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using OpenTD;

namespace OpenTDDemos.FeMeshSpiral
{
    public class FeMeshSpiralDemo : Script
    {
        public override string GetName()
        {
            return "Finite Element Mesh Spiral";
        }
        public override string GetDescription()
        {
            return "Create a coil of curved finite element surface and solids.";
        }
        public override string GetKeywords()
        {
            return "finite element fem mesh";
        }
        public override void Run()
        {
            FeMeshSpiralDialog d = new FeMeshSpiralDialog();
            d.ShowDialog();
        }
    }
}