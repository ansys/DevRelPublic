// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System.Collections.Generic;
using OpenTD;

namespace OpenTDDemos
{
    public struct TrussData
    {
        public double Length;
        public double Width;
        public int numSections;
        public Point3d origin;
        public int StartingNodeNum;
        public string Submodel;
    }

    public static class TrussMaker
    {
        public static void MakeTruss(ThermalDesktop td, TrussData truss)
        {
            double sectionLength = truss.Length / truss.numSections;

            List<Node> nodes = new List<Node>();
            int numNodes = (truss.numSections + 1) * 4;
            for (int i = 0; i < numNodes; ++i)
            {
                nodes.Add(td.CreateNode());
                nodes[i].Submodel = "truss";
                nodes[i].Id = i + 1;
            }
            for (int i = 0; i < numNodes; i += 4)
            {
                nodes[i].Origin = truss.origin;
                nodes[i + 1].Origin = truss.origin + new Point3d(truss.Width, 0, 0);
                nodes[i + 2].Origin = truss.origin + new Point3d(truss.Width, truss.Width, 0);
                nodes[i + 3].Origin = truss.origin + new Point3d(0, truss.Width, 0);
                truss.origin += new Point3d(0, 0, sectionLength);
            }

            foreach (Node node in nodes)
                node.Update();

            for (int i = 0; i < truss.numSections + 1; ++i)
            {
                // horizontal conductors
                for (int j = 0; j < 4; ++j)
                {
                    Conductor c;
                    if (j != 3)
                        c = td.CreateConductor(nodes[i * 4 + j], nodes[i * 4 + j + 1]);
                    else // need to close loop
                        c = td.CreateConductor(nodes[i * 4 + j], nodes[i * 4 + 0]);
                    c.Submodel = "truss";
                    c.Update();
                }

                // vertical and diagonal conductors
                if (i < truss.numSections)
                {
                    for (int j = 0; j < 4; ++j)
                    {
                        Conductor c = td.CreateConductor(nodes[i * 4 + j], nodes[(i + 1) * 4 + j]);
                        c.Submodel = "truss";
                        c.Update();
                    }

                    for (int j = 0; j < 4; ++j)
                    {
                        Conductor c; 
                        if (j != 3)
                            c = td.CreateConductor(nodes[i * 4 + j], nodes[(i + 1) * 4 + j + 1]);
                        else
                            c = td.CreateConductor(nodes[i * 4 + j], nodes[(i + 1) * 4 + 0]);
                        c.Submodel = "truss";
                        c.Update();
                    }
                }
            }
        }
    }
}
