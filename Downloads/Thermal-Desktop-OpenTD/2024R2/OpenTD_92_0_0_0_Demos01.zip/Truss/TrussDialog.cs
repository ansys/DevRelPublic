// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using OpenTD;

namespace OpenTDDemos
{
    public partial class TrussDialog : Form
    {
        public TrussDialog()
        {
            InitializeComponent();
            td = null;
        }

        public ThermalDesktop td { get; set; }

        public double TrussLength
        {
            get { return (double)lengthNumericUpDown.Value; }
            set { lengthNumericUpDown.Value = (decimal)value; }
        }
        public double TrussWidth
        {
            get { return (double)widthNumericUpDown.Value; }
            set { widthNumericUpDown.Value = (decimal)value; }
        }
        public int NumSections
        {
            get { return (int)numSectionsNumericUpDown.Value; }
            set { numSectionsNumericUpDown.Value = value; }
        }

        private void makeTrussButton_Click(object sender, EventArgs e)
        {
            if (td == null) return;

            DeleteModel();

            TrussData truss;
            truss.Length = TrussLength;
            truss.Width = TrussWidth;
            truss.numSections = NumSections;
            truss.origin = new Point3d(0, 0, 0);
            truss.Submodel = "truss";
            truss.StartingNodeNum = 1;
            TrussMaker.MakeTruss(td, truss);

            td.RestoreIsoView(IsoViews.SW);
            td.SetVisualStyle(VisualStyles.THERMAL_PP);
        }

        private void DeleteModel()
        {
            // delete existing nodes and conductors:
            List<Node> nodes = td.GetNodes();
            foreach (Node node in nodes)
                td.DeleteEntity(node);
            td.UpdateGraphics();
        }

        private void TrussDialog_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (td != null)
                try { DeleteModel(); } catch { }
        }
    }
}
