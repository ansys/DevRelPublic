// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

namespace OpenTDDemos
{
    partial class ControlTdDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ControlTdDialog));
            this.DwgTextBox = new System.Windows.Forms.TextBox();
            this.OpenDwgButton = new System.Windows.Forms.Button();
            this.BrowseButton = new System.Windows.Forms.Button();
            this.SymbolsLabel = new System.Windows.Forms.Label();
            this.SymbolsListBox = new System.Windows.Forms.ListBox();
            this.CasesLabel = new System.Windows.Forms.Label();
            this.CasesListBox = new System.Windows.Forms.ListBox();
            this.RunButton = new System.Windows.Forms.Button();
            this.ExecuteTextBox = new System.Windows.Forms.TextBox();
            this.ExecuteButton = new System.Windows.Forms.Button();
            this.SaveButton = new System.Windows.Forms.Button();
            this.CloseButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // DwgTextBox
            // 
            this.DwgTextBox.Location = new System.Drawing.Point(105, 20);
            this.DwgTextBox.Name = "DwgTextBox";
            this.DwgTextBox.Size = new System.Drawing.Size(418, 22);
            this.DwgTextBox.TabIndex = 0;
            // 
            // OpenDwgButton
            // 
            this.OpenDwgButton.Location = new System.Drawing.Point(12, 18);
            this.OpenDwgButton.Name = "OpenDwgButton";
            this.OpenDwgButton.Size = new System.Drawing.Size(87, 27);
            this.OpenDwgButton.TabIndex = 1;
            this.OpenDwgButton.Text = "Open Dwg";
            this.OpenDwgButton.UseVisualStyleBackColor = true;
            this.OpenDwgButton.Click += new System.EventHandler(this.OpenDwgButton_Click);
            // 
            // BrowseButton
            // 
            this.BrowseButton.Location = new System.Drawing.Point(529, 18);
            this.BrowseButton.Name = "BrowseButton";
            this.BrowseButton.Size = new System.Drawing.Size(87, 27);
            this.BrowseButton.TabIndex = 2;
            this.BrowseButton.Text = "Browse...";
            this.BrowseButton.UseVisualStyleBackColor = true;
            this.BrowseButton.Click += new System.EventHandler(this.BrowseButton_Click);
            // 
            // SymbolsLabel
            // 
            this.SymbolsLabel.AutoSize = true;
            this.SymbolsLabel.Location = new System.Drawing.Point(9, 69);
            this.SymbolsLabel.Name = "SymbolsLabel";
            this.SymbolsLabel.Size = new System.Drawing.Size(221, 17);
            this.SymbolsLabel.TabIndex = 3;
            this.SymbolsLabel.Text = "Symbols: (double-click to change)";
            // 
            // SymbolsListBox
            // 
            this.SymbolsListBox.FormattingEnabled = true;
            this.SymbolsListBox.ItemHeight = 16;
            this.SymbolsListBox.Location = new System.Drawing.Point(12, 89);
            this.SymbolsListBox.Name = "SymbolsListBox";
            this.SymbolsListBox.Size = new System.Drawing.Size(282, 324);
            this.SymbolsListBox.TabIndex = 4;
            this.SymbolsListBox.DoubleClick += new System.EventHandler(this.SymbolsListBox_DoubleClick);
            // 
            // CasesLabel
            // 
            this.CasesLabel.AutoSize = true;
            this.CasesLabel.Location = new System.Drawing.Point(331, 69);
            this.CasesLabel.Name = "CasesLabel";
            this.CasesLabel.Size = new System.Drawing.Size(51, 17);
            this.CasesLabel.TabIndex = 5;
            this.CasesLabel.Text = "Cases:";
            // 
            // CasesListBox
            // 
            this.CasesListBox.FormattingEnabled = true;
            this.CasesListBox.ItemHeight = 16;
            this.CasesListBox.Location = new System.Drawing.Point(334, 89);
            this.CasesListBox.Name = "CasesListBox";
            this.CasesListBox.Size = new System.Drawing.Size(282, 324);
            this.CasesListBox.TabIndex = 6;
            // 
            // RunButton
            // 
            this.RunButton.Location = new System.Drawing.Point(528, 419);
            this.RunButton.Name = "RunButton";
            this.RunButton.Size = new System.Drawing.Size(88, 26);
            this.RunButton.TabIndex = 7;
            this.RunButton.Text = "Run Case";
            this.RunButton.UseVisualStyleBackColor = true;
            this.RunButton.Click += new System.EventHandler(this.RunButton_Click);
            // 
            // ExecuteTextBox
            // 
            this.ExecuteTextBox.Location = new System.Drawing.Point(228, 485);
            this.ExecuteTextBox.Name = "ExecuteTextBox";
            this.ExecuteTextBox.Size = new System.Drawing.Size(388, 22);
            this.ExecuteTextBox.TabIndex = 8;
            // 
            // ExecuteButton
            // 
            this.ExecuteButton.Location = new System.Drawing.Point(12, 482);
            this.ExecuteButton.Name = "ExecuteButton";
            this.ExecuteButton.Size = new System.Drawing.Size(210, 28);
            this.ExecuteButton.TabIndex = 9;
            this.ExecuteButton.Text = "Execute Autocad Command:";
            this.ExecuteButton.UseVisualStyleBackColor = true;
            this.ExecuteButton.Click += new System.EventHandler(this.ExecuteButton_Click);
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(399, 545);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(91, 29);
            this.SaveButton.TabIndex = 10;
            this.SaveButton.Text = "Save Dwg";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // CloseButton
            // 
            this.CloseButton.Location = new System.Drawing.Point(496, 545);
            this.CloseButton.Name = "CloseButton";
            this.CloseButton.Size = new System.Drawing.Size(120, 29);
            this.CloseButton.TabIndex = 11;
            this.CloseButton.Text = "Close Autocad";
            this.CloseButton.UseVisualStyleBackColor = true;
            this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
            // 
            // MatlabTdComReplacementDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 587);
            this.Controls.Add(this.CloseButton);
            this.Controls.Add(this.SaveButton);
            this.Controls.Add(this.ExecuteButton);
            this.Controls.Add(this.ExecuteTextBox);
            this.Controls.Add(this.RunButton);
            this.Controls.Add(this.CasesListBox);
            this.Controls.Add(this.CasesLabel);
            this.Controls.Add(this.SymbolsListBox);
            this.Controls.Add(this.SymbolsLabel);
            this.Controls.Add(this.BrowseButton);
            this.Controls.Add(this.OpenDwgButton);
            this.Controls.Add(this.DwgTextBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MatlabTdComReplacementDialog";
            this.Text = "MATLAB TD COM Replacement";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox DwgTextBox;
        private System.Windows.Forms.Button OpenDwgButton;
        private System.Windows.Forms.Button BrowseButton;
        private System.Windows.Forms.Label SymbolsLabel;
        private System.Windows.Forms.ListBox SymbolsListBox;
        private System.Windows.Forms.Label CasesLabel;
        private System.Windows.Forms.ListBox CasesListBox;
        private System.Windows.Forms.Button RunButton;
        private System.Windows.Forms.TextBox ExecuteTextBox;
        private System.Windows.Forms.Button ExecuteButton;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button CloseButton;
    }
}