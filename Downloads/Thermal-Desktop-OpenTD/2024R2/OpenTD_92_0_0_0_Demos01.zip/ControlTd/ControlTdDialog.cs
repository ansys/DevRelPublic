// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using System.IO;
using System.Windows.Forms;
using OpenTD;

namespace OpenTDDemos
{
    public partial class ControlTdDialog : Form
    {
        public ControlTdDialog()
        {
            InitializeComponent();
            EnableOpenMode();
        }

        private ThermalDesktop td { get; set; }
        private string DwgPathname { get { return DwgTextBox.Text; } set { DwgTextBox.Text = value; } }
        private string ExecuteCommand { get { return ExecuteTextBox.Text; } set { ExecuteTextBox.Text = value; } }

        private void BrowseButton_Click(object sender, EventArgs e)
        {
            BrowseForDwg();
        }

        private void BrowseForDwg()
        {
            OpenFileDialog d = new OpenFileDialog();
            d.Filter = @"TD drawing files|*.dwg";
            try { d.InitialDirectory = Path.GetFullPath(Path.GetDirectoryName(DwgPathname)); }
            catch { }
            if (d.ShowDialog() == DialogResult.OK)
                DwgPathname = d.FileName;
        }

        private void OpenDwgButton_Click(object sender, EventArgs e)
        {
            if (!File.Exists(DwgPathname))
                BrowseForDwg();
            if (!File.Exists(DwgPathname))
            {
                MessageBox.Show("Dwg pathname not valid.", "Problem Opening dwg",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            try
            {
                td = new ThermalDesktop(DwgPathname);
                td.Connect();
                RefreshLists();
                EnableEditMode();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Problem Opening dwg",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void RefreshLists()
        {
            ClearLists();
            foreach (Symbol symbol in td.GetSymbols())
                SymbolsListBox.Items.Add(symbol);
            foreach (CaseSet caseSet in td.GetCaseSets())
                CasesListBox.Items.Add(caseSet);
        }

        private void ExecuteButton_Click(object sender, EventArgs e)
        {
            td.SendCommand(ExecuteCommand + "\n");
        }

        private void SymbolsListBox_DoubleClick(object sender, EventArgs e)
        {
            Symbol symbol = (Symbol)SymbolsListBox.SelectedItem;
            ControlTdSymbolDialog d = new ControlTdSymbolDialog(td, symbol);
            d.Show();
        }

        private void RunButton_Click(object sender, EventArgs e)
        {
            CaseSet caseSet = (CaseSet)CasesListBox.SelectedItem;
            caseSet.Run();
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            td.SaveAs(DwgPathname);
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            td.Quit();
            EnableOpenMode();
        }

        private void ClearLists()
        {
            SymbolsListBox.Items.Clear();
            CasesListBox.Items.Clear();
        }

        private void EnableEditMode()
        {
            SymbolsLabel.Enabled = true;
            SymbolsListBox.Enabled = true;
            CasesLabel.Enabled = true;
            CasesListBox.Enabled = true;
            RunButton.Enabled = true;
            ExecuteButton.Enabled = true;
            SaveButton.Enabled = true;
            CloseButton.Enabled = true;

            OpenDwgButton.Enabled = false;
            DwgTextBox.Enabled = false;
            BrowseButton.Enabled = false;
        }

        private void EnableOpenMode()
        {
            SymbolsLabel.Enabled = false;
            SymbolsListBox.Enabled = false;
            CasesLabel.Enabled = false;
            CasesListBox.Enabled = false;
            RunButton.Enabled = false;
            ExecuteButton.Enabled = false;
            SaveButton.Enabled = false;
            CloseButton.Enabled = false;

            OpenDwgButton.Enabled = true;
            DwgTextBox.Enabled = true;
            BrowseButton.Enabled = true;

            ClearLists();
        }
    }
}
