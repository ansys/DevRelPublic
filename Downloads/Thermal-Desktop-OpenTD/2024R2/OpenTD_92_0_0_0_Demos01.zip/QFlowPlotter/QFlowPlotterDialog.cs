// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using OpenTD.Results.Dataset;
using OpenTD.Results.Dataset.Topology;
using OpenTD.Results.Plot;
using OpenTD;

namespace OpenTDDemos.QFlowPlotter
{
    public partial class QFlowPlotterDialog : Form
    {

        IDataset saveData;
        List<long> recNums = new List<long>();
        string pcsPathname;

        ThermalDesktop td;

        public QFlowPlotterDialog()
        {
            InitializeComponent();
        }

        private void openSave_Click(object sender, EventArgs e)
        {

            string sav = @"qflowplotter.sav";
            string savPathname = Path.Combine(Script.WorkingDirectory, sav);
            if (!File.Exists(savPathname))
            {
                MessageBox.Show("Could not find " + sav + " in directory " + Script.WorkingDirectory);
                return;
            }

            string pcs = @"qflowplotter.savPCS";
            pcsPathname = Path.Combine(Script.WorkingDirectory, pcs);
            if (!File.Exists(pcsPathname))
            {
                MessageBox.Show("Could not find " + pcs + " in directory " + Script.WorkingDirectory);
                return;
            }

            try { saveData = DatasetFactory.Load(savPathname); }
            catch { saveData = null; return; }

            LoadSubmodels(listBoxFrom);
            LoadSubmodels(listBoxTo);

            recNums = saveData.GetRecordNumbers();

            label1.Enabled = true;
            label2.Enabled = true;               
            listBoxFrom.Enabled = true;
            listBoxTo.Enabled = true;
            plotButton.Enabled = true;            
        }

        private void LoadSubmodels(ListBox lb)
        {
            lb.Items.Clear();
            if (saveData == null) return;
            foreach (var z in saveData.GetThermalSubmodels()) lb.Items.Add(z);
        }

        private void plotButton_Click(object sender, EventArgs e)
        {
            if (listBoxFrom.SelectedItem == null) return;
            if (listBoxTo.SelectedItem == null) return;
            if (listBoxFrom.SelectedItem.ToString() == listBoxTo.SelectedItem.ToString())
            {
                MessageBox.Show("Please select two unique submodels.");
                return;
            }
            DataArray time = saveData.GetTimes();
            DataArray linearHeatDA;
            DataArray radiativeHeatDA;
            DataArray totalHeatDA;


            List<double> totalHeat = new List<double>();
            List<double> linearHeat = new List<double>();
            List<double> radiativeHeat = new List<double>();

            IDatasetTopology pcsNetwork;
            IBrowser browser;


            pcsNetwork = DatasetTopology.Load(saveData, recNums.First(), pcsPathname);
            long lastPCSRecNum = saveData.GetNpcsrec(recNums.First());

            foreach (var recNum in saveData.GetRecordNumbers())
            {
                long curPCSRecNum = saveData.GetNpcsrec(recNum);
                if (lastPCSRecNum != curPCSRecNum)
                {
                    pcsNetwork = DatasetTopology.Load(saveData, recNum, pcsPathname);
                    lastPCSRecNum = curPCSRecNum;
                }

                browser = Browser.Create(saveData, pcsNetwork, recNum);
                HeatratesBetween hrBetween = browser.GetHeatBetweenSubmodels(listBoxFrom.SelectedItem.ToString(), listBoxTo.SelectedItem.ToString());
                totalHeat.Add(hrBetween.TotalHeatrate);
                linearHeat.Add(hrBetween.LinearHeatrate);
                radiativeHeat.Add(hrBetween.RadiativeHeatrate);
            }
            linearHeatDA = new DataArray(StandardDataSubtypes.HR, linearHeat, Units.WorkingUnits);
            linearHeatDA.Name = "Linear heat";
            radiativeHeatDA = new DataArray(StandardDataSubtypes.HR, radiativeHeat, Units.WorkingUnits);
            radiativeHeatDA.Name = "Radiative heat";
            totalHeatDA = new DataArray(StandardDataSubtypes.HR, totalHeat, Units.WorkingUnits);
            totalHeatDA.Name = "Total heat";

            SimplePlot heatflowplot = new SimplePlot("Heat flow from " + listBoxFrom.SelectedItem.ToString() + " to " + listBoxTo.SelectedItem.ToString());
            heatflowplot.AddSeries(time, linearHeatDA);
            heatflowplot.AddSeries(time, radiativeHeatDA);
            heatflowplot.AddSeries(time, totalHeatDA);
            heatflowplot.Show();

        }

        private void openTdButton_Click(object sender, EventArgs e)
        {
            string dwg = @"QFlowPlotterModel.dwg";
            string dwgPathname = Path.Combine(Script.WorkingDirectory, dwg);
            if (!File.Exists(dwgPathname))
            {
                MessageBox.Show("Could not find " + dwg + " in directory " + Script.WorkingDirectory);
                return;
            }
            td = new ThermalDesktop(dwgPathname);            
            td.Connect();            
        }

        private void QFlowPlotterDialog_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (td != null)
                try { td.Quit(); } catch { }
        }
    }
}
