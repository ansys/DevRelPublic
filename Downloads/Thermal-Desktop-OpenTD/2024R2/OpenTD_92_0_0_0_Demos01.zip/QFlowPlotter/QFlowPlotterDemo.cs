// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using OpenTD;

namespace OpenTDDemos.QFlowPlotter
{
    public class QFlowPlotterDemo : Script
    {
        public override string GetName()
        {
            return "QFlow Plotter";
        }
        public override string GetDescription()
        {
            return "Read model topology from results and plot heat flows between submodels";
        }

        public override string GetKeywords()
        {
            return "postprocessing post-processing contour results save csr datasets topology pcs heat flow qflow";
        }
        public override void Run()
        {
            QFlowPlotterDialog d = new QFlowPlotterDialog();
            d.ShowDialog();
        }
    }
}