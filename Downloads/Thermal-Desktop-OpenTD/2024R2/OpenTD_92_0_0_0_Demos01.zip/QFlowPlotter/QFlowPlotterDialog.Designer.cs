// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

namespace OpenTDDemos.QFlowPlotter
{
    partial class QFlowPlotterDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openSave = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.listBoxFrom = new System.Windows.Forms.ListBox();
            this.listBoxTo = new System.Windows.Forms.ListBox();
            this.plotButton = new System.Windows.Forms.Button();
            this.openTdButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // openSave
            // 
            this.openSave.Location = new System.Drawing.Point(9, 14);
            this.openSave.Margin = new System.Windows.Forms.Padding(2);
            this.openSave.Name = "openSave";
            this.openSave.Size = new System.Drawing.Size(160, 31);
            this.openSave.TabIndex = 0;
            this.openSave.Text = "Open Save File";
            this.openSave.UseVisualStyleBackColor = true;
            this.openSave.Click += new System.EventHandler(this.openSave_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Enabled = false;
            this.label1.Location = new System.Drawing.Point(9, 57);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select From submodel";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Enabled = false;
            this.label2.Location = new System.Drawing.Point(191, 57);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Select To submodel";
            // 
            // listBoxFrom
            // 
            this.listBoxFrom.FormattingEnabled = true;
            this.listBoxFrom.Location = new System.Drawing.Point(9, 78);
            this.listBoxFrom.Margin = new System.Windows.Forms.Padding(2);
            this.listBoxFrom.Name = "listBoxFrom";
            this.listBoxFrom.Size = new System.Drawing.Size(161, 251);
            this.listBoxFrom.TabIndex = 3;
            // 
            // listBoxTo
            // 
            this.listBoxTo.FormattingEnabled = true;
            this.listBoxTo.Location = new System.Drawing.Point(194, 78);
            this.listBoxTo.Margin = new System.Windows.Forms.Padding(2);
            this.listBoxTo.Name = "listBoxTo";
            this.listBoxTo.Size = new System.Drawing.Size(161, 251);
            this.listBoxTo.TabIndex = 4;
            // 
            // plotButton
            // 
            this.plotButton.Location = new System.Drawing.Point(194, 344);
            this.plotButton.Margin = new System.Windows.Forms.Padding(2);
            this.plotButton.Name = "plotButton";
            this.plotButton.Size = new System.Drawing.Size(160, 37);
            this.plotButton.TabIndex = 5;
            this.plotButton.Text = "Plot Heat Flow";
            this.plotButton.UseVisualStyleBackColor = true;
            this.plotButton.Click += new System.EventHandler(this.plotButton_Click);
            // 
            // openTdButton
            // 
            this.openTdButton.Location = new System.Drawing.Point(194, 14);
            this.openTdButton.Margin = new System.Windows.Forms.Padding(2);
            this.openTdButton.Name = "openTdButton";
            this.openTdButton.Size = new System.Drawing.Size(160, 31);
            this.openTdButton.TabIndex = 6;
            this.openTdButton.Text = "Open Model (for reference)";
            this.openTdButton.UseVisualStyleBackColor = true;
            this.openTdButton.Click += new System.EventHandler(this.openTdButton_Click);
            // 
            // QFlowPlotterDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 395);
            this.Controls.Add(this.openTdButton);
            this.Controls.Add(this.plotButton);
            this.Controls.Add(this.listBoxTo);
            this.Controls.Add(this.listBoxFrom);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.openSave);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "QFlowPlotterDialog";
            this.ShowIcon = false;
            this.Text = "QFlow Plotter";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.QFlowPlotterDialog_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button openSave;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBoxFrom;
        private System.Windows.Forms.ListBox listBoxTo;
        private System.Windows.Forms.Button plotButton;
        private System.Windows.Forms.Button openTdButton;
    }
}