// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using OpenTD;

namespace OpenTDDemos.Snake
{
    public class SnakeDemo : Script
    {
        public override string GetDescription()
        {
            return "Play a classic game using FD Solids";
        }

        public override string GetName()
        {
            return "Snake";
        }

        public override string GetKeywords()
        {
            return "finite difference fd solid basetrans localtrans matrix position transform geometry game";
        }

        public override void Run()
        {
            SnakeDialog d = new SnakeDialog();
            d.ShowDialog();
        }
    }
}
