// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using OpenTD;
using OpenTD.Dimension;
using OpenTD.RadCAD.FdSolid;

namespace OpenTDDemos.Snake
{
    class Snake
    {
        public Snake(Board _board, Position startPos, int startBodyLength, int color = 4)
        {
            board = _board;
            td = board.td;

            if (!board.IsWithinBoard(startPos))
                throw new Exception("Snake start position is not within board.");

            if (startBodyLength < 1)
                startBodyLength = 1;
            BodyLength = startBodyLength;
            MaxBodyLength = (int)(0.9 * (board.GridNumU * board.GridNumV));

            ColorIndex = color;

            segmentSize = board.GridSize;

            headPosition = startPos;
            head = DrawSegment(headPosition);
            body = new Queue<SolidBrick>();
            bodyPositions = new Queue<Position>();

            LastTimeMovedms = 0;
            LastTimeSpedUpms = 0;
            Dead = false;
        }

        ~Snake()
        {
            Delete();
        }
        public void Delete()
        {
            try
            {
                td.DeleteEntity(head);
            }
            catch { }
            try
            {
                foreach (SolidBrick segment in body)
                    td.DeleteEntity(segment);
            }
            catch { }
            body.Clear();
            bodyPositions.Clear();
        }

        public void OnTick(object sender, TickEventArgs e)
        {
            long t = e.TotalElapsedTime_ms;

            if (t - LastTimeMovedms >= MovePeriodms)
            {
                Move();
                LastTimeMovedms = t;
            }

            if (t - LastTimeSpedUpms >= SpeedUpPeriodms)
            {
                SpeedUp();
                LastTimeSpedUpms = t;
            }
        }

        public void Move(Directions direction)
        {
            Position oldHeadPosition = headPosition;
            Position newHeadPosition = oldHeadPosition + direction;

            if (!board.IsWithinBoard(newHeadPosition))
            {
                Dead = true;
                return;
            }
            else if (IsInSnake(newHeadPosition))
            {
                Dead = true;
                return;
            }
            else if (board.PelletPosition.Equals(newHeadPosition))
            {
                if (++BodyLength > MaxBodyLength)
                    BodyLength = MaxBodyLength;
                if (AtePellet != null)
                {
                    AtePellet(this, new EventArgs());
                }
            }

            headPosition = newHeadPosition;

            Point3d oldHeadCoords = head.BaseTrans.GetOrigin();

            head.BaseTrans.SetOrigin(board.GetCoordinates(headPosition));
            head.Update();

            body.Enqueue(DrawSegment(oldHeadCoords));
            bodyPositions.Enqueue(oldHeadPosition);

            if (body.Count >= BodyLength)
            {
                td.DeleteEntity(body.Dequeue());
                bodyPositions.Dequeue();
            }

            td.UpdateGraphics();
        }

        public void Move()
        {
            Move(Facing);
        }

        public bool IsInSnake(Position pos)
        {
            if (headPosition.Equals(pos))
                return true;
            return bodyPositions.Any(bodyPos => bodyPos.Equals(pos));
        }

        SolidBrick DrawSegment(Point3d origin)
        {
            var segment = td.CreateSolidBrick();
            segment.XMax = segmentSize;
            segment.YMax = segmentSize;
            segment.ZMax = segmentSize;
            segment.BaseTrans.SetCoordSystem(
                origin,
                board.Right,
                board.Up,
                board.Normal);
            segment.ColorIndex = ColorIndex;
            segment.Update();
            return segment;
        }

        SolidBrick DrawSegment(Position pos)
        {
            return DrawSegment(board.GetCoordinates(pos));
        }

        public Directions Facing { get; set; }

        /// <summary>
        /// Number of ms between moves
        /// </summary>
        public long MovePeriodms { get; set; }
        public long LastTimeMovedms { get; set; }

        /// <summary>
        /// Speed up snake periodically
        /// </summary>
        public long SpeedUpPeriodms { get; set; }
        public long SpeedUpAmountms { get; set; }
        public long MinMovePeriodms { get; set; }
        public long LastTimeSpedUpms { get; set; }

        public void SpeedUp()
        {
            if (MovePeriodms - SpeedUpAmountms >= MinMovePeriodms)
                MovePeriodms -= SpeedUpAmountms;
            else
                MovePeriodms = MinMovePeriodms;
        }

        public EventHandler AtePellet;

        public int BodyLength { get; set; }
        int MaxBodyLength { get; set; }
        public bool Dead { get; private set; }

        public Position headPosition { get; private set; }
        public Queue<Position> bodyPositions { get; private set; }

        int ColorIndex { get; set; }
        SolidBrick head { get; set; }
        Queue<SolidBrick> body { get; set; }
        Dimensional<ModelLength> segmentSize { get; set; }

        Board board { get; set; }
        ThermalDesktop td { get; set; }
    }
}
