// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;

namespace OpenTDDemos.Snake
{
    struct Position
    {
        public Position(int u, int v)
        {
            U = u;
            V = v;
        }
        public int U;
        public int V;

        public static Position operator +(Position pos, Directions direction)
        {
            switch (direction)
            {
                case Directions.UP:
                    return new Position(pos.U, pos.V + 1);
                case Directions.DOWN:
                    return new Position(pos.U, pos.V - 1);
                case Directions.LEFT:
                    return new Position(pos.U - 1, pos.V);
                case Directions.RIGHT:
                    return new Position(pos.U + 1, pos.V);
                default:
                    throw new Exception("Unknown direction: '" + direction + "'.");
            }
        }
    }

    class PositionEventArgs : EventArgs
    {
        public PositionEventArgs(Position _pos)
        {
            pos = _pos;
        }
        public Position pos { get; set; }
    }
}
