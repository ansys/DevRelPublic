// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using OpenTD;
using OpenTD.RadCAD.FdSolid;

namespace OpenTDDemos.Marquee
{
    class SolidUpperY : SolidCharacter
    {
        public SolidUpperY(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height)
        {
            DrawUpright();
            DrawLeft();
            DrawRight();
        }

        const double angleDeg = 35;
        const double angleRad = angleDeg * Math.PI / 180;

        SolidBrick Upright;
        SolidBrick Left;
        SolidBrick Right;

        void DrawUpright()
        {
            Upright = TD.CreateSolidBrick();
            Upright.ColorIndex = ColorIndex;
            Upright.XMax = Thickness;
            Upright.ZMax = Thickness;
            Upright.YMax = 0.5 * Height;
            Upright.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(0.5 * (Width-Thickness), 0, 0));
            Upright.BaseTrans.PostMultBy(trans);

            Upright.Update();
        }

        void DrawLeft()
        {
            Left = TD.CreateSolidBrick();
            Left.XMax = Thickness;
            Left.ZMax = Thickness;
            Left.YMax = Height / 2 / Math.Cos(angleRad);
            Left.BaseTrans = new Matrix3d(CS);

            Matrix3d trans = new Matrix3d();
            trans.SetToRotZ(angleDeg);
            trans.SetOrigin(new Point3d(0.5 * (Width - Thickness) + Thickness - Thickness * Math.Cos(angleRad), 0.5 * Height - Thickness * Math.Sin(angleRad), 0));
            Left.BaseTrans.PostMultBy(trans);
            Left.ColorIndex = ColorIndex;
            Left.Update();
        }

        void DrawRight()
        {
            Right = TD.CreateSolidBrick();
            Right.XMax = Thickness;
            Right.ZMax = Thickness;
            Right.YMax = Height / 2 / Math.Cos(angleRad);
            Right.BaseTrans = new Matrix3d(CS);

            Matrix3d trans = new Matrix3d();
            trans.SetToRotZ(-angleDeg);
            trans.SetOrigin(new Point3d(0.5 * (Width - Thickness), 0.5 * Height, 0));
            Right.BaseTrans.PostMultBy(trans);
            Right.ColorIndex = ColorIndex;
            Right.Update();
        }

        public override double Width => 0.82787 * Height;

        public override void Delete()
        {
            TD.DeleteEntity(Upright);
            TD.DeleteEntity(Left);
            TD.DeleteEntity(Right);
        }
    }
}
