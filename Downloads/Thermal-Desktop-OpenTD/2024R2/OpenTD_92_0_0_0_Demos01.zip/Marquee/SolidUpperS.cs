// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using OpenTD;
using OpenTD.RadCAD.FdSolid;

namespace OpenTDDemos.Marquee
{
    class SolidUpperS : SolidCharacter
    {
        public SolidUpperS(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height)
        {
            DrawUpperCyl();
            DrawLowerCyl();
        }

        SolidCylinder UpperCyl;
        SolidCylinder LowerCyl;

        double Rmax => 0.25 * (Thickness + Height);

        void DrawUpperCyl()
        {
            UpperCyl = TD.CreateSolidCylinder();
            UpperCyl.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(Rmax, Height - Rmax, 0));
            UpperCyl.BaseTrans.PostMultBy(trans);
            UpperCyl.Height = Thickness;
            UpperCyl.Rmax = Rmax;
            UpperCyl.Rmin = UpperCyl.Rmax -  Thickness;
            UpperCyl.StartAngle = 30;
            UpperCyl.EndAngle = 270;
            UpperCyl.ColorIndex = ColorIndex;
            UpperCyl.Update();
        }

        void DrawLowerCyl()
        {
            LowerCyl = TD.CreateSolidCylinder();
            LowerCyl.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(Rmax, Rmax, 0));
            LowerCyl.BaseTrans.PostMultBy(trans);
            LowerCyl.Height = Thickness;
            LowerCyl.Rmax = Rmax;
            LowerCyl.Rmin = LowerCyl.Rmax -  Thickness;
            LowerCyl.StartAngle = 210;
            LowerCyl.EndAngle = 90;
            LowerCyl.ColorIndex = ColorIndex;
            LowerCyl.Update();
        }

        public override double Width => 2 * Rmax;

        public override void Delete()
        {
            TD.DeleteEntity(UpperCyl);
            TD.DeleteEntity(LowerCyl);
        }
    }
}
