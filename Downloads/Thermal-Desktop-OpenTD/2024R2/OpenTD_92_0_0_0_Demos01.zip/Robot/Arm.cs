// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System.Collections.Generic;
using OpenTD;
using OpenTD.Dimension;
using OpenTD.RadCAD;

namespace OpenTDDemos.Robot
{
    public class Arm : IRobotPart
    {
        public Arm(ThermalDesktop tdInstance)
        {
            Units.SaveWorkingUnitsAndSetToSI();
            try
            {
                double upperArmLengthM = 0.5;
                double upperArmWidthM = 0.2;
                double lowerArmLengthM = 0.5;
                double lowerArmWidthM = 0.15;

                td = tdInstance;

                lowerArm = td.CreateRectangle();
                lowerArm.YMax = lowerArmLengthM;
                lowerArm.XMax = lowerArmWidthM;
                lowerArm.BaseTrans.SetToRotX(90); // align with elbow z-axis
                lowerArm.BaseTrans.SetOrigin(new Point3d(-lowerArmWidthM/2, 0, 0)); // align with elbow temporary position
                lowerArm.Update();

                elbow = td.CreateAssembly(new Point3d(0, 0, 0));
                elbow.AxisSize = 0.1;
                elbow.DisplayBaseCS = false;
                elbow.AttachedObjectHandles.Add(lowerArm.Handle);
                elbow.BaseTrans.SetOrigin(new Point3d(0, 0, upperArmLengthM)); // move elbow to end of upper arm
                elbow.Update();

                upperArm = td.CreateRectangle();
                upperArm.YMax = upperArmLengthM;
                upperArm.XMax = upperArmWidthM;
                upperArm.BaseTrans.SetToRotX(90);
                upperArm.BaseTrans.SetOrigin(new Point3d(-upperArmWidthM / 2, 0, 0)); // align with shoulder position
                upperArm.Update();

                shoulder = td.CreateAssembly(new Point3d(0, 0, 0));
                shoulder.AxisSize = 0.1;
                shoulder.DisplayBaseCS = false;
                shoulder.AttachedObjectHandles.AddRange(new List<string> { upperArm.Handle, elbow.Handle });

                Update();
            }
            finally
            {
                Units.RestoreWorkingUnits();
            }
        }

        public Matrix3d BaseTrans
        {
            get
            {
                if (shoulder != null)
                    return shoulder.BaseTrans;
                else
                    return null;
            }
        }

        public Transformation LocalTrans
        {
            get
            {
                if (shoulder != null)
                    return shoulder.LocalTrans;
                else
                    return null;
            }
        }

        public string Handle { get { return shoulder.Handle; } }

        public List<string> AttachedObjectHandles { get { return shoulder.AttachedObjectHandles; } }

        public void Update()
        {
            shoulder.Update();
            lowerArm.UpdateFromTD();
            elbow.UpdateFromTD();
            upperArm.UpdateFromTD();
            shoulder.UpdateFromTD();
        }

        public void UpdateFromTD()
        {
            lowerArm.UpdateFromTD();
            elbow.UpdateFromTD();
            upperArm.UpdateFromTD();
            shoulder.UpdateFromTD();
        }
        
        public double ShoulderPitchDeg
        {
            get
            {
                shoulder.UpdateFromTD();
                return shoulder.LocalTrans.Rot2;
            }
            set
            {
                shoulder.UpdateFromTD();
                shoulder.LocalTrans.Axis2 = 0; // second rotation is x-axis
                shoulder.LocalTrans.Rot2 = value;
                shoulder.Update();
                td.UpdateGraphics();
            }
        }

        public double ShoulderYawDeg
        {
            get
            {
                shoulder.UpdateFromTD();
                return shoulder.LocalTrans.Rot1;
            }
            set
            {
                shoulder.UpdateFromTD();
                shoulder.LocalTrans.Axis1 = 1; // first rotation is y-axis
                shoulder.LocalTrans.Rot1 = value;
                shoulder.Update();
                td.UpdateGraphics();
            }
        }

        public Dimensional<ModelLength> UpperArmLength
        {
            get
            {
                upperArm.UpdateFromTD();
                return upperArm.YMax;
            }
        }

        public Dimensional<ModelLength> UpperArmWidth
        {
            get
            {
                upperArm.UpdateFromTD();
                return upperArm.XMax;
            }
        }

        public double ElbowPitchDeg
        {
            get
            {
                elbow.UpdateFromTD();
                return elbow.LocalTrans.Rot1;
            }
            set
            {
                elbow.UpdateFromTD();
                elbow.LocalTrans.Axis1 = 0; // x-axis
                elbow.LocalTrans.Rot1 = value;
                elbow.Update();
                td.UpdateGraphics();
            }
        }

        public Dimensional<ModelLength> LowerArmLength
        {
            get
            {
                lowerArm.UpdateFromTD();
                return lowerArm.YMax;
            }
        }

        public Dimensional<ModelLength> LowerArmWidth
        {
            get
            {
                lowerArm.UpdateFromTD();
                return lowerArm.XMax;
            }
        }

        public void Delete()
        {
            td.DeleteEntity(shoulder);
            td.DeleteEntity(upperArm);
            td.DeleteEntity(elbow);
            td.DeleteEntity(lowerArm);
        }

        ThermalDesktop td { get; set; }
        Assembly shoulder { get; set; }
        Rectangle upperArm { get; set; }
        Assembly elbow { get; set; }
        Rectangle lowerArm { get; set; }



    }
}
