namespace OpenTDv242Demos.CompartmentCreator
{
    partial class CompartmentCreatorDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openModel = new System.Windows.Forms.Button();
            this.groupBoxSettings = new System.Windows.Forms.GroupBox();
            this.textBoxVoidFraction = new System.Windows.Forms.TextBox();
            this.textBoxAirTemp = new System.Windows.Forms.TextBox();
            this.textBoxWaterTemp = new System.Windows.Forms.TextBox();
            this.trackBarVoidFraction = new System.Windows.Forms.TrackBar();
            this.trackBarAirTemp = new System.Windows.Forms.TrackBar();
            this.trackBarWaterTemp = new System.Windows.Forms.TrackBar();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonCreateUpdate = new System.Windows.Forms.Button();
            this.groupBoxSettings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarVoidFraction)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarAirTemp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarWaterTemp)).BeginInit();
            this.SuspendLayout();
            // 
            // openModel
            // 
            this.openModel.Location = new System.Drawing.Point(9, 8);
            this.openModel.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.openModel.Name = "openModel";
            this.openModel.Size = new System.Drawing.Size(111, 25);
            this.openModel.TabIndex = 0;
            this.openModel.Text = "Open TD Model";
            this.openModel.UseVisualStyleBackColor = true;
            this.openModel.Click += new System.EventHandler(this.openModel_Click);
            // 
            // groupBoxSettings
            // 
            this.groupBoxSettings.Controls.Add(this.textBoxVoidFraction);
            this.groupBoxSettings.Controls.Add(this.textBoxAirTemp);
            this.groupBoxSettings.Controls.Add(this.textBoxWaterTemp);
            this.groupBoxSettings.Controls.Add(this.trackBarVoidFraction);
            this.groupBoxSettings.Controls.Add(this.trackBarAirTemp);
            this.groupBoxSettings.Controls.Add(this.trackBarWaterTemp);
            this.groupBoxSettings.Controls.Add(this.label3);
            this.groupBoxSettings.Controls.Add(this.label2);
            this.groupBoxSettings.Controls.Add(this.label1);
            this.groupBoxSettings.Enabled = false;
            this.groupBoxSettings.Location = new System.Drawing.Point(9, 46);
            this.groupBoxSettings.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBoxSettings.Name = "groupBoxSettings";
            this.groupBoxSettings.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBoxSettings.Size = new System.Drawing.Size(301, 272);
            this.groupBoxSettings.TabIndex = 1;
            this.groupBoxSettings.TabStop = false;
            this.groupBoxSettings.Text = "Compartment Settings";
            // 
            // textBoxVoidFraction
            // 
            this.textBoxVoidFraction.Location = new System.Drawing.Point(225, 42);
            this.textBoxVoidFraction.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxVoidFraction.Name = "textBoxVoidFraction";
            this.textBoxVoidFraction.ReadOnly = true;
            this.textBoxVoidFraction.Size = new System.Drawing.Size(58, 20);
            this.textBoxVoidFraction.TabIndex = 8;
            this.textBoxVoidFraction.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxAirTemp
            // 
            this.textBoxAirTemp.Location = new System.Drawing.Point(118, 42);
            this.textBoxAirTemp.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxAirTemp.Name = "textBoxAirTemp";
            this.textBoxAirTemp.ReadOnly = true;
            this.textBoxAirTemp.Size = new System.Drawing.Size(58, 20);
            this.textBoxAirTemp.TabIndex = 7;
            this.textBoxAirTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxWaterTemp
            // 
            this.textBoxWaterTemp.Location = new System.Drawing.Point(11, 42);
            this.textBoxWaterTemp.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.textBoxWaterTemp.Name = "textBoxWaterTemp";
            this.textBoxWaterTemp.ReadOnly = true;
            this.textBoxWaterTemp.Size = new System.Drawing.Size(58, 20);
            this.textBoxWaterTemp.TabIndex = 6;
            this.textBoxWaterTemp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // trackBarVoidFraction
            // 
            this.trackBarVoidFraction.Location = new System.Drawing.Point(233, 62);
            this.trackBarVoidFraction.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.trackBarVoidFraction.Maximum = 90;
            this.trackBarVoidFraction.Minimum = 3;
            this.trackBarVoidFraction.Name = "trackBarVoidFraction";
            this.trackBarVoidFraction.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBarVoidFraction.Size = new System.Drawing.Size(45, 200);
            this.trackBarVoidFraction.TabIndex = 5;
            this.trackBarVoidFraction.Value = 5;
            this.trackBarVoidFraction.ValueChanged += new System.EventHandler(this.trackBarVoidFraction_ValueChanged);
            // 
            // trackBarAirTemp
            // 
            this.trackBarAirTemp.Location = new System.Drawing.Point(127, 62);
            this.trackBarAirTemp.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.trackBarAirTemp.Maximum = 95;
            this.trackBarAirTemp.Minimum = 5;
            this.trackBarAirTemp.Name = "trackBarAirTemp";
            this.trackBarAirTemp.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBarAirTemp.Size = new System.Drawing.Size(45, 200);
            this.trackBarAirTemp.TabIndex = 4;
            this.trackBarAirTemp.Value = 35;
            this.trackBarAirTemp.ValueChanged += new System.EventHandler(this.trackBarAirTemp_ValueChanged);
            // 
            // trackBarWaterTemp
            // 
            this.trackBarWaterTemp.Location = new System.Drawing.Point(20, 62);
            this.trackBarWaterTemp.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.trackBarWaterTemp.Maximum = 95;
            this.trackBarWaterTemp.Minimum = 5;
            this.trackBarWaterTemp.Name = "trackBarWaterTemp";
            this.trackBarWaterTemp.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBarWaterTemp.Size = new System.Drawing.Size(45, 200);
            this.trackBarWaterTemp.TabIndex = 3;
            this.trackBarWaterTemp.Value = 20;
            this.trackBarWaterTemp.ValueChanged += new System.EventHandler(this.trackBarWaterTemp_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(220, 24);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Initial Fill (%)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(113, 24);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Air Temp (C)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 24);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Water Temp (C)";
            // 
            // buttonCreateUpdate
            // 
            this.buttonCreateUpdate.Enabled = false;
            this.buttonCreateUpdate.Location = new System.Drawing.Point(137, 322);
            this.buttonCreateUpdate.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.buttonCreateUpdate.Name = "buttonCreateUpdate";
            this.buttonCreateUpdate.Size = new System.Drawing.Size(173, 46);
            this.buttonCreateUpdate.TabIndex = 2;
            this.buttonCreateUpdate.Text = "Create/Update Compartment";
            this.buttonCreateUpdate.UseVisualStyleBackColor = true;
            this.buttonCreateUpdate.Click += new System.EventHandler(this.buttonCreateUpdate_Click);
            // 
            // CompartmentCreatorDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(329, 381);
            this.Controls.Add(this.buttonCreateUpdate);
            this.Controls.Add(this.groupBoxSettings);
            this.Controls.Add(this.openModel);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "CompartmentCreatorDialog";
            this.Text = "Compartment Creator";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CompartmentCreatorDialog_FormClosing);
            this.groupBoxSettings.ResumeLayout(false);
            this.groupBoxSettings.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarVoidFraction)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarAirTemp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarWaterTemp)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button openModel;
        private System.Windows.Forms.GroupBox groupBoxSettings;
        private System.Windows.Forms.TextBox textBoxVoidFraction;
        private System.Windows.Forms.TextBox textBoxAirTemp;
        private System.Windows.Forms.TextBox textBoxWaterTemp;
        private System.Windows.Forms.TrackBar trackBarVoidFraction;
        private System.Windows.Forms.TrackBar trackBarAirTemp;
        private System.Windows.Forms.TrackBar trackBarWaterTemp;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonCreateUpdate;
    }
}