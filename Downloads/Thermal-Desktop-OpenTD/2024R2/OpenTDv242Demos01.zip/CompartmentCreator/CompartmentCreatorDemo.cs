using OpenTDv242;

namespace OpenTDv242Demos.CompartmentCreator
{
    public class CompartmentCreatorDemo : Script
    {
        public override string GetName()
        {
            return "Compartment Creator";
        }
        public override string GetDescription()
        {
            return "Create or update compartment using existing finite element geometry";
        }
        public override string GetKeywords()
        {
            return "flocad fluint";
        }
        public override void Run()
        {
            CompartmentCreatorDialog d = new CompartmentCreatorDialog();
            d.ShowDialog();
        }
    }
}