using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Forms;
using OpenTDv242;
using OpenTDv242.FloCAD;
using OpenTDv242.Results.Dataset;

namespace OpenTDv242Demos
{
    public partial class ReducedModelTuneDialog : Form
    {
        public ReducedModelTuneDialog(
            ThermalDesktop tdin, ThermalDesktop tdout,
            Lump beg, Lump end,
            Path reduced,
            string WorkingDirectory)
        {
            InitializeComponent();
            tdIn = tdin;
            tdOut = tdout;
            BeginLump = beg;
            EndLump = end;
            ReducedPath = reduced;

            WorkingDir = WorkingDirectory;
            ResultsDirIn = System.IO.Path.GetFullPath(System.IO.Path.Combine(WorkingDirectory, "Full"));
            ResultsDirOut = System.IO.Path.GetFullPath(System.IO.Path.Combine(WorkingDirectory, "Reduced"));

            try
            {
                cases = new BindingList<CaseSet>(tdOut.GetCaseSets());
            }
            catch
            {
                // todo: how to handle this?
            }

            numIterations = 5;
            currentIteration = -1;

            RefreshLabels();
        }

        private string Output { set { toolStripStatusLabel1.Text = value; } }

        private ThermalDesktop tdIn;
        private ThermalDesktop tdOut;
        private CaseSet caseSetIn;
        private CaseSet caseSetOut;
        private Lump BeginLump;
        private Lump EndLump;
        private Path ReducedPath;

        private BindingList<CaseSet> cases
        {
            get
            {
                return (BindingList<CaseSet>)CaseSetsListBox.DataSource;
            }
            set
            {
                CaseSetsListBox.DataSource = value;
            }
        }

        private CaseSet caseSet;
        private string WorkingDir;
        private string ResultsDirIn;
        private string ResultsDirOut;
        private string SaveFilename
        {
            get
            {
                if (caseSet != null)
                    return caseSet.SindaOptions.SaveFilename;
                else
                    return null;
            }
        }
        private string SavePathIn
        {
            get
            {
                if (SaveFilename != null)
                    return System.IO.Path.Combine(ResultsDirIn, SaveFilename);
                else
                    return null;
            }
        }
        private string SavePathOut
        {
            get
            {
                if (SaveFilename != null)
                    return System.IO.Path.Combine(ResultsDirOut, SaveFilename);
                else
                    return null;
            }
        }
        private SaveFile dataIn;
        private SaveFile dataOut;
        private double PinBeg
        {
            get
            {
                if (dataIn != null)
                {
                    var sindaName = string.Format("{0}.PL{1}", BeginLump.Submodel, BeginLump.Id);
                    List<double> pressures = dataIn.GetData(sindaName)[0];
                    if (pressures.Any())
                        return pressures.Last();
                    else
                        return -1e23;
                }
                else
                    return -1e23;
            }
        }
        private double PinEnd
        {
            get
            {
                if (dataIn != null)
                {
                    var sindaName = string.Format("{0}.PL{1}", EndLump.Submodel, EndLump.Id);
                    List<double> pressures = dataIn.GetData(sindaName)[0];
                    if (pressures.Any())
                        return pressures.Last();
                    else
                        return -1e23;
                }
                else
                    return -1e23;
            }
        }
        private double PoutBeg
        {
            get
            {
                if (dataOut != null)
                {
                    var sindaName = string.Format("{0}.PL{1}", BeginLump.Submodel, BeginLump.Id);
                    List<double> pressures = dataOut.GetData(sindaName)[0];
                    if (pressures.Any())
                        return pressures.Last();
                    else
                        return -1e23;
                }
                else
                    return -1e23;
            }
        }
        private double PoutEnd
        {
            get
            {
                if (dataOut != null)
                {
                    var sindaName = string.Format("{0}.PL{1}", EndLump.Submodel, EndLump.Id);
                    List<double> pressures = dataOut.GetData(sindaName)[0];
                    if (pressures.Any())
                        return pressures.Last();
                    else
                        return -1e23;
                }
                else
                    return -1e23;
            }
        }

        private int numIterations;
        private int currentIteration;
        private List<double> FlowAreas = new List<double>();
        private List<double> Objectives = new List<double>();

        private void TuneButton_Click(object sender, EventArgs e)
        {
            TuneButton.Enabled = false;

            caseSet = (CaseSet)CaseSetsListBox.SelectedItem;

            SetSolutionPaths();
            Output = "Running full model...";
            try
            {
                RunCaseIn();
            }
            catch (Exception ex)
            {
                Output = "Problem running full model: " + ex.Message;
                TuneButton.Enabled = true;
                return;
            }
            RefreshLabels();
            
            double maxAf = 10*GetMaxFlowArea(tdIn);
            double minAf = 0.1*GetMinFlowArea(tdIn);
            Output = "Trying random flow areas between " + minAf.ToString("E2") + " and " + maxAf.ToString("E2");
            Random rand = new Random();

            for (currentIteration = 0; currentIteration < numIterations; ++currentIteration)
            {
                double flowArea = minAf + (maxAf - minAf) * rand.NextDouble();
                ReducedPath.FlowArea = flowArea;
                ReducedPath.Update();
                Output = "Trying flow area = " + flowArea;
                try
                {
                    RunCaseOut();
                }
                catch (Exception ex)
                {
                    Output = "Problem running reduced model: " + ex.Message;
                    TuneButton.Enabled = true;
                    return;
                }
                FlowAreas.Add(flowArea);
                Objectives.Add(GetObjective());
                RefreshLabels();
            }
            currentIteration = -1;

            // find best iteration (Objective closest to 0.0) and re-run it:
            int minIndex = Objectives.IndexOf(Objectives.Min());
            double tunedFlowArea = FlowAreas[minIndex];
            ReducedPath.FlowArea = tunedFlowArea;
            ReducedPath.Update();
            Output = "Re-running with tuned flow area = " + tunedFlowArea;
            try
            {
                RunCaseOut();
            }
            catch (Exception ex)
            {
                Output = "Problem running reduced model: " + ex.Message;
                TuneButton.Enabled = true;
                return;
            }
            RefreshLabels();

            TuneButton.Enabled = true;
        }

        private double GetObjective()
        {
            // sum of squared error
            return Math.Pow(PinBeg - PoutBeg, 2) + Math.Pow(PinEnd - PoutEnd, 2);
        }

        private double GetMaxFlowArea(ThermalDesktop td)
        {
            List<Path> paths = td.GetPaths();
            double Af = 0.0;
            foreach (Path path in paths)
            {
                if (path.FlowArea > Af)
                    Af = path.FlowArea;
            }
            return Af;
        }

        private double GetMinFlowArea(ThermalDesktop td)
        {
            List<Path> paths = td.GetPaths();
            double Af = 1e23;
            foreach (Path path in paths)
            {
                if (path.FlowArea < Af)
                    Af = path.FlowArea;
            }
            return Af;
        }

        private void SetSolutionPaths()
        {
            if (!System.IO.Directory.Exists(ResultsDirIn))
                System.IO.Directory.CreateDirectory(ResultsDirIn);
            if (!System.IO.Directory.Exists(ResultsDirOut))
                System.IO.Directory.CreateDirectory(ResultsDirOut);

            caseSetIn = tdIn.GetCaseSet(caseSet.Name);
            caseSetOut = tdOut.GetCaseSet(caseSet.Name);

            caseSetIn.UseUserDirectory = 1;
            caseSetOut.UseUserDirectory = 1;
            caseSetIn.UserDirectory = ResultsDirIn;
            caseSetOut.UserDirectory = ResultsDirOut;
            caseSetIn.Update();
            caseSetOut.Update();
        }

        private void RunCaseIn()
        {
            if (dataIn != null)
                dataIn.Close();
            caseSetIn.Run();
            if (dataIn != null)
                dataIn.ReOpen();
            else
                dataIn = new SaveFile(SavePathIn);
        }

        private void RunCaseOut()
        {
            if (dataOut != null)
                dataOut.Close();
            caseSetOut.Run();
            if (dataOut != null)
                dataOut.ReOpen();
            else
                dataOut = new SaveFile(SavePathOut);
        }

        private void RefreshLabels()
        {
            BeginLumpLabel.Text = BeginLump.ToString();
            EndLumpLabel.Text = EndLump.ToString();

            if (caseSet != null)
                CaseLabel.Text = caseSet.ToString();

            if (PinBeg > -1e22)
                PinBegLabel.Text = PinBeg.ToString("E2");
            else
                PinBegLabel.Text = "TBD";

            if (PinEnd > -1e22)
                PinEndLabel.Text = PinEnd.ToString("E2");
            else
                PinEndLabel.Text = "TBD";

            if (PoutBeg > -1e22)
                PoutBegLabel.Text = PoutBeg.ToString("E2");
            else
                PoutBegLabel.Text = "TBD";

            if (PoutEnd > -1e22)
                PoutEndLabel.Text = PoutEnd.ToString("E2");
            else
                PoutEndLabel.Text = "TBD";

            if (currentIteration != -1)
                iterationLabel.Text = (currentIteration + 1).ToString();
            else
                iterationLabel.Text = "TBD";
        }
    }
}
