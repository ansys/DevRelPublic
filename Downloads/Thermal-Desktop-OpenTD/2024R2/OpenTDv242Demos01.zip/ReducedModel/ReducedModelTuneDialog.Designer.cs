namespace OpenTDv242Demos
{
    partial class ReducedModelTuneDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReducedModelTuneDialog));
            this.BeginLumpLabel = new System.Windows.Forms.Label();
            this.EndLumpLabel = new System.Windows.Forms.Label();
            this.ResultsGroupBox = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.CaseLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.CaseSetsListBox = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TuneButton = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.PinBegLabel = new System.Windows.Forms.Label();
            this.PinEndLabel = new System.Windows.Forms.Label();
            this.PoutEndLabel = new System.Windows.Forms.Label();
            this.PoutBegLabel = new System.Windows.Forms.Label();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.label7 = new System.Windows.Forms.Label();
            this.iterationLabel = new System.Windows.Forms.Label();
            this.ResultsGroupBox.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // BeginLumpLabel
            // 
            this.BeginLumpLabel.AutoSize = true;
            this.BeginLumpLabel.Location = new System.Drawing.Point(129, 110);
            this.BeginLumpLabel.Name = "BeginLumpLabel";
            this.BeginLumpLabel.Size = new System.Drawing.Size(36, 17);
            this.BeginLumpLabel.TabIndex = 0;
            this.BeginLumpLabel.Text = "TBD";
            // 
            // EndLumpLabel
            // 
            this.EndLumpLabel.AutoSize = true;
            this.EndLumpLabel.Location = new System.Drawing.Point(129, 154);
            this.EndLumpLabel.Name = "EndLumpLabel";
            this.EndLumpLabel.Size = new System.Drawing.Size(36, 17);
            this.EndLumpLabel.TabIndex = 1;
            this.EndLumpLabel.Text = "TBD";
            // 
            // ResultsGroupBox
            // 
            this.ResultsGroupBox.Controls.Add(this.iterationLabel);
            this.ResultsGroupBox.Controls.Add(this.label7);
            this.ResultsGroupBox.Controls.Add(this.PoutEndLabel);
            this.ResultsGroupBox.Controls.Add(this.PoutBegLabel);
            this.ResultsGroupBox.Controls.Add(this.PinEndLabel);
            this.ResultsGroupBox.Controls.Add(this.PinBegLabel);
            this.ResultsGroupBox.Controls.Add(this.label6);
            this.ResultsGroupBox.Controls.Add(this.label5);
            this.ResultsGroupBox.Controls.Add(this.label4);
            this.ResultsGroupBox.Controls.Add(this.label3);
            this.ResultsGroupBox.Controls.Add(this.CaseLabel);
            this.ResultsGroupBox.Controls.Add(this.label1);
            this.ResultsGroupBox.Controls.Add(this.EndLumpLabel);
            this.ResultsGroupBox.Controls.Add(this.BeginLumpLabel);
            this.ResultsGroupBox.Location = new System.Drawing.Point(20, 242);
            this.ResultsGroupBox.Name = "ResultsGroupBox";
            this.ResultsGroupBox.Size = new System.Drawing.Size(802, 195);
            this.ResultsGroupBox.TabIndex = 2;
            this.ResultsGroupBox.TabStop = false;
            this.ResultsGroupBox.Text = "Results";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(569, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(168, 17);
            this.label6.TabIndex = 7;
            this.label6.Text = "Reduced Model Pressure";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(291, 70);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 17);
            this.label5.TabIndex = 6;
            this.label5.Text = "Full Model Pressure";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 154);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "End Lump:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Begin Lump:";
            // 
            // CaseLabel
            // 
            this.CaseLabel.AutoSize = true;
            this.CaseLabel.Location = new System.Drawing.Point(84, 35);
            this.CaseLabel.Name = "CaseLabel";
            this.CaseLabel.Size = new System.Drawing.Size(36, 17);
            this.CaseLabel.TabIndex = 3;
            this.CaseLabel.Text = "TBD";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Case:";
            // 
            // CaseSetsListBox
            // 
            this.CaseSetsListBox.FormattingEnabled = true;
            this.CaseSetsListBox.ItemHeight = 16;
            this.CaseSetsListBox.Location = new System.Drawing.Point(29, 42);
            this.CaseSetsListBox.Name = "CaseSetsListBox";
            this.CaseSetsListBox.Size = new System.Drawing.Size(238, 164);
            this.CaseSetsListBox.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(26, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Case Sets:";
            // 
            // TuneButton
            // 
            this.TuneButton.Location = new System.Drawing.Point(282, 180);
            this.TuneButton.Name = "TuneButton";
            this.TuneButton.Size = new System.Drawing.Size(182, 26);
            this.TuneButton.TabIndex = 5;
            this.TuneButton.Text = "Tune Reduced Model";
            this.TuneButton.UseVisualStyleBackColor = true;
            this.TuneButton.Click += new System.EventHandler(this.TuneButton_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 459);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(840, 22);
            this.statusStrip1.SizingGrip = false;
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // PinBegLabel
            // 
            this.PinBegLabel.AutoSize = true;
            this.PinBegLabel.Location = new System.Drawing.Point(333, 110);
            this.PinBegLabel.Name = "PinBegLabel";
            this.PinBegLabel.Size = new System.Drawing.Size(36, 17);
            this.PinBegLabel.TabIndex = 8;
            this.PinBegLabel.Text = "TBD";
            // 
            // PinEndLabel
            // 
            this.PinEndLabel.AutoSize = true;
            this.PinEndLabel.Location = new System.Drawing.Point(333, 154);
            this.PinEndLabel.Name = "PinEndLabel";
            this.PinEndLabel.Size = new System.Drawing.Size(36, 17);
            this.PinEndLabel.TabIndex = 9;
            this.PinEndLabel.Text = "TBD";
            // 
            // PoutEndLabel
            // 
            this.PoutEndLabel.AutoSize = true;
            this.PoutEndLabel.Location = new System.Drawing.Point(631, 154);
            this.PoutEndLabel.Name = "PoutEndLabel";
            this.PoutEndLabel.Size = new System.Drawing.Size(36, 17);
            this.PoutEndLabel.TabIndex = 11;
            this.PoutEndLabel.Text = "TBD";
            // 
            // PoutBegLabel
            // 
            this.PoutBegLabel.AutoSize = true;
            this.PoutBegLabel.Location = new System.Drawing.Point(631, 110);
            this.PoutBegLabel.Name = "PoutBegLabel";
            this.PoutBegLabel.Size = new System.Drawing.Size(36, 17);
            this.PoutBegLabel.TabIndex = 10;
            this.PoutBegLabel.Text = "TBD";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 17);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(659, 18);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 17);
            this.label7.TabIndex = 12;
            this.label7.Text = "Iteration:";
            // 
            // iterationLabel
            // 
            this.iterationLabel.AutoSize = true;
            this.iterationLabel.Location = new System.Drawing.Point(728, 18);
            this.iterationLabel.Name = "iterationLabel";
            this.iterationLabel.Size = new System.Drawing.Size(36, 17);
            this.iterationLabel.TabIndex = 13;
            this.iterationLabel.Text = "TBD";
            // 
            // ReducedModelTuneDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(840, 481);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.TuneButton);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.CaseSetsListBox);
            this.Controls.Add(this.ResultsGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ReducedModelTuneDialog";
            this.Text = "Tune Reduced Model";
            this.ResultsGroupBox.ResumeLayout(false);
            this.ResultsGroupBox.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label BeginLumpLabel;
        private System.Windows.Forms.Label EndLumpLabel;
        private System.Windows.Forms.GroupBox ResultsGroupBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label CaseLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox CaseSetsListBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button TuneButton;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.Label PoutEndLabel;
        private System.Windows.Forms.Label PoutBegLabel;
        private System.Windows.Forms.Label PinEndLabel;
        private System.Windows.Forms.Label PinBegLabel;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.Label iterationLabel;
        private System.Windows.Forms.Label label7;
    }
}