using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using OpenTDv242;
using OpenTDv242.FloCAD;
using OpenTDv242.Utility;

namespace OpenTDv242Demos
{
    public partial class ReducedModelDialog : Form
    {
        public ReducedModelDialog()
        {
            InitializeComponent();
            CopyButton.Enabled = false;
            ScanGroupBox.Enabled = false;
            SetLumpBegin = true;
            firstSelectedLump = true;
            ReduceGroupBox.Enabled = false;
            ReduceButton.Enabled = false;
            InputDwg = System.IO.Path.Combine(Script.WorkingDirectory, @"reducedModelDemo.dwg");
        }

        private ThermalDesktop tdIn;
        private ThermalDesktop tdOut;

        private string InputDwg { get { return inputDwgTextBox.Text; } set { inputDwgTextBox.Text = value; } }
        private string InputDwgDir { get { return System.IO.Path.GetDirectoryName(InputDwg); } }
        private string InputDwgFullPath { get { return System.IO.Path.GetFullPath(InputDwg); } }
        private string Output { set { toolStripStatusLabel1.Text = value; } }
        private BindingList<Lump> lumps
        {
            get
            {
                return (BindingList<Lump>)LumpListBox.DataSource;
            }
            set
            {
                LumpListBox.DataSource = value;
            }
        }
        private BindingList<OpenTDv242.FloCAD.Path> paths
        {
            get
            {
                return (BindingList<OpenTDv242.FloCAD.Path>)PathListBox.DataSource;
            }
            set
            {
                PathListBox.DataSource = value;
            }
        }
        private Lump lumpBegin;
        private Lump lumpEnd;
        private bool SetLumpBegin;
        private bool firstSelectedLump;

        private void browseButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog d = new OpenFileDialog();
            d.Filter = @"TD Models|*.dwg";
            d.InitialDirectory = System.IO.Path.GetDirectoryName(InputDwg);
            if (d.ShowDialog() == DialogResult.OK)
                InputDwg = d.FileName;
        }

        private void openInputDwgButton_Click(object sender, EventArgs e)
        {
            if (!System.IO.File.Exists(InputDwg))
            {
                Output = "Could not find " + InputDwg;
                return;
            }

            tdIn = new ThermalDesktop(InputDwg);
            tdIn.Connect();

            inputDwgTextBox.Enabled = false;
            browseButton.Enabled = false;
            openInputDwgButton.Enabled = false;
            CopyButton.Enabled = true;

        }

        private void CopyButton_Click(object sender, EventArgs e)
        {
            string newPathname = StringUtility.AppendToFilename(InputDwgFullPath, "_reduced");
            if (System.IO.File.Exists(newPathname))
            {
                try { System.IO.File.Delete(newPathname); }
                catch (Exception ex)
                {
                    Output = ex.Message;
                    return;
                }                
            }
            try { System.IO.File.Copy(InputDwgFullPath, newPathname); }
            catch (Exception ex)
            {
                Output = ex.Message;
                return;
            }

            tdOut = new ThermalDesktop(newPathname);
            tdOut.Connect();

            CopyButton.Enabled = false;
            Scan();
            ScanGroupBox.Enabled = true;

        }

        private void Scan()
        {
            lumps = new BindingList<Lump>(tdOut.GetLumps());
            paths = new BindingList<OpenTDv242.FloCAD.Path>(tdOut.GetPaths());
            ReduceGroupBox.Enabled = true;
        }

        private void LumpListBox_SelectedValueChanged(object sender, EventArgs e)
        {
            if (firstSelectedLump)
            {
                firstSelectedLump = false;
                return;
            }

            if (SetLumpBegin)
            {
                lumpBegin = (Lump)LumpListBox.SelectedItem;
                BegLumpLabel.Text = lumpBegin.ToString();
                SetLumpBegin = !SetLumpBegin;
            }
            else
            {
                lumpEnd = (Lump)LumpListBox.SelectedItem;
                EndLumpLabel.Text = lumpEnd.ToString();
                SetLumpBegin = !SetLumpBegin;
            }

            if ((lumpBegin != null) && (lumpEnd != null))
                ReduceButton.Enabled = true;
        }

        private void ReduceButton_Click(object sender, EventArgs e)
        {
            HashSet<Lump> lumpsOnRoute = getLumpsOnRoute();
            if (!lumpsOnRoute.Any())
            {
                Output = "Could not find a route from " + lumpBegin + " to " + lumpEnd;
                return;
            }

            foreach (Lump lump in lumpsOnRoute)
            {
                tdOut.DeleteEntity(lump);
            }

            OpenTDv242.FloCAD.Path reduced = tdOut.CreatePath(lumpBegin, lumpEnd);
            reduced.isTube = false;
            reduced.FlowArea = 0.0001;
            reduced.Update();

            tdOut.ZoomExtents();

            firstSelectedLump = true;
            Scan();

            ReducedModelTuneDialog tuneDialog = new ReducedModelTuneDialog(tdIn, tdOut, lumpBegin, lumpEnd, reduced, InputDwgDir);
            tuneDialog.ShowDialog();

        }

        private HashSet<Lump> getLumpsOnRoute()
        {
            HashSet<Lump> lumpsOnRoute = new HashSet<Lump>();
            lumpsOnRoute.Add(lumpEnd);
            isOnRoute(lumpBegin, lumpsOnRoute);

            if (!lumpsOnRoute.Contains(lumpBegin))
            {
                lumpsOnRoute.Clear();
                return lumpsOnRoute;
            }

            lumpsOnRoute.Remove(lumpBegin);
            lumpsOnRoute.Remove(lumpEnd);

            return lumpsOnRoute;
        }

        private bool isOnRoute(Lump x, HashSet<Lump> lumpsOnRoute)
        {
            bool success = false;
            List<Lump> downstreamLumps = lumpsDownstreamOf(x);
            if (downstreamLumps.Intersect(lumpsOnRoute).Any())
            {
                lumpsOnRoute.Add(x);
                success = true;
            }
            else
            {
                foreach (Lump y in lumpsDownstreamOf(x))
                {
                    if (isOnRoute(y, lumpsOnRoute))
                    {
                        lumpsOnRoute.Add(x);
                        success = true;
                    }
                }
            }
            return success;
        }

        private List<Lump> lumpsDownstreamOf(Lump baseLump)
        {
            List<Lump> outputLumps = new List<Lump>();
            var pathsFromLump = from path in paths
                                where path.From.Handle == baseLump.Handle
                                select path;
            foreach (var path in pathsFromLump)
                outputLumps.Add(lumps.Single(lump => lump.Handle == path.To.Handle));
            return outputLumps;
        }
    }
}
