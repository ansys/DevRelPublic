using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using OpenTDv242;
using OpenTDv242.Utility;
using OpenTDv242.UserInterface;

namespace OpenTDv242Demos
{
    public partial class MainMenu : Form
    {
        public MainMenu(List<Script> demos)
        {
            InitializeComponent();
            Version v = System.Reflection.Assembly.GetEntryAssembly().GetName().Version;
            Text = string.Format("OpenTD Demos - Version {0}.{1}", v.Major, v.Minor);
            allDemosAvailable = demos;
            FilterListedDemos();
            demosAvailableListBox.DataSource = listedDemos;
        }

        string Filter { get { return SearchTextBox.Text; } }
        List<Script> allDemosAvailable { get; set; }
        BindingList<Script> listedDemos { get; set; }

        private void okButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void runSelected_Click(object sender, EventArgs e)
        {
            toggleButtonsEnabled();       
            foreach (Script d in demosAvailableListBox.SelectedItems)
            {
                RunScript(d);
            }
            toggleButtonsEnabled();
        }

        private void RunScript(Script script)
        {
            Console.WriteLine(getTitleBlock(script));
            try
            {
                script.Run();
            }
            catch (Exception ex)
            {
                Console.WriteLine(getFormattedException(ex));
            }
            Console.WriteLine("*** End Demo ***" + Environment.NewLine);
        }

        private string getTitleBlock(Script d)
        {
            string line = string.Concat(Enumerable.Repeat("-", d.GetName().Length));
            return line + Environment.NewLine
                 + d.GetName() + Environment.NewLine
                 + line;
        }

        private string getFormattedException(Exception ex)
        {
            return (StringUtility.GetRecursiveMessage(ex) +
                    Environment.NewLine +
                    StringUtility.GetRecursiveStackTrace(ex));
        }

        private void toggleButtonsEnabled()
        {
            runSelected.Enabled = toggle(runSelected.Enabled);
        }

        private bool toggle(bool input)
        {
            return input ? false : true;
        }

        private void demosAvailableListBox_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            var listbox = (ListBox)sender;
            int index = listbox.IndexFromPoint(e.Location);
            if (index == ListBox.NoMatches)
                return;
            var selected = (Script)listbox.Items[index];
            RunScript(selected);
        }

        #region Custom ListBox formatting

        const int verticalPad = 5;
        private void demosAvailableListBox_MeasureItem(object sender, MeasureItemEventArgs e)
        {          
            e.ItemHeight = ((Control)sender).Font.Height * 2 + verticalPad; 
        }

        const string indent = "   ";
        private void demosAvailableListBox_DrawItem(object sender, DrawItemEventArgs e)
        {
            Script demo = (Script)(((ListBox)sender).Items[e.Index]);
            
            Font font = ((Control)sender).Font;
            Font fontRegular = new Font(font, FontStyle.Regular);
            Font fontBold = new Font(font, FontStyle.Bold);

            Brush brush;
            if ((e.State & DrawItemState.Selected) == DrawItemState.Selected)
                brush = Brushes.White;
            else
                brush = Brushes.Black;

            e.DrawBackground();
            
            e.Graphics.DrawString(demo.GetName(), fontBold, brush, e.Bounds.X, e.Bounds.Y);
            e.Graphics.DrawString(
                indent + demo.GetDescription(), fontRegular, brush, e.Bounds.X, e.Bounds.Y + font.Height);
        }

        #endregion

        #region Searchbox

        private void SearchTextBox_TextChanged(object sender, EventArgs e)
        {
            FilterListedDemos();
        }

        string GetAllKeywordsLower(Script script)
        {
            StringBuilder output = new StringBuilder();
            output.Append(script.GetName().ToLower());
            output.Append(" ");
            output.Append(script.GetDescription().ToLower());
            output.Append(" ");
            output.Append(script.GetKeywords().ToLower());

            return output.ToString();
        }

        void FilterListedDemos()
        {
            if (listedDemos == null)
                listedDemos = new BindingList<Script>();

            listedDemos.Clear();
            if (string.IsNullOrWhiteSpace(Filter))
            {
                foreach (Script d in allDemosAvailable)
                    listedDemos.Add(d);
            }
            else
            {
                string FilterLower = Filter.ToLower();
                foreach (Script d in allDemosAvailable)
                {
                    if (GetAllKeywordsLower(d).Contains(FilterLower))
                        listedDemos.Add(d);
                }
            }
        }

        #endregion

    }
}
