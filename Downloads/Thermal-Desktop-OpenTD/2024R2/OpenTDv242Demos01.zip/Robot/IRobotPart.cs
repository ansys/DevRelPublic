using System.Collections.Generic;
using OpenTDv242;

namespace OpenTDv242Demos.Robot
{
    internal interface IRobotPart
    {
        Matrix3d BaseTrans { get; }
        Transformation LocalTrans { get; }
        string Handle { get; }
        List<string> AttachedObjectHandles { get; }
        void Update();
        void UpdateFromTD();
    }
}
