using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenTDv242;

namespace OpenTDv242Demos.Robot
{
    public class RobotDemo : Script
    {
        public override string GetDescription()
        {
            return "Create and manipulate surfaces and assemblies";
        }

        public override string GetName()
        {
            return "Robot";
        }
        public override string GetKeywords()
        {
            return "finite difference fd surface basetrans localtrans matrix position transform geometry";
        }

        public override void Run()
        {
            RobotDialog d = new RobotDialog();
            d.ShowDialog();

        }
    }
}
