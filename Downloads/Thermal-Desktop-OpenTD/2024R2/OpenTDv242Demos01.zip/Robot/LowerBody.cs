using System.Collections.Generic;
using OpenTDv242;
using OpenTDv242.Dimension;
using OpenTDv242.RadCAD;

namespace OpenTDv242Demos.Robot
{
    public class LowerBody : IRobotPart
    {
        public LowerBody(ThermalDesktop tdInstance)
        {
            Units.SaveWorkingUnitsAndSetToSI();
            try
            {
                double heightM = 0.5;
                double diaM = 0.3;

                td = tdInstance;

                pedestal = td.CreateCylinder();
                pedestal.Height = heightM;
                pedestal.Radius = diaM / 2;
                //pedestal.BaseTrans.SetOrigin(new Point3d(-widthM / 2, 0, 0)); // align with foot
                pedestal.Update();

                foot = td.CreateAssembly(new Point3d(0, 0, 0));
                foot.AxisSize = 0.1;
                foot.DisplayBaseCS = false;
                foot.AttachedObjectHandles.Add(pedestal.Handle);

                Update();

            }
            finally
            {
                Units.RestoreWorkingUnits();
            }
        }

        public List<string> AttachedObjectHandles
        {
            get
            {
                return foot.AttachedObjectHandles;
            }
        }

        public Matrix3d BaseTrans
        {
            get
            {
                return foot.BaseTrans;
            }
        }

        public string Handle
        {
            get
            {
                return foot.Handle;
            }
        }

        public Transformation LocalTrans
        {
            get
            {
                return foot.LocalTrans;
            }
        }

        public void Update()
        {
            foot.Update();
            pedestal.UpdateFromTD();
        }

        public void UpdateFromTD()
        {
            foot.UpdateFromTD();
            pedestal.UpdateFromTD();
        }

        public Dimensional<ModelLength> PedestalHeight
        {
            get
            {
                pedestal.UpdateFromTD();
                return pedestal.Height;
            }
        }

        public void Delete()
        {
            td.DeleteEntity(pedestal);
            td.DeleteEntity(foot);
        }

        Cylinder pedestal { get; set; }
        Assembly foot { get; set; }
        ThermalDesktop td { get; set; }
    }
}
