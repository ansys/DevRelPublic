using System;
using System.IO;
using System.Windows.Forms;
using OpenTDv242;

namespace OpenTDv242Demos.Robot
{
    public partial class RobotDialog : Form
    {
        public RobotDialog()
        {
            InitializeComponent();
            td = new ThermalDesktop(Path.Combine(Script.WorkingDirectory, "common.dwg"));
            td.Connect();
            robby = new Robot(td);
            td.RestoreIsoView(IsoViews.SW);
            td.ZoomExtents();
            td.SendCommand("\x1B\x1B_vscurrent _other thermal_pp\r");
        }

        ThermalDesktop td { get; set; }
        Robot robby { get; set; }

        private void RightShoulderYawTrackBar_Scroll(object sender, EventArgs e)
        {
            robby.RightArm.ShoulderYawDeg = RightShoulderYawTrackBar.Value;
        }

        private void RightShoulderPitchTrackBar_Scroll(object sender, EventArgs e)
        {
            robby.RightArm.ShoulderPitchDeg = -RightShoulderPitchTrackBar.Value;
        }

        private void RightElbowPitchTrackBar_Scroll(object sender, EventArgs e)
        {
            robby.RightArm.ElbowPitchDeg = -RightElbowPitchTrackBar.Value;
        }

        private void LeftShoulderYawTrackBar_Scroll(object sender, EventArgs e)
        {
            robby.LeftArm.ShoulderYawDeg = LeftShoulderYawTrackBar.Value;
        }

        private void LeftShoulderPitchTrackBar_Scroll(object sender, EventArgs e)
        {
            robby.LeftArm.ShoulderPitchDeg = -LeftShoulderPitchTrackBar.Value;
        }

        private void LeftElbowPitchTrackBar_Scroll(object sender, EventArgs e)
        {
            robby.LeftArm.ElbowPitchDeg = -LeftElbowPitchTrackBar.Value;
        }

        private void NeckYawTrackBar_Scroll(object sender, EventArgs e)
        {
            robby.Head.NeckYawDeg = NeckYawTrackBar.Value;
        }

        private void WaistYawTrackBar_Scroll(object sender, EventArgs e)
        {
            robby.Torso.WaistYawDeg = WaistYawTrackBar.Value;
        }

        private void WaistPitchTrackBar_Scroll(object sender, EventArgs e)
        {
            robby.Torso.WaistPitchDeg = -WaistPitchTrackBar.Value;
        }

        private void RobotDialog_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (td != null)
                try { robby.Delete(); } catch { }
        }
    }
}
