using System.Collections.Generic;
using OpenTDv242;
using OpenTDv242.Dimension;
using OpenTDv242.RadCAD;

namespace OpenTDv242Demos.Robot
{
    public class Torso : IRobotPart
    {
        public Torso(ThermalDesktop tdInstance)
        {
            Units.SaveWorkingUnitsAndSetToSI();
            try
            {
                double heightM = 0.75;
                double widthM = 0.6;

                td = tdInstance;

                torso = td.CreateRectangle();
                torso.YMax = heightM;
                torso.XMax = widthM;
                torso.BaseTrans.SetOrigin(new Point3d(-widthM / 2, 0, 0)); // align with waist
                torso.Update();

                waist = td.CreateAssembly(new Point3d(0, 0, 0));
                waist.AxisSize = 0.1;
                waist.DisplayBaseCS = false;
                waist.AttachedObjectHandles.Add(torso.Handle);

                Update();

            }
            finally
            {
                Units.RestoreWorkingUnits();
            }
        }

        public Matrix3d BaseTrans
        {
            get
            {
                if (waist != null)
                    return waist.BaseTrans;
                else
                    return null;
            }
        }

        public Transformation LocalTrans
        {
            get
            {
                if (waist != null)
                    return waist.LocalTrans;
                else
                    return null;
            }
        }

        public string Handle { get { return waist.Handle; } }

        public List<string> AttachedObjectHandles { get { return waist.AttachedObjectHandles; } }

        public void Update()
        {
            waist.Update();
            torso.UpdateFromTD();
        }

        public void UpdateFromTD()
        {
            torso.UpdateFromTD();
            waist.UpdateFromTD();
        }

        public Dimensional<ModelLength> Height
        {
            get
            {
                torso.UpdateFromTD();
                return torso.YMax;
            }
        }

        public Dimensional<ModelLength> Width
        {
            get
            {
                torso.UpdateFromTD();
                return torso.XMax;
            }
        }

        public double WaistYawDeg
        {
            get
            {
                waist.UpdateFromTD();
                return waist.LocalTrans.Rot1;
            }
            set
            {
                waist.UpdateFromTD();
                waist.LocalTrans.Axis1 = 1; // first rotation is y-axis
                waist.LocalTrans.Rot1 = value;
                waist.Update();
                td.UpdateGraphics();
            }
        }

        public double WaistPitchDeg
        {
            get
            {
                waist.UpdateFromTD();
                return waist.LocalTrans.Rot2;
            }
            set
            {
                waist.UpdateFromTD();
                waist.LocalTrans.Axis2 = 0; // second rotation is x-axis
                waist.LocalTrans.Rot2 = value;
                waist.Update();
                td.UpdateGraphics();
            }
        }

        public void Delete()
        {
            td.DeleteEntity(torso);
            td.DeleteEntity(waist);
        }

        Rectangle torso { get; set; }
        Assembly waist { get; set; }
        ThermalDesktop td { get; set; }

    }
}
