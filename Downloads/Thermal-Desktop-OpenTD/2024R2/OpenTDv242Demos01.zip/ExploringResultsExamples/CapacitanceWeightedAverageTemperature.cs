using System.IO;
using OpenTDv242;
using OpenTDv242.Results.Dataset;
using OpenTDv242.Results.Plot;

namespace OpenTDv242Demos.ExploringResultsExamples
{
    class CapacitanceWeightedAverageTemperature : Example
    {
        public override string Description
        {
            get
            {
                return "Uses a WeightedAverageDataArray to plot the piecewise mCp-weighted average temperature for all nodes in a submodel. " +
                       "A WeightedAverageDataArray is a type of DerivedDataArray, which acts like a DataArray but contains a list " +
                       "of DataArrays which it combines in some way to produce its data. A WeightedAverageDataArray finds the weighted mean " +
                       "of the data for each record.";
            }
        }

        public override string Name { get { return "Plot the mCp-weighted average T of a submodel"; } }

        public override void Run()
        {
            string resultsDir = Path.Combine(Script.WorkingDirectory, "exploringResultsSav");
            var data = new SaveFile(Path.Combine(resultsDir, "AllCap.sav"));
            var itemIdentifiers = new ItemIdentifierCollection(DataTypes.NODE, "PLATE", data);
            var plateTs = data.GetData(itemIdentifiers, StandardDataSubtypes.T);
            var weightedAvg = new WeightedAverageDataArray(StandardDataSubtypes.T, StandardDataSubtypes.C, itemIdentifiers, data);
            var plot = new SimplePlot();
            plot.AddSeries(plateTs);
            plot.AddSeries(weightedAvg);
            plot.Series[plot.Series.Count - 1].Series2dStyle.LineWidth = 6;
            plot.Show();
        }
    }
}