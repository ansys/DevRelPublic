using System.IO;
using OpenTDv242;
using OpenTDv242.Results.Dataset;
using OpenTDv242.Results.Plot;

namespace OpenTDv242Demos.ExploringResultsExamples
{
    public class MissingData : Example
    {
        public override string Description
        {
            get
            {
                return "Plot T and a register from a sav file. For the register, data was only " +
                       "saved at two records, so the DataArray returned by GetData will contain " +
                       "NaN for all other records. The SimplePlot will plot the NaN's as " +
                       "discontinuities in the series. Also, any series with discontinuities will " +
                       "default to having markers turned on and made large.";
            }
        }

        public override string Name
        {
            get
            {
                return "Plot data that's missing from some records";
            }
        }

        public override void Run()
        {
            string resultsDir = Path.Combine(Script.WorkingDirectory, "exploringResultsSav");
            var data = new SaveFile(Path.Combine(resultsDir, "transientMissingData.sav"));

            data.GetThermalSubmodels();

            var TandReg = data.GetData("MAIN.T1", "TESTREG01");
            var plot = new SimplePlot();
            plot.AddSeries(TandReg);
            plot.Show();
        }
    }
}
