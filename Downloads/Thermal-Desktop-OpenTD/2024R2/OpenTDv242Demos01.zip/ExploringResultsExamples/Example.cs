namespace OpenTDv242Demos.ExploringResultsExamples
{
    public abstract class Example
    {
        public abstract string Name { get; }
        public abstract string Description { get; }
        public abstract void Run();
        public override string ToString()
        {
            return Name;
        }
    }
}
