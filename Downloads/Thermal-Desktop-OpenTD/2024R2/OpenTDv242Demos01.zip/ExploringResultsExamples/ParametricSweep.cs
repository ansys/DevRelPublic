using System.IO;
using System.Linq;
using OpenTDv242;
using OpenTDv242.Results.Dataset;
using OpenTDv242.Results.Plot;

namespace OpenTDv242Demos.ExploringResultsExamples
{
    public class ParametricSweep : Example
    {
        public override string Description
        {
            get
            {
                return "Plot T for a parametric steady-state run. Create a SimplePlot and add " +
                       "T data with AddSeries(Ydata), which automatically finds Xdata from the source Dataset. " +
                       "Usually this is time, but when the plot notices that time is not changing for the series, it " +
                       "uses Record Number instead. Create a second plot that uses AddSeries(Xdata, Ydata) to " +
                       "plot T vs. the sweep variable instead of record number.";
            }
        }

        public override string Name { get { return "Plot parametric sweep results"; } }

        public override void Run()
        {
            string resultsDir = Path.Combine(Script.WorkingDirectory, "exploringResultsSav");
            var data = new SaveFile(Path.Combine(resultsDir, "Q_sweep.sav"));
            var plot = new SimplePlot("T vs. Record Number using AddSeries(Y)");
            var Ts = data.GetData("AVIONICS3.T1", "AVIONICS1.T1");
            plot.AddSeries(Ts); // will automatically use record number as x data
            plot.Show();

            var Q = data.GetRegisterData("Q_AVIONICS3", StandardDataSubtypes.Q);
            var plot2 = new SimplePlot("T vs. Q using AddSeries(X, Y)");
            plot2.AddSeries(Q, Ts[0]);
            plot2.AddSeries(Q, Ts[1]);
            plot2.Show();
        }
    }
}
