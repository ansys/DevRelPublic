using System.IO;
using OpenTDv242;
using OpenTDv242.Results.Dataset;
using OpenTDv242.Results.Plot;

namespace OpenTDv242Demos.ExploringResultsExamples
{
    public class SteadyState : Example
    {
        public override string Description
        {
            get
            {
                return "Plot temperatures from a steady-state Dataset. SimplePlot will" +
                    " automatically enable markers on series with only one data point.";
            }
        }

        public override string Name
        {
            get
            {
                return "Try plotting steady-state data";
            }
        }

        public override void Run()
        {
            string resultsDir = Path.Combine(Script.WorkingDirectory, "exploringResultsSav");
            var data = new SaveFile(Path.Combine(resultsDir, "steady.sav"));

            data.GetThermalSubmodels();

            var Avionics1Ts = data.GetData("AVIONICS1.T1", "AVIONICS2.T1", "AVIONICS3.T1");
            var plot = new SimplePlot();
            plot.AddSeries(Avionics1Ts);
            plot.Show();
        }
    }
}
