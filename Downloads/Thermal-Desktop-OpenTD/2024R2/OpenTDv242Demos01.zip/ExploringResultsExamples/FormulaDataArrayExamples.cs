using System.IO;
using OpenTDv242;
using OpenTDv242.Results.Dataset;
using OpenTDv242.Results.Plot;

namespace OpenTDv242Demos.ExploringResultsExamples
{
    public class FormulaDataArrayExamples : Example
    {
        public override string Description
        {
            get
            {
                return "Use FormulaDataArrays to combine multiple arrays. A FormulaDataArray is a type of DerivedDataArray," +
                    " which acts like a DataArray but contains a list of DataArrays which it combines in some way to produce" +
                    " its data. A FormulaDataArray combines the values of its input arrays using a specified mathematical " +
                    " formula, in a specified unit system.";
            }
        }

        public override string Name { get { return "Use a formula to combine arrays or create new arrays"; } }

        public override void Run()
        {
            string resultsDir = Path.Combine(Script.WorkingDirectory, "exploringResultsSav");
            var beta0 = new SaveFile(Path.Combine(resultsDir, "hot_beta0.sav"));

            {
                // Create FormulaDataArray that adds 100 deg F to a
                // node temperature.

                var T = beta0.GetData("AVIONICS1.T1");
                var Tplus100degF = new FormulaDataArray();
                Tplus100degF.InputCollection.AddRange(T);

                // In the formula, use X0 for the first input array,
                // X1 for the second, etc.:
                Tplus100degF.Formula = "X0 + 100";

                // Need to set Formula units to Eng because formula
                // is only valid in deg F (or R):
                Tplus100degF.FormulaUnits.SetToEng();

                // Need to set Subtype because all FormulaDataArrays default
                // to dimensionless:
                Tplus100degF.Subtype = StandardDataSubtypes.T;

                var plot = new SimplePlot();
                plot.AddSeries(T);
                plot.AddSeries(Tplus100degF);
                plot.Show();
            }

            {
                // Create FormulaDataArray that computes the ratio of submodel average T's

                // Get average T for submodel 1:
                var sub1Nodes = new ItemIdentifierCollection(DataTypes.NODE, "AVIONICS1", beta0);
                var sub1Ts = beta0.GetData(sub1Nodes, StandardDataSubtypes.T);
                var sub1Tavg = new AverageDataArray(sub1Ts);

                // Get average T for submodel 2:
                var sub2Nodes = new ItemIdentifierCollection(DataTypes.NODE, "AVIONICS2", beta0);
                var sub2Ts = beta0.GetData(sub2Nodes, StandardDataSubtypes.T);
                var sub2Tavg = new AverageDataArray(sub2Ts);

                // Create array of sub1Tavg/sub2Tavg:
                var T2_over_T1 = new FormulaDataArray();
                T2_over_T1.Name = "AVIONICS2.T_avg / AVIONICS1.T_avg";
                T2_over_T1.InputCollection.Add(sub1Tavg);
                T2_over_T1.InputCollection.Add(sub2Tavg);

                // In the formula, use X0 for the first input array,
                // X1 for the second, etc.:
                T2_over_T1.Formula = "X1/X0";

                // Set FormulaUnits to SI to make sure the ratio is calculated with absolute T:
                T2_over_T1.FormulaUnits.SetToSI();

                Units.WorkingUnits.SetToEng();
                var plot = new SimplePlot();
                plot.AddSeries(sub1Tavg);
                plot.AddSeries(sub2Tavg);
                plot.AddSeries(T2_over_T1);
                plot.Series[plot.Series.Count - 1].Series2dStyle.LineWidth = 5;
                plot.Show();
                Units.WorkingUnits.SetToSI();
            }
        }
    }
}
