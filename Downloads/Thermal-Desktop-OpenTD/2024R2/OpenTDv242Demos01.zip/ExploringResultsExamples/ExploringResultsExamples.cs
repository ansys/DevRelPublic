using System.Collections.Generic;
using OpenTDv242;

namespace OpenTDv242Demos.ExploringResultsExamples
{
    class ExploringResultsExamples : Script
    {
        public override string GetDescription()
        {
            return "Demonstrates how to read solution results";
        }

        public override string GetName()
        {
            return "Exploring Results Examples";
        }

        public override string GetKeywords()
        {
            return "postprocessing post-processing contour results save csr datasets maximum minimum plots average";
        }

        public override void Run()
        {
            var examples = new List<Example>();
            examples.Add(new SingleNodeSingleCase());
            examples.Add(new MissingData());
            examples.Add(new SteadyState());
            examples.Add(new FormatChart());
            examples.Add(new ParametricSweep());
            examples.Add(new ConcatenatedDataSetExample());
            examples.Add(new DataSetSliceExample());
            examples.Add(new AverageSubmodel());
            examples.Add(new CapacitanceWeightedAverageTemperature());
            examples.Add(new EnvelopeOverMultipleDatasets());
            examples.Add(new FormulaDataArrayExamples());
            examples.Add(new CompareDatasets());
            Menu m = new Menu(examples);
            m.ShowDialog();
        }
    }
}
