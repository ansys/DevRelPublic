using System.IO;
using OpenTDv242;
using OpenTDv242.Results.Dataset;
using OpenTDv242.Results.Plot;

namespace OpenTDv242Demos.ExploringResultsExamples
{
    class FormatChart : Example
    {
        public override string Description
        {
            get
            {
                return "Create a SimplePlot and apply custom formatting to it. " +
                       "Change the chart palette and the title font, hide the x axis grid, set the x axis to English units, " +
                       "change the x axis number format, change the line style and add markers for one series, create a " +
                       "custom name for one series, and change a Y axis font.";
            }
        }

        public override string Name { get { return "Custom format a SimplePlot"; } }

        public override void Run()
        {
            string resultsDir = Path.Combine(Script.WorkingDirectory, "exploringResultsSav");
            var beta0 = new SaveFile(Path.Combine(resultsDir, "hot_beta0.sav"));
            var nodeData = beta0.GetData("AVIONICS1.T6", "AVIONICS1.Q6");
            var plot = new SimplePlot();
            plot.AddSeries(nodeData); // will automatically use time as x data
            plot.AutoSetAxes();
            plot.Plot2dStyle.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Berry;
            plot.Title = "This is a custom plot title";
            plot.Plot2dStyle.TitleColor = System.Drawing.Color.Red;
            plot.Plot2dStyle.TitleFont = new System.Drawing.Font("Times New Roman", 25);
            plot.XAxes[0].MajorGrid.Enabled = false;
            plot.XAxes[0].Units.SetToEng();
            plot.XAxes[0].AxisStyle.LabelFormat = "F1";
            plot.Series[0].Series2dStyle.MarkerStyle = System.Windows.Forms.DataVisualization.Charting.MarkerStyle.Square;
            plot.Series[0].Series2dStyle.MarkerSize = 10;
            plot.Series[0].Series2dStyle.LineStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            plot.Series[0].Series2dStyle.LineWidth = 3;
            plot.Series[1].Name = "This is a custom name for the Q series";
            plot.YAxes[1].AxisStyle.TitleFont = new System.Drawing.Font("Consolas", 20);
            plot.YAxes[1].AxisStyle.TitleColor = System.Drawing.Color.Green;
            plot.Show();
        }
    }
}
