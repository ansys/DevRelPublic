using System;
using OpenTDv242;
using OpenTDv242.RadCAD.FdSolid;

namespace OpenTDv242Demos.Marquee
{
    class SolidUpperK : SolidCharacter
    {
        public SolidUpperK(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height)
        {
            DrawUpright();
            DrawLeg();
            DrawArm();
        }

        const double angleDeg = 35;
        const double angleRad = angleDeg * Math.PI / 180;

        SolidBrick Upright;
        SolidBrick Leg;
        SolidBrick Arm;

        void DrawUpright()
        {
            Upright = TD.CreateSolidBrick();
            Upright.ColorIndex = ColorIndex;
            Upright.XMax = Thickness;
            Upright.ZMax = Thickness;
            Upright.YMax = Height;
            Upright.BaseTrans = new Matrix3d(CS);

            Upright.Update();
        }

        void DrawLeg()
        {
            Leg = TD.CreateSolidBrick();
            Leg.XMax = Thickness;
            Leg.ZMax = Thickness;
            Leg.YMax = Height / 2 / Math.Cos(angleRad);
            Leg.BaseTrans = new Matrix3d(CS);

            Matrix3d trans = new Matrix3d();
            trans.SetToRotZ(-180 + angleDeg);
            trans.SetOrigin(new Point3d(Thickness, 0.6 * Height, 0));
            Leg.BaseTrans.PostMultBy(trans);
            Leg.ColorIndex = ColorIndex;
            Leg.Update();
        }

        void DrawArm()
        {
            Arm = TD.CreateSolidBrick();
            Arm.XMax = Thickness;
            Arm.ZMax = Thickness;
            Arm.YMax = Height / 2 / Math.Cos(angleRad);
            Arm.BaseTrans = new Matrix3d(CS);

            Matrix3d trans = new Matrix3d();
            trans.SetToRotZ(-angleDeg);
            trans.SetOrigin(new Point3d(0.2 * Thickness, 0.5 * Height, 0));
            Arm.BaseTrans.PostMultBy(trans);
            Arm.ColorIndex = ColorIndex;
            Arm.Update();
        }

        public override double Width => 0.55 * Height;

        public override void Delete()
        {
            TD.DeleteEntity(Upright);
            TD.DeleteEntity(Leg);
            TD.DeleteEntity(Arm);
        }
    }
}
