using OpenTDv242;
using OpenTDv242.RadCAD.FdSolid;

namespace OpenTDv242Demos.Marquee
{
    class SolidUpperH : SolidCharacter
    {
        public SolidUpperH(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height)
        {
            DrawUpright();
            DrawUpright2();
            DrawMid();
        }

        SolidBrick Upright;
        SolidBrick Upright2;
        SolidBrick Mid;

        void DrawUpright()
        {
            Upright = TD.CreateSolidBrick();
            Upright.ColorIndex = ColorIndex;
            Upright.XMax = Thickness;
            Upright.ZMax = Thickness;
            Upright.YMax = Height;
            Upright.BaseTrans = new Matrix3d(CS);

            Upright.Update();
        }

        void DrawUpright2()
        {
            Upright2 = TD.CreateSolidBrick();
            Upright2.ColorIndex = ColorIndex;
            Upright2.XMax = Thickness;
            Upright2.ZMax = Thickness;
            Upright2.YMax = Height;
            Upright2.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(Thickness + 0.2 * Height, 0, 0));
            Upright2.BaseTrans.PostMultBy(trans);

            Upright2.Update();
        }

        void DrawMid()
        {
            Mid = TD.CreateSolidBrick();
            Mid.ColorIndex = ColorIndex;
            Mid.XMax = 0.2 * Height;
            Mid.ZMax = Thickness;
            Mid.YMax = Thickness;
            Mid.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(Thickness, Height / 2 - Thickness / 2, 0));
            Mid.BaseTrans.PostMultBy(trans);

            Mid.Update();
        }

        public override double Width => 2 * Thickness + 0.2 * Height;

        public override void Delete()
        {
            TD.DeleteEntity(Upright);
            TD.DeleteEntity(Upright2);
            TD.DeleteEntity(Mid);
        }
    }
}
