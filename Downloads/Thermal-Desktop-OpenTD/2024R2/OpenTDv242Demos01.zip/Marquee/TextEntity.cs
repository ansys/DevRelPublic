using OpenTDv242;

namespace OpenTDv242Demos.Marquee
{
    abstract class TextEntity
    {
        public TextEntity(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
        {
            TD = _td;
            CS = _cs;
            ColorIndex = _colorIndex;
            Height = _height;
        }

        public ThermalDesktop TD { get; private set; }

        public Matrix3d CS { get; private set; }

        public double Height { get; private set; }
        public virtual double Width { get; }

        public int ColorIndex { get; private set; }

        public abstract void Delete();
    }
}
