using System.IO;
using System.Threading;
using OpenTDv242;

namespace OpenTDv242Demos.Marquee
{
    public class Marquee : Script
    {
        public override string GetName()
        {
            return "Marquee";
        }
        public override string GetDescription()
        {
            return "Use 3d matrices to position text made from FD Solids";
        }
        public override string GetKeywords()
        {
            return "finite difference fd solid basetrans localtrans matrix position transform geometry";
        }
        public override void Run()
        {
            Units.WorkingUnits.SetToSI();
            var td = new ThermalDesktop(Path.Combine(Script.WorkingDirectory, "common.dwg"));
            td.Connect();

            var cursor = new Matrix3d();

            td.SetVisualStyle(VisualStyles.THERMAL);
            td.RestoreOrthoView(OrthoViews.TOP);

            {
                cursor.SetToRotX(90);
                var trans = new Matrix3d();
                trans.SetToRotY(2);
                trans.SetOrigin(new Point3d(0.5, 0, 0));
                var text = new SolidText("THERMAL DESKTOP", td, cursor, 1, 10, trans);
                td.RestoreIsoView(IsoViews.SE);
                td.ZoomExtents();
                Thread.Sleep(2000);
                text.Delete();
            }

            {
                td.RestoreIsoView(IsoViews.SW);
                cursor = new Matrix3d();
                var trans = new Matrix3d();
                trans.SetOrigin(new Point3d(0.5, 0, 0));
                var text = new SolidText("BY CRTECH", td, cursor, 152, 10, trans);
                td.ZoomExtents();
                Thread.Sleep(1000);
                text.Delete();
            }

            {
                cursor.SetOrigin(new Point3d(0, 15, 0));
                var trans = new Matrix3d();
                trans.SetOrigin(new Point3d(0.5, 0, 0));
                var text = new SolidText("THERMAL DESKTOP", td, cursor, 1, 15, trans);
                td.ZoomExtents();
                Thread.Sleep(2000);
                text.Delete();
            }

            {
                cursor.SetOrigin(new Point3d(0, 50, 0));
                var trans = new Matrix3d();
                trans.SetOrigin(new Point3d(0.5, 0, 0));
                var crtech = new SolidText("BY CRTECH", td, cursor, 152, 100, trans);
                td.ZoomExtents();
                Thread.Sleep(2000);

                td.RestoreIsoView(IsoViews.SE);
                cursor.SetOrigin(new Point3d(0, 175, 0));
                trans.SetToRotZ(5);
                trans.SetOrigin(new Point3d(10, 0, 0));
                var thermalDesktop = new SolidText("THERMAL DESKTOP", td, cursor, 1, 100, trans);
                td.ZoomExtents();
                Thread.Sleep(2000);

                crtech.Delete();
                thermalDesktop.Delete();
            }
        }
    }
}
