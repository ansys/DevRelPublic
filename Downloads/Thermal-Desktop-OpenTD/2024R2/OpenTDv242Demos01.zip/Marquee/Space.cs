using OpenTDv242;

namespace OpenTDv242Demos.Marquee
{
    class Space : Character
    {
        public Space(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height) { }

        public override double Width => Height / 1.8;

        public override void Delete() { }
    }
}
