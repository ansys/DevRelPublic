using OpenTDv242;
using OpenTDv242.RadCAD.FdSolid;

namespace OpenTDv242Demos.Marquee
{
    class SolidUpperP : SolidCharacter
    {
        public SolidUpperP(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height)
        {
            DrawUpright();
            DrawUpperCyl();
        }

        SolidBrick Upright;
        SolidCylinder UpperCyl;

        void DrawUpright()
        {
            Upright = TD.CreateSolidBrick();
            Upright.ColorIndex = ColorIndex;
            Upright.XMax = Thickness;
            Upright.ZMax = Thickness;
            Upright.YMax = Height;
            Upright.BaseTrans = new Matrix3d(CS);

            Upright.Update();
        }

        void DrawUpperCyl()
        {
            UpperCyl = TD.CreateSolidCylinder();
            UpperCyl.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(Thickness, 0.75 * Height, 0));
            UpperCyl.BaseTrans.PostMultBy(trans);
            UpperCyl.Height = Thickness;
            UpperCyl.Rmax = 0.25 * Height;
            UpperCyl.Rmin = UpperCyl.Rmax - 0.8 * Thickness;
            UpperCyl.StartAngle = 270;
            UpperCyl.EndAngle = 90;
            UpperCyl.ColorIndex = ColorIndex;
            UpperCyl.Update();
        }

        public override double Width => Thickness + 0.25 * Height;

        public override void Delete()
        {
            TD.DeleteEntity(Upright);
            TD.DeleteEntity(UpperCyl);
        }
    }
}
