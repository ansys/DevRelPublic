using OpenTDv242;

namespace OpenTDv242Demos.Marquee
{
    abstract class Character : TextEntity
    {
        public Character(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height) { }
    }
}
