using System;
using OpenTDv242;
using OpenTDv242.RadCAD.FdSolid;

namespace OpenTDv242Demos.Marquee
{
    class SolidUpperA : SolidCharacter
    {
        public SolidUpperA(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height)
        {
            DrawLeft();
            DrawRight();
        }

        const double angleRad = 15 * Math.PI / 180;

        SolidBrick left;
        SolidBrick right;

        void DrawLeft()
        {
            left = TD.CreateSolidBrick();
            left.ColorIndex = ColorIndex;
            left.XMax = Thickness;
            left.ZMax = Thickness;
            left.YMax = Height / Math.Cos(angleRad);

            Matrix3d rotate = new Matrix3d();
            rotate.SetToRotZ(-angleRad * 180 / Math.PI);
            left.BaseTrans = new Matrix3d(CS);
            left.BaseTrans.PostMultBy(rotate);

            left.Update();
        }

        void DrawRight()
        {
            right = TD.CreateSolidBrick();
            right.ColorIndex = ColorIndex;
            right.XMax = Thickness;
            right.ZMax = Thickness;
            right.YMax = Height / Math.Cos(angleRad);

            Matrix3d translate = new Matrix3d();
            translate.SetOrigin(new Point3d(2 * Height * Math.Tan(angleRad),
                                            - Thickness * Math.Sin(angleRad),
                                            0));
            Matrix3d rotateright = new Matrix3d();
            rotateright.SetToRotZ(angleRad * 180 / Math.PI);
            right.BaseTrans = new Matrix3d(CS);
            right.BaseTrans.PostMultBy(translate).PostMultBy(rotateright);

            right.Update();
        }

        public override double Width => 2 * Height * Math.Tan(angleRad)
                                       + Thickness * Math.Cos(angleRad);

        public override void Delete()
        {
            TD.DeleteEntity(left);
            TD.DeleteEntity(right);
        }
    }
}
