using OpenTDv242;
using OpenTDv242.RadCAD.FdSolid;

namespace OpenTDv242Demos.Marquee
{
    class SolidUpperE : SolidCharacter
    {
        public SolidUpperE(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height)
        {
            DrawUpright();
            DrawUp();
            DrawMid();
            DrawLow();
        }

        SolidBrick Upright;
        SolidBrick Up;
        SolidBrick Mid;
        SolidBrick Low;

        void DrawUpright()
        {
            Upright = TD.CreateSolidBrick();
            Upright.ColorIndex = ColorIndex;
            Upright.XMax = Thickness;
            Upright.ZMax = Thickness;
            Upright.YMax = Height;
            Upright.BaseTrans = new Matrix3d(CS);

            Upright.Update();
        }

        void DrawUp()
        {
            Up = TD.CreateSolidBrick();
            Up.ColorIndex = ColorIndex;
            Up.XMax = 0.4 * Height;
            Up.ZMax = Thickness;
            Up.YMax = Thickness;
            Up.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(Thickness, Height - Thickness, 0));
            Up.BaseTrans.PostMultBy(trans);

            Up.Update();
        }

        void DrawMid()
        {
            Mid = TD.CreateSolidBrick();
            Mid.ColorIndex = ColorIndex;
            Mid.XMax = 0.3 * Height;
            Mid.ZMax = Thickness;
            Mid.YMax = Thickness;
            Mid.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(Thickness, Height / 2 - Thickness / 2, 0));
            Mid.BaseTrans.PostMultBy(trans);

            Mid.Update();
        }

        void DrawLow()
        {
            Low = TD.CreateSolidBrick();
            Low.ColorIndex = ColorIndex;
            Low.XMax = 0.4 * Height;
            Low.ZMax = Thickness;
            Low.YMax = Thickness;
            Low.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(Thickness, 0, 0));
            Low.BaseTrans.PostMultBy(trans);

            Low.Update();
        }

        public override double Width => Thickness + 0.4 * Height;

        public override void Delete()
        {
            TD.DeleteEntity(Upright);
            TD.DeleteEntity(Up);
            TD.DeleteEntity(Mid);
            TD.DeleteEntity(Low);
        }
    }
}
