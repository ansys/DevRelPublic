using System.Collections.Generic;
using OpenTDv242;

namespace OpenTDv242Demos.Marquee
{
    class SolidText : Text
    {
        public SolidText(string _value, ThermalDesktop _td, Matrix3d _cs, int _colorIndex,
            double _height = 1.0, Matrix3d _characterTransition = null)
            : base(_value, _td, _cs, _colorIndex, _height, _characterTransition)
        {
            Draw();
        }

        List<Character> Characters;

        void Draw()
        {
            _width = 0;
            Characters = new List<Character>();
            foreach (char c in Value)
            {
                Character solidChar = DrawCharacter(c);
                Characters.Add(solidChar);
                AdvanceCursor(solidChar.Width);
                _width += solidChar.Width;
            }
        }


        public override double Width => _width;
        double _width;

        public override void Delete()
        {
            foreach (Character c in Characters)
                c.Delete();
        }

        Character DrawCharacter(char x)
        {
            switch (x)
            {
                case ' ':
                    return new Space(TD, Cursor, ColorIndex, Height);
                case 'A':
                    return new SolidUpperA(TD, Cursor, ColorIndex, Height);
                case 'B':
                    return new SolidUpperB(TD, Cursor, ColorIndex, Height);
                case 'C':
                    return new SolidUpperC(TD, Cursor, ColorIndex, Height);
                case 'D':
                    return new SolidUpperD(TD, Cursor, ColorIndex, Height);
                case 'E':
                    return new SolidUpperE(TD, Cursor, ColorIndex, Height);
                case 'H':
                    return new SolidUpperH(TD, Cursor, ColorIndex, Height);
                case 'K':
                    return new SolidUpperK(TD, Cursor, ColorIndex, Height);
                case 'L':
                    return new SolidUpperL(TD, Cursor, ColorIndex, Height);
                case 'M':
                    return new SolidUpperM(TD, Cursor, ColorIndex, Height);
                case 'O':
                    return new SolidUpperO(TD, Cursor, ColorIndex, Height);
                case 'P':
                    return new SolidUpperP(TD, Cursor, ColorIndex, Height);
                case 'R':
                    return new SolidUpperR(TD, Cursor, ColorIndex, Height);
                case 'S':
                    return new SolidUpperS(TD, Cursor, ColorIndex, Height);
                case 'T':
                    return new SolidUpperT(TD, Cursor, ColorIndex, Height);
                case 'Y':
                    return new SolidUpperY(TD, Cursor, ColorIndex, Height);
                default:
                    return new SolidPlaceholder(TD, Cursor, ColorIndex, Height);
            }
        }
    }
}
