using System;
using OpenTDv242;
using OpenTDv242.RadCAD.FdSolid;

namespace OpenTDv242Demos.Marquee
{
    class SolidUpperR : SolidCharacter
    {
        public SolidUpperR(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height)
        {
            DrawUpright();
            DrawUpperCyl();
            DrawLeg();
        }

        const double angleDeg = 35;
        const double angleRad = angleDeg * Math.PI / 180;

        SolidBrick Upright;
        SolidCylinder UpperCyl;
        SolidBrick Leg;

        void DrawUpright()
        {
            Upright = TD.CreateSolidBrick();
            Upright.ColorIndex = ColorIndex;
            Upright.XMax = Thickness;
            Upright.ZMax = Thickness;
            Upright.YMax = Height;
            Upright.BaseTrans = new Matrix3d(CS);

            Upright.Update();
        }

        void DrawUpperCyl()
        {
            UpperCyl = TD.CreateSolidCylinder();
            UpperCyl.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(Thickness, 0.75 * Height, 0));
            UpperCyl.BaseTrans.PostMultBy(trans);
            UpperCyl.Height = Thickness;
            UpperCyl.Rmax = 0.25 * Height;
            UpperCyl.Rmin = UpperCyl.Rmax - 0.8 * Thickness;
            UpperCyl.StartAngle = 270;
            UpperCyl.EndAngle = 90;
            UpperCyl.ColorIndex = ColorIndex;
            UpperCyl.Update();
        }

        void DrawLeg()
        {
            Leg = TD.CreateSolidBrick();
            Leg.XMax = Thickness;
            Leg.ZMax = Thickness;
            Leg.YMax = Height / 2 / Math.Cos(angleRad);
            Leg.BaseTrans = new Matrix3d(CS);

            Matrix3d trans = new Matrix3d();
            trans.SetToRotZ(-180 + angleDeg);
            trans.SetOrigin(new Point3d(Thickness, 0.6 * Height, 0));
            Leg.BaseTrans.PostMultBy(trans);
            Leg.ColorIndex = ColorIndex;
            Leg.Update();
        }

        public override double Width => 0.55 * Height;

        public override void Delete()
        {
            TD.DeleteEntity(Upright);
            TD.DeleteEntity(UpperCyl);
            TD.DeleteEntity(Leg);
        }
    }
}
