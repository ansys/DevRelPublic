using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OpenTDv242;

namespace OpenTDv242Demos
{
    public class TecCatalogMaker : Script
    {
        public override string GetDescription()
        {
            return "Uses the TEC Generator to produce several TEC's in one model";
        }

        public override string GetName()
        {
            return "TEC Catalog Maker";
        }

        public override string GetKeywords()
        {
            return "finite difference fd surface tec thermoelectric cooler";
        }

        public override void Run()
        {
            List<Tuple<TecSpec, int>> tecsAndLayerColors = new List<Tuple<TecSpec, int>>();

            TecSpec tec1 = new TecSpec();
            tec1.Name = "CP10,127,05,L1,W4.5";
            tec1.LayerName = "CP10";
            tec1.SubmodelName = "CP10";
            tec1.BasePlate.thickness_mm = 0.75;
            tec1.BasePlate.Xmm = 30;
            tec1.BasePlate.Ymm = 30;
            Stage tec1stage1 = new Stage();
            tec1stage1.Couples.N = 127;
            tec1stage1.Couples.GeometryFactorCM = 0.079;
            tec1stage1.Couples.Height_mm = 3.2;
            tec1stage1.TopPlate.thickness_mm = 0.75;
            tec1stage1.TopPlate.Xmm = 30;
            tec1stage1.TopPlate.Ymm = 30;
            tec1.Stages.Add(tec1stage1);
            tecsAndLayerColors.Add(new Tuple<TecSpec, int>(tec1, 72));

            TecSpec tec2 = new TecSpec();
            tec2.Name = "CP12,161,04,L1,W4.5";
            tec2.LayerName = "CP12";
            tec2.SubmodelName = "CP12";
            tec2.BasePlate.thickness_mm = 0.75;
            tec2.BasePlate.Xmm = 40;
            tec2.BasePlate.Ymm = 40;
            Stage tec2stage1 = new Stage();
            tec2stage1.Couples.N = 161;
            tec2stage1.Couples.GeometryFactorCM = 0.144;
            tec2stage1.Couples.Height_mm = 3.3;
            tec2stage1.TopPlate.thickness_mm = 0.75;
            tec2stage1.TopPlate.Xmm = 40;
            tec2stage1.TopPlate.Ymm = 40;
            tec2.Stages.Add(tec2stage1);
            tecsAndLayerColors.Add(new Tuple<TecSpec, int>(tec2, 60));

            TecSpec tec3 = new TecSpec();
            tec3.Name = "CP14,71,045,L1,W4.5";
            tec3.LayerName = "CP14";
            tec3.SubmodelName = "CP14";
            tec3.BasePlate.thickness_mm = 0.75;
            tec3.BasePlate.Xmm = 30;
            tec3.BasePlate.Ymm = 30;
            Stage tec3stage1 = new Stage();
            tec3stage1.Couples.N = 71;
            tec3stage1.Couples.GeometryFactorCM = 0.171;
            tec3stage1.Couples.Height_mm = 3.3;
            tec3stage1.TopPlate.thickness_mm = 0.75;
            tec3stage1.TopPlate.Xmm = 30;
            tec3stage1.TopPlate.Ymm = 30;
            tec3.Stages.Add(tec3stage1);
            tecsAndLayerColors.Add(new Tuple<TecSpec, int>(tec3, 140));

            TecSpec tec4 = new TecSpec();
            tec4.Name = "CP2,127,10,L1,W4.5";
            tec4.LayerName = "CP2";
            tec4.SubmodelName = "CP2";
            tec4.BasePlate.thickness_mm = 0.75;
            tec4.BasePlate.Xmm = 44;
            tec4.BasePlate.Ymm = 44;
            Stage tec4stage1 = new Stage();
            tec4stage1.Couples.N = 127;
            tec4stage1.Couples.GeometryFactorCM = 0.184;
            tec4stage1.Couples.Height_mm = 5.6;
            tec4stage1.TopPlate.thickness_mm = 0.75;
            tec4stage1.TopPlate.Xmm = 44;
            tec4stage1.TopPlate.Ymm = 44;
            tec4.Stages.Add(tec4stage1);
            tecsAndLayerColors.Add(new Tuple<TecSpec, int>(tec4, 40));

            TecSpec tec5 = new TecSpec();
            tec5.Name = "MS2,102,14,14,17,17,11,W8";
            tec5.LayerName = "MS2";
            tec5.SubmodelName = "MS2";
            tec5.BasePlate.thickness_mm = 0.75;
            tec5.BasePlate.Xmm = 30;
            tec5.BasePlate.Ymm = 30;
            Stage tec5stage1 = new Stage();
            tec5stage1.Couples.N = 71;
            tec5stage1.Couples.GeometryFactorCM = 0.082;
            tec5stage1.Couples.Height_mm = 7.5/2;
            tec5stage1.TopPlate.thickness_mm = 0.75;
            tec5stage1.TopPlate.Xmm = 30;
            tec5stage1.TopPlate.Ymm = 30;
            tec5.Stages.Add(tec5stage1);
            Stage tec5stage2 = new Stage();
            tec5stage2.Couples.N = 31;
            tec5stage2.Couples.GeometryFactorCM = 0.082;
            tec5stage2.Couples.Height_mm = 7.5 / 2;
            tec5stage2.TopPlate.thickness_mm = 0.75;
            tec5stage2.TopPlate.Xmm = 30;
            tec5stage2.TopPlate.Ymm = 30;
            tec5.Stages.Add(tec5stage2);
            tecsAndLayerColors.Add(new Tuple<TecSpec, int>(tec5, 220));

            ThermalDesktop td = new ThermalDesktop();
            td.Connect();
            UnitsData ourWorkingUnits = new UnitsData();
            ourWorkingUnits.SetToSI();
            ourWorkingUnits.modelLength = UnitsData.ModelLength.MM;
            td.SetUnits(ourWorkingUnits);

            Point3d origin = new Point3d(0, 0, 0);
            Point3d currentOrigin = new Point3d(origin);
            foreach (Tuple<TecSpec, int> tAndC in tecsAndLayerColors)
            {
                Layer layer = td.CreateLayer(tAndC.Item1.LayerName);
                layer.ColorIndex = tAndC.Item2;
                layer.Update();
                TecGenerator.MakeTec(td, tAndC.Item1, currentOrigin);
                currentOrigin += new Point3d(60, 0, 0);
            }

            td.SetVisualStyle(VisualStyles.THERMAL_PP);
            td.RestoreIsoView(IsoViews.SW);
            td.ZoomExtents();
        }
    }
}
