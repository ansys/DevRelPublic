using System;
using System.Collections.Generic;
using System.Windows.Forms;
using OpenTDv242;
using OpenTDv242Demos.ContourFinder;
using OpenTDv242Demos.SatelliteConfigurator;
using OpenTDv242Demos.UDFACreator;
using OpenTDv242Demos.CompartmentCreator;
using OpenTDv242Demos.QFlowPlotter;
using OpenTDv242Demos.FeMeshSpiral;

namespace OpenTDv242Demos
{
    static class OpenTDv242Demos
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Version v = System.Reflection.Assembly.GetEntryAssembly().GetName().Version;
            string title = string.Format("OpenTD Demos - Version {0}.{1}", v.Major, v.Minor);
            Console.WriteLine("Welcome to " + title);
            Console.WriteLine("Please use the menu dialog to run the demos.");
            Console.WriteLine("Additional information and prompts will be displayed here.");
            Console.WriteLine();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Script.WorkingDirectory = @".\model";

            List<Script> demos = new List<Script>();
            demos.Add(new Translator());
            demos.Add(new Robot.RobotDemo());
            demos.Add(new FEMeshExample.FEMeshExample());
            demos.Add(new FeMeshSpiralDemo());
            demos.Add(new Truss());
            demos.Add(new Marquee.Marquee());
            demos.Add(new Snake.SnakeDemo());
            demos.Add(new CompartmentCreatorDemo());
            demos.Add(new CaptureScreenshots());
            demos.Add(new OrganizeModelWithLinq());
            demos.Add(new ReducedModel());
            demos.Add(new ExploringResultsExamples.ExploringResultsExamples());
            demos.Add(new SatelliteConfiguratorDemo());
            demos.Add(new ContourFinderDemo());
            demos.Add(new QFlowPlotterDemo());
            demos.Add(new UDFACreatorDemo());
            demos.Add(new ControlTd());
            demos.Add(new ControlSindaFluint.ControlSindaFluint());
            demos.Add(new TecGenerator());
            demos.Add(new Comprehensive());

            Application.Run(new MainMenu(demos));
        }
    }
}
