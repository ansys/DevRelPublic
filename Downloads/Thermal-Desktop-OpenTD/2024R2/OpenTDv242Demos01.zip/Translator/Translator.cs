using OpenTDv242;

namespace OpenTDv242Demos
{
    public class Translator : Script
    {
        public override string GetName()
        {
            return "Translator";
        }
        public override string GetDescription()
        {
            return "Translate a text-based model to TD";
        }
        public override string GetKeywords()
        {
            return "nodes conductors text translate exhange model sinda";
        }
        public override void Run()
        {
            TranslatorDialog d = new TranslatorDialog();
            d.ShowDialog();
        }
    }
}
