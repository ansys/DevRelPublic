namespace OpenTDv242Demos
{
    partial class TranslatorDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TranslatorDialog));
            this.inputDeckTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.translateButton = new System.Windows.Forms.Button();
            this.IntroTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // inputDeckTextBox
            // 
            this.inputDeckTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.inputDeckTextBox.Location = new System.Drawing.Point(11, 84);
            this.inputDeckTextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.inputDeckTextBox.Multiline = true;
            this.inputDeckTextBox.Name = "inputDeckTextBox";
            this.inputDeckTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.inputDeckTextBox.Size = new System.Drawing.Size(448, 248);
            this.inputDeckTextBox.TabIndex = 1;
            this.inputDeckTextBox.Text = resources.GetString("inputDeckTextBox.Text");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 68);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Input model:";
            // 
            // translateButton
            // 
            this.translateButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.translateButton.Location = new System.Drawing.Point(362, 362);
            this.translateButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.translateButton.Name = "translateButton";
            this.translateButton.Size = new System.Drawing.Size(97, 22);
            this.translateButton.TabIndex = 2;
            this.translateButton.Text = "Translate to TD";
            this.translateButton.UseVisualStyleBackColor = true;
            this.translateButton.Click += new System.EventHandler(this.translateButton_Click);
            // 
            // IntroTextBox
            // 
            this.IntroTextBox.Location = new System.Drawing.Point(9, 10);
            this.IntroTextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.IntroTextBox.Multiline = true;
            this.IntroTextBox.Name = "IntroTextBox";
            this.IntroTextBox.ReadOnly = true;
            this.IntroTextBox.Size = new System.Drawing.Size(450, 45);
            this.IntroTextBox.TabIndex = 4;
            this.IntroTextBox.TabStop = false;
            this.IntroTextBox.Text = "OpenTD can be used to create custom translators to and from Thermal Desktop\r\nmode" +
    "ls. Here is an example of translating from the fictional \"Simple Thermal\r\nModel\"" +
    " format to a TD dwg.";
            // 
            // TranslatorDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(467, 399);
            this.Controls.Add(this.IntroTextBox);
            this.Controls.Add(this.translateButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.inputDeckTextBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MinimumSize = new System.Drawing.Size(402, 438);
            this.Name = "TranslatorDialog";
            this.Text = "Translate to TD";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TranslatorDialog_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox inputDeckTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button translateButton;
        private System.Windows.Forms.TextBox IntroTextBox;
    }
}