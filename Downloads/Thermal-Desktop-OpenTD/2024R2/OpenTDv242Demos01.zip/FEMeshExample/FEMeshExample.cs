using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using OpenTDv242;
using OpenTDv242.RadCAD;

namespace OpenTDv242Demos.FEMeshExample
{
    public class FEMeshExample : Script
    {
        public override string GetDescription()
        {
            return "Use an FEMeshImporter to create a FEM";
        }

        public override string GetName()
        {
            return "FEM Example";
        }

        public override string GetKeywords()
        {
            return "finite element fem mesh sinusoid";
        }

        public override void Run()
        {
            var td = new ThermalDesktop(Path.Combine(Script.WorkingDirectory, "common.dwg"));
            td.Connect();

            var feMesh = new OpenTDv242.RadCAD.FEModel.FEMesh();

            int uDiv = 20;
            int vDiv = 20;

            double height = 0.5;
            double xPeriods = 2.0;
            double yPeriods = 1.0;
            double xLen = 5.0;
            double yLen = 3.0;

            int id = 0;
            int elemId = 0;
            double dx = xLen / uDiv;
            double dy = yLen / vDiv;
            for (int j = 0; j < vDiv + 1; ++j)
            {
                double y = j * dy;
                for (int i = 0; i < uDiv + 1; ++i)
                {
                    double x = i * dx;
                    double z = height *
                        Math.Cos(x / xLen * xPeriods * 2.0 * Math.PI) *
                        Math.Cos(y / yLen * yPeriods * 2.0 * Math.PI);

                    var node = new OpenTDv242.RadCAD.FEModel.Node();
                    node.x = x; node.y = y; node.z = z; node.Nx = 0.0; node.Ny = 0.0; node.Nz = 1.0;
                    id++;
                    node.id = id;

                    feMesh.nodes.Add(node);

                    if (i < uDiv && j < vDiv)
                    {
                        var face = new OpenTDv242.RadCAD.FEModel.SurfaceElement();

                        elemId++;
                        face.id = elemId;
                        face.order = 1;
                        face.numNodes = 4;

                        int baseIndex = j * (uDiv + 1) + i + 1;
                        face.nodeIds.Add(baseIndex);
                        face.nodeIds.Add(baseIndex + 1);
                        face.nodeIds.Add(baseIndex + 1 + uDiv + 1);
                        face.nodeIds.Add(baseIndex + uDiv + 1);

                        face.material = "aluminum";
                        face.thickness = 0.01;

                        feMesh.surfaceElements.Add(face);
                    }
                }
            }

            string name = "API Importer";
            bool useUCS = false;
            var meshImporter = td.CreateFEMeshImporter(name, useUCS);
            
            meshImporter.SetMesh(feMesh);

            td.SetVisualStyle(VisualStyles.THERMAL_PP);
            td.RestoreIsoView(IsoViews.SE);
            td.ZoomExtents();

            System.Windows.Forms.MessageBox.Show("Close this dialog to delete mesh.");
            try
            {
                td.DeleteEntity(meshImporter);
                td.UpdateGraphics();
            }
            catch { }
        }
    }
}
