namespace OpenTDv242Demos.UDFACreator
{
    partial class UDFACreatorDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UDFACreatorDialog));
            this.openDWG = new System.Windows.Forms.Button();
            this.groupBoxControls = new System.Windows.Forms.GroupBox();
            this.buttonLoadUDFA = new System.Windows.Forms.Button();
            this.buttonExecute = new System.Windows.Forms.Button();
            this.labelXYLoc = new System.Windows.Forms.Label();
            this.labelHeatFlux = new System.Windows.Forms.Label();
            this.labelMinRadSlider = new System.Windows.Forms.Label();
            this.labelMaxRadSlider = new System.Windows.Forms.Label();
            this.groupBoxSubmodel = new System.Windows.Forms.GroupBox();
            this.radioButtonBlue = new System.Windows.Forms.RadioButton();
            this.radioButtonOrange = new System.Windows.Forms.RadioButton();
            this.trackBarMinRad = new System.Windows.Forms.TrackBar();
            this.trackBarMaxRad = new System.Windows.Forms.TrackBar();
            this.trackBarHeatLoad = new System.Windows.Forms.TrackBar();
            this.trackBarXLoc = new System.Windows.Forms.TrackBar();
            this.trackBarYLoc = new System.Windows.Forms.TrackBar();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBoxControls.SuspendLayout();
            this.groupBoxSubmodel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarMinRad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarMaxRad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarHeatLoad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarXLoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarYLoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // openDWG
            // 
            this.openDWG.Location = new System.Drawing.Point(19, 16);
            this.openDWG.Margin = new System.Windows.Forms.Padding(2);
            this.openDWG.Name = "openDWG";
            this.openDWG.Size = new System.Drawing.Size(134, 35);
            this.openDWG.TabIndex = 1;
            this.openDWG.Text = "Open Dwg";
            this.openDWG.UseVisualStyleBackColor = true;
            this.openDWG.Click += new System.EventHandler(this.openDWG_Click);
            // 
            // groupBoxControls
            // 
            this.groupBoxControls.Controls.Add(this.buttonLoadUDFA);
            this.groupBoxControls.Controls.Add(this.buttonExecute);
            this.groupBoxControls.Controls.Add(this.labelXYLoc);
            this.groupBoxControls.Controls.Add(this.labelHeatFlux);
            this.groupBoxControls.Controls.Add(this.labelMinRadSlider);
            this.groupBoxControls.Controls.Add(this.labelMaxRadSlider);
            this.groupBoxControls.Controls.Add(this.groupBoxSubmodel);
            this.groupBoxControls.Controls.Add(this.trackBarMinRad);
            this.groupBoxControls.Controls.Add(this.trackBarMaxRad);
            this.groupBoxControls.Controls.Add(this.trackBarHeatLoad);
            this.groupBoxControls.Controls.Add(this.trackBarXLoc);
            this.groupBoxControls.Controls.Add(this.trackBarYLoc);
            this.groupBoxControls.Controls.Add(this.pictureBox1);
            this.groupBoxControls.Enabled = false;
            this.groupBoxControls.Location = new System.Drawing.Point(19, 64);
            this.groupBoxControls.Margin = new System.Windows.Forms.Padding(2);
            this.groupBoxControls.Name = "groupBoxControls";
            this.groupBoxControls.Padding = new System.Windows.Forms.Padding(2);
            this.groupBoxControls.Size = new System.Drawing.Size(806, 577);
            this.groupBoxControls.TabIndex = 2;
            this.groupBoxControls.TabStop = false;
            this.groupBoxControls.Text = "Heat load controls";
            // 
            // buttonLoadUDFA
            // 
            this.buttonLoadUDFA.Enabled = false;
            this.buttonLoadUDFA.Location = new System.Drawing.Point(556, 491);
            this.buttonLoadUDFA.Margin = new System.Windows.Forms.Padding(2);
            this.buttonLoadUDFA.Name = "buttonLoadUDFA";
            this.buttonLoadUDFA.Size = new System.Drawing.Size(171, 53);
            this.buttonLoadUDFA.TabIndex = 12;
            this.buttonLoadUDFA.Text = "Display Heated Nodes\r\n(using UDFA \"WithinRange\")";
            this.buttonLoadUDFA.UseVisualStyleBackColor = true;
            this.buttonLoadUDFA.Click += new System.EventHandler(this.buttonLoadUDFA_Click);
            // 
            // buttonExecute
            // 
            this.buttonExecute.Location = new System.Drawing.Point(556, 417);
            this.buttonExecute.Margin = new System.Windows.Forms.Padding(2);
            this.buttonExecute.Name = "buttonExecute";
            this.buttonExecute.Size = new System.Drawing.Size(171, 48);
            this.buttonExecute.TabIndex = 11;
            this.buttonExecute.Text = "Run Case";
            this.buttonExecute.UseVisualStyleBackColor = true;
            this.buttonExecute.Click += new System.EventHandler(this.buttonExecute_Click);
            // 
            // labelXYLoc
            // 
            this.labelXYLoc.AutoSize = true;
            this.labelXYLoc.Location = new System.Drawing.Point(89, 36);
            this.labelXYLoc.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelXYLoc.Name = "labelXYLoc";
            this.labelXYLoc.Size = new System.Drawing.Size(342, 13);
            this.labelXYLoc.TabIndex = 10;
            this.labelXYLoc.Text = "Move X and Y sliders to select center of heating position (0 - 10 meters)";
            // 
            // labelHeatFlux
            // 
            this.labelHeatFlux.AutoSize = true;
            this.labelHeatFlux.Location = new System.Drawing.Point(568, 320);
            this.labelHeatFlux.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelHeatFlux.Name = "labelHeatFlux";
            this.labelHeatFlux.Size = new System.Drawing.Size(133, 13);
            this.labelHeatFlux.TabIndex = 9;
            this.labelHeatFlux.Text = "Heat Flux (10 - 200 W/m2)";
            // 
            // labelMinRadSlider
            // 
            this.labelMinRadSlider.AutoSize = true;
            this.labelMinRadSlider.Location = new System.Drawing.Point(568, 230);
            this.labelMinRadSlider.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelMinRadSlider.Name = "labelMinRadSlider";
            this.labelMinRadSlider.Size = new System.Drawing.Size(148, 13);
            this.labelMinRadSlider.TabIndex = 8;
            this.labelMinRadSlider.Text = "Minimum Radius (0 - 9 meters)";
            // 
            // labelMaxRadSlider
            // 
            this.labelMaxRadSlider.AutoSize = true;
            this.labelMaxRadSlider.Location = new System.Drawing.Point(561, 140);
            this.labelMaxRadSlider.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelMaxRadSlider.Name = "labelMaxRadSlider";
            this.labelMaxRadSlider.Size = new System.Drawing.Size(157, 13);
            this.labelMaxRadSlider.TabIndex = 7;
            this.labelMaxRadSlider.Text = "Maximum Radius (1 - 10 meters)";
            // 
            // groupBoxSubmodel
            // 
            this.groupBoxSubmodel.Controls.Add(this.radioButtonBlue);
            this.groupBoxSubmodel.Controls.Add(this.radioButtonOrange);
            this.groupBoxSubmodel.Location = new System.Drawing.Point(533, 36);
            this.groupBoxSubmodel.Margin = new System.Windows.Forms.Padding(2);
            this.groupBoxSubmodel.Name = "groupBoxSubmodel";
            this.groupBoxSubmodel.Padding = new System.Windows.Forms.Padding(2);
            this.groupBoxSubmodel.Size = new System.Drawing.Size(217, 76);
            this.groupBoxSubmodel.TabIndex = 6;
            this.groupBoxSubmodel.TabStop = false;
            this.groupBoxSubmodel.Text = "Apply heat to nodes that are:";
            // 
            // radioButtonBlue
            // 
            this.radioButtonBlue.AutoSize = true;
            this.radioButtonBlue.Location = new System.Drawing.Point(23, 47);
            this.radioButtonBlue.Margin = new System.Windows.Forms.Padding(2);
            this.radioButtonBlue.Name = "radioButtonBlue";
            this.radioButtonBlue.Size = new System.Drawing.Size(46, 17);
            this.radioButtonBlue.TabIndex = 1;
            this.radioButtonBlue.Text = "Blue";
            this.radioButtonBlue.UseVisualStyleBackColor = true;
            // 
            // radioButtonOrange
            // 
            this.radioButtonOrange.AutoSize = true;
            this.radioButtonOrange.Checked = true;
            this.radioButtonOrange.Location = new System.Drawing.Point(23, 28);
            this.radioButtonOrange.Margin = new System.Windows.Forms.Padding(2);
            this.radioButtonOrange.Name = "radioButtonOrange";
            this.radioButtonOrange.Size = new System.Drawing.Size(60, 17);
            this.radioButtonOrange.TabIndex = 0;
            this.radioButtonOrange.TabStop = true;
            this.radioButtonOrange.Text = "Orange";
            this.radioButtonOrange.UseVisualStyleBackColor = true;
            // 
            // trackBarMinRad
            // 
            this.trackBarMinRad.Location = new System.Drawing.Point(533, 253);
            this.trackBarMinRad.Margin = new System.Windows.Forms.Padding(2);
            this.trackBarMinRad.Maximum = 90;
            this.trackBarMinRad.Name = "trackBarMinRad";
            this.trackBarMinRad.Size = new System.Drawing.Size(217, 45);
            this.trackBarMinRad.TabIndex = 5;
            this.trackBarMinRad.Value = 20;
            // 
            // trackBarMaxRad
            // 
            this.trackBarMaxRad.Location = new System.Drawing.Point(533, 166);
            this.trackBarMaxRad.Margin = new System.Windows.Forms.Padding(2);
            this.trackBarMaxRad.Maximum = 100;
            this.trackBarMaxRad.Minimum = 10;
            this.trackBarMaxRad.Name = "trackBarMaxRad";
            this.trackBarMaxRad.Size = new System.Drawing.Size(217, 45);
            this.trackBarMaxRad.TabIndex = 4;
            this.trackBarMaxRad.Value = 40;
            // 
            // trackBarHeatLoad
            // 
            this.trackBarHeatLoad.Location = new System.Drawing.Point(533, 350);
            this.trackBarHeatLoad.Margin = new System.Windows.Forms.Padding(2);
            this.trackBarHeatLoad.Maximum = 200;
            this.trackBarHeatLoad.Minimum = 10;
            this.trackBarHeatLoad.Name = "trackBarHeatLoad";
            this.trackBarHeatLoad.Size = new System.Drawing.Size(217, 45);
            this.trackBarHeatLoad.TabIndex = 3;
            this.trackBarHeatLoad.Value = 100;
            // 
            // trackBarXLoc
            // 
            this.trackBarXLoc.Location = new System.Drawing.Point(41, 68);
            this.trackBarXLoc.Margin = new System.Windows.Forms.Padding(2);
            this.trackBarXLoc.Maximum = 100;
            this.trackBarXLoc.Name = "trackBarXLoc";
            this.trackBarXLoc.Size = new System.Drawing.Size(457, 45);
            this.trackBarXLoc.TabIndex = 2;
            this.trackBarXLoc.Value = 40;
            // 
            // trackBarYLoc
            // 
            this.trackBarYLoc.Location = new System.Drawing.Point(4, 109);
            this.trackBarYLoc.Margin = new System.Windows.Forms.Padding(2);
            this.trackBarYLoc.Maximum = 100;
            this.trackBarYLoc.Name = "trackBarYLoc";
            this.trackBarYLoc.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBarYLoc.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBarYLoc.Size = new System.Drawing.Size(45, 449);
            this.trackBarYLoc.TabIndex = 1;
            this.trackBarYLoc.Value = 60;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::OpenTDv242Demos.Properties.Resources.UDFAMesh450;
            this.pictureBox1.Location = new System.Drawing.Point(41, 112);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(450, 439);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // UDFACreatorDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(875, 649);
            this.Controls.Add(this.openDWG);
            this.Controls.Add(this.groupBoxControls);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "UDFACreatorDialog";
            this.Text = "UDFA Demo";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UDFACreatorDialog_FormClosing);
            this.groupBoxControls.ResumeLayout(false);
            this.groupBoxControls.PerformLayout();
            this.groupBoxSubmodel.ResumeLayout(false);
            this.groupBoxSubmodel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarMinRad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarMaxRad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarHeatLoad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarXLoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarYLoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button openDWG;
        private System.Windows.Forms.GroupBox groupBoxControls;
        private System.Windows.Forms.Button buttonExecute;
        private System.Windows.Forms.Label labelXYLoc;
        private System.Windows.Forms.Label labelHeatFlux;
        private System.Windows.Forms.Label labelMinRadSlider;
        private System.Windows.Forms.Label labelMaxRadSlider;
        private System.Windows.Forms.GroupBox groupBoxSubmodel;
        private System.Windows.Forms.RadioButton radioButtonBlue;
        private System.Windows.Forms.RadioButton radioButtonOrange;
        private System.Windows.Forms.TrackBar trackBarMinRad;
        private System.Windows.Forms.TrackBar trackBarMaxRad;
        private System.Windows.Forms.TrackBar trackBarHeatLoad;
        private System.Windows.Forms.TrackBar trackBarXLoc;
        private System.Windows.Forms.TrackBar trackBarYLoc;
        private System.Windows.Forms.Button buttonLoadUDFA;
    }
}