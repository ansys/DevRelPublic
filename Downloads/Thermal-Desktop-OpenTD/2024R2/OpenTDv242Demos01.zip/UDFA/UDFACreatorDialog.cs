using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using OpenTDv242;
using OpenTDv242.PostProcessing;



namespace OpenTDv242Demos.UDFACreator
{
    public partial class UDFACreatorDialog : Form
    {
        public UDFACreatorDialog()
        {
            InitializeComponent();
        }
        ThermalDesktop td = new ThermalDesktop();

        // Layer control will be used to switch between viewing surfaces and viewing nodes
        Layer blue = new Layer();
        Layer orange = new Layer();
        Layer nodelayer = new Layer();

        private void openDWG_Click(object sender, EventArgs e)
        {
            string dwg = @"UDFA.dwg";
            string dwgPathname = Path.Combine(Script.WorkingDirectory, dwg);
            if (!File.Exists(dwgPathname))
            {
                MessageBox.Show("Could not find " + dwg + " in directory " + Script.WorkingDirectory);
                return;
            }

            td.ConnectConfig.DwgPathname = dwgPathname;
            td.Connect();
            blue = td.GetLayerByName("Blue");
            orange = td.GetLayerByName("Orange");
            nodelayer = td.GetLayerByName("Nodes");
            groupBoxControls.Enabled = true;
        }

        private void buttonExecute_Click(object sender, EventArgs e)
        {
            buttonLoadUDFA.Enabled = false;
            buttonExecute.Enabled = false;

            string heatflux = trackBarHeatLoad.Value.ToString("N2");
            string xLoc = (trackBarXLoc.Value / 10.0).ToString("N2");
            string yLoc = (trackBarYLoc.Value / 10.0).ToString("N2");
            string maxrad;
            string minrad;

            if (trackBarMaxRad.Value == trackBarMinRad.Value)
            {
                MessageBox.Show("The max radius equals the min radius. Please adjust and try again.");
                return;
            }

            // If the min radius is greater than the max radius, the values will just be swapped.
            // Instead the trackBar could adjust the valid range of the min to the max setting.
            if (trackBarMinRad.Value > trackBarMaxRad.Value)
            {
                maxrad = (trackBarMinRad.Value / 10.0).ToString("N2");
                minrad = (trackBarMaxRad.Value / 10.0).ToString("N2");
            }
            else
            {
                minrad = (trackBarMinRad.Value / 10.0).ToString("N2");
                maxrad = (trackBarMaxRad.Value / 10.0).ToString("N2");
            }

            // It is assumed that if any logic object exist, this was activated for a second time, so do not recreate them.
            if (!LogicObjectsExist(td))
            {
                // First create the group for the UDFAs
                var udfas = td.CreateUDFACollection();

                // Then create the Fortran Arrays in that group
                // This UDFA is actually 3, and it is the position of each node (X, Y, and Z arrays)
                UDFA xyz = new UDFA();
                xyz.UdfaValueType = UDFA.ValueType.REAL;
                xyz.Type = UDFA.UdfaType.NODES;
                xyz.InitType = UDFA.UdfaInitType.NODE_LOC;
                xyz.Name = "position";
                xyz.IndexName = "pos";
                xyz.EnabledExpression.Value = "1";
                udfas.FortranArrays.Add(xyz);

                // This UDFA is only used for post processing. It indicates whether a node was of the correct submodel and within range. 
                UDFA inrange = new UDFA();
                inrange.UdfaValueType = UDFA.ValueType.REAL;
                inrange.Type = UDFA.UdfaType.NODES;
                inrange.InitType = UDFA.UdfaInitType.SINGLE;
                inrange.InitData = "0.0";
                inrange.Name = "withinrange";
                inrange.IndexName = "inr";
                inrange.EnabledExpression.Value = "1";
                udfas.FortranArrays.Add(inrange);

                // This UDFA is populated with the area of each node.
                UDFA nodearea = new UDFA();
                nodearea.UdfaValueType = UDFA.ValueType.REAL;
                nodearea.Type = UDFA.UdfaType.NODES;
                nodearea.InitType = UDFA.UdfaInitType.NODE_AREA;
                nodearea.Name = "nodearea";
                nodearea.IndexName = "nodeA";
                nodearea.EnabledExpression.Value = "1";
                udfas.FortranArrays.Add(nodearea);

                // Update the group to add the Fortran Arrays
                udfas.Update();

                CreateFortranSub(td);
            }

            var allnodes = td.GetNodes();
            
            // Where the submodel of a node matches the selected radio button, a call to a fortran subroutine that uses Network Element Logic will be added
            // Where they do not match, a comment will be put in the logic of the node to indicate they did not match.
            foreach (var nd in allnodes)
            {
                if ((nd.Submodel == "ORANGE" && radioButtonOrange.Checked == true) || (nd.Submodel == "BLUE" && radioButtonBlue.Checked == true))
                {
                    nd.TCode.Variables0 =
                        "      CALL SETHEAT('#sub',#num, " + xLoc + ", " + yLoc + ", " + minrad + ", " + maxrad + ", " + heatflux + ")"; }
                else
                {
                    nd.TCode.Variables0 =
                        "C No heat to this node";
                }
                nd.Update();     
            }

            var sscase = td.GetCaseSet("SteadyState");
            UpdateLayers(1);
            sscase.Run();            
            td.UpdateGraphics();
            td.ZoomExtents();
            buttonLoadUDFA.Enabled = true;
            buttonExecute.Enabled = true;

        }

        private bool LogicObjectsExist(ThermalDesktop td)
        {
            var logictest = td.GetLogicObjects();
            if (logictest.Count == 0) return false;
            else return true;            
        }

        private void CreateFortranSub(ThermalDesktop td)
        {
            // This fortran subroutine will determine whether the node in question is within the max and min radius from the specified point
            // If it is within range, it will apply heat to the node based on the nodal area (regardless of whether the surfaces are orange or blue)
            // It will also update a UDFA to identify which nodes were identified for heating.
            var fortransub = td.CreateUserCode();
            fortransub.Routine = LogicObjectRoutineTypes.SUBROUTINE_or_NODE_or_FLOW;
            fortransub.Code = "F     SUBROUTINE SETHEAT(SUBMOD,ID,XLOCF,YLOCF,MINR,MAXR,QA)\n" +
                              "      CALL COMMON\n" +
                              "F     CHARACTER*(*) :: SUBMOD\n" +
                              "F     INTEGER ::ID\n" +
                              "F     REAL ::XLOCF, YLOCF, MINR, MAXR, QA\n" +
                              "F     REAL::DISTX, DISTY, DISTTOT\n" +
                              "F     DISTX = UDRA(POS_X) % ARV(INTNOD(SUBMOD, ID)) - XLOCF\n" +
                              "F     DISTY = UDRA(POS_Y) % ARV(INTNOD(SUBMOD, ID)) - YLOCF\n" +
                              "F     DISTTOT = SQRT(DISTX * *2.0 + DISTY * *2.0)\n" +
                              "F     IF(DISTTOT.GT.MINR.AND.DISTTOT.LT.MAXR ) THEN\n" +
                              "F       UDRA(INR) % ARV(INTNOD(SUBMOD, ID)) = 1.0000000\n" +
                              "F       Q(INTNOD (SUBMOD, ID)) = Q(INTNOD(SUBMOD, ID)) + UDRA(NODEA) % ARV(INTNOD(SUBMOD, ID)) * QA\n" +
                              "F     ELSE\n" +
                              "F       UDRA(INR ) % ARV(INTNOD(SUBMOD, ID)) = 0.0000000\n" +
                              "F     ENDIF\n" +
                              "F     RETURN\n" +
                              "F     END";

            fortransub.Update();
        }

        private void buttonLoadUDFA_Click(object sender, EventArgs e)
        {
            string savefile = @"UDFAsteady.sav";
            string savePathname = Path.Combine(Script.WorkingDirectory, savefile);
            Dataset udfadataset = new Dataset();
            // If the post processing dataset already exists (meaning the model has been run already), use it. Otherwise create a new one.
            try
            {
                udfadataset = td.DatasetManager.GetDataset("UDFAflag");
            }
            catch 
            {
                udfadataset = td.DatasetManager.CreateDataset("UDFAflag", savePathname, Dataset.DataSourceTypes.SF);
            }                
            // The index identifies the WITHINRANGE UDFA and displays it for each node in a post processing window.
            udfadataset.AdditionalInfo.Sinda.SelectedNodeVariableIndex = 8;            
            udfadataset.SetCurrent();
            udfadataset.ShowContourPlot();
            udfadataset.Update();
            // Layers are used to switch visibility between surfaces and nodes. 
            UpdateLayers(0);
            td.UpdateGraphics();
            td.ZoomExtents();
        }

        private void UpdateLayers(int set)
        {
            if (set == 1) 
            { 
            blue.Frozen = false;
            orange.Frozen = false;
            nodelayer.Frozen = true;
            }
            else
            {
                blue.Frozen = true;
                orange.Frozen = true;
                nodelayer.Frozen = false;
            }
            blue.Update();
            orange.Update();
            nodelayer.Update();
        }

        private void UDFACreatorDialog_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (td != null)
                try { td.Quit(); } catch { }
        }
    }
}
