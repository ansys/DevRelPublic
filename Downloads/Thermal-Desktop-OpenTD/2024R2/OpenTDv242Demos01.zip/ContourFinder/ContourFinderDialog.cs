using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenTDv242;
using OpenTDv242.PostProcessing;
using OpenTDv242.Results.Dataset;
using System.IO;

namespace OpenTDv242Demos.ContourFinder
{
    public partial class ContourFinderDialog : Form
    {
        public ContourFinderDialog()
        {
            InitializeComponent();
        }
        ThermalDesktop td = new ThermalDesktop();
        List<Submodel> submodels = new List<Submodel>();
        string saveFilePath;

        private void openDwgButton_Click(object sender, EventArgs e)
        {
            string dwg = @"Contours.dwg";
            string dwgPathname = Path.Combine(Script.WorkingDirectory, dwg);
            if (!File.Exists(dwgPathname))
            {
                MessageBox.Show("Could not find " + dwg + " in directory " + Script.WorkingDirectory);
                return;
            }

            td.ConnectConfig.DwgPathname = dwgPathname;
            //path name is saved for used with save file in post processing
            saveFilePath = Path.GetDirectoryName(dwgPathname);
            td.Connect();
            LoadSubmodels();
            LoadViews();
            findMaxButton.Enabled = true;
            findMinButton.Enabled = true;
        }

        /// <summary>
        /// Add submodels in DWG to list box
        /// </summary>
        private void LoadSubmodels()
        {
            submodelListBox1.Items.Clear();
            submodels = td.GetSubmodels();
            if (submodels == null) return;
            foreach (var z in submodels) submodelListBox1.Items.Add(z);
        }

        /// <summary>
        /// Add ortho, iso, and any saved named views to list box
        /// </summary>
        private void LoadViews()
        {
            viewListBox.Items.Clear();
            viewListBox.Items.Add("Ortho TOP");
            viewListBox.Items.Add("Ortho BOTTOM");
            viewListBox.Items.Add("Ortho FRONT");
            viewListBox.Items.Add("Ortho BACK");
            viewListBox.Items.Add("Ortho LEFT");
            viewListBox.Items.Add("Ortho RIGHT");
            viewListBox.Items.Add("Iso SW");
            viewListBox.Items.Add("Iso SE");
            viewListBox.Items.Add("Iso NE");
            viewListBox.Items.Add("Iso NW");

            // If there are any named views in the drawing, load them into the list box
            var views = td.GetViewNames(); 
            if (views == null) return;
            foreach (var v in views)
            {
                viewListBox.Items.Add(v);
            }
        }

        private void findMaxButton_Click(object sender, EventArgs e)
        {
            if (submodelListBox1.SelectedItem == null) return;
            int IndexToPlot = GetIndex(1);       
            if (IndexToPlot == -1) return;  // -1 for the index indicates a problem
            PlotContour(IndexToPlot);
            GetContour();
        }

        private void findMinButton_Click(object sender, EventArgs e)
        {
            if (submodelListBox1.SelectedItem == null) return;
            int IndexToPlot = GetIndex(2);
            if (IndexToPlot == -1) return;  // -1 for the index indicates a problem
            PlotContour(IndexToPlot);
            GetContour();
        }

        /// <summary>
        /// Searches data arrays for min or max values
        /// </summary>
        /// <param name="v"></param>
        /// <returns>Index for maximum or minimum of selected submodel or -1 for error</returns>
        private int GetIndex(int v)
        {
            OpenTDv242.Results.Dataset.Dataset dataOutput;
            try { dataOutput = new SaveFile(saveFilePath + @"\contours.sav"); }
            catch { dataOutput = null; return -1; }
            var subNodes = new ItemIdentifierCollection(DataTypes.NODE, submodelListBox1.SelectedItem.ToString(), dataOutput);
            if (subNodes == null) return -1;
            var subTs = dataOutput.GetData(subNodes, StandardDataSubtypes.T);

            int index = -1;
            if (v == 1)
            {
                MaxDataArray maxTArray = new MaxDataArray(subTs);
                double maxValue = double.MinValue;
                var values = maxTArray.GetValues();
                for (int i = 0; i < values.Count; i++)
                {
                    if (values[i] > maxValue)
                    {
                        maxValue = values[i];
                        index = i;
                    }
                }
            }
            else
            {
                MinDataArray minTArray = new MinDataArray(subTs);
                double minValue = double.MaxValue;
                var values = minTArray.GetValues();
                for (int i = 0; i < values.Count; i++)
                {
                    if (values[i] < minValue)
                    {
                        minValue = values[i];
                        index = i;
                    }
                }
            }
            return index;
        }

        /// <summary>
        /// Sets contour dataset to specific time based on provided index
        /// </summary>
        private void PlotContour(int index)
        {
            OpenTDv242.PostProcessing.Dataset currentDataset = td.DatasetManager.GetCurrentDataset();
            currentDataset.CurrentTimeIndex = index;
            currentDataset.ShowContourPlot();
        }

        /// <summary>
        /// Set view, if any, and copy contour from dwg to program window
        /// </summary>
        private void GetContour()
        {
            if (viewListBox.SelectedItem != null)
            {
                switch (viewListBox.SelectedItem.ToString())
                {
                    case "Ortho TOP":
                        td.RestoreOrthoView(OrthoViews.TOP);
                        break;
                    case "Ortho BOTTOM":
                        td.RestoreOrthoView(OrthoViews.BOTTOM);
                        break;
                    case "Ortho FRONT":
                        td.RestoreOrthoView(OrthoViews.FRONT);
                        break;
                    case "Ortho BACK":
                        td.RestoreOrthoView(OrthoViews.BACK);
                        break;
                    case "Ortho LEFT":
                        td.RestoreOrthoView(OrthoViews.LEFT);
                        break;
                    case "Ortho RIGHT":
                        td.RestoreOrthoView(OrthoViews.RIGHT);
                        break;
                    case "Iso SW":
                        td.RestoreIsoView(IsoViews.SW);
                        break;
                    case "Iso SE":
                        td.RestoreIsoView(IsoViews.SE);
                        break;
                    case "Iso NE":
                        td.RestoreIsoView(IsoViews.NE);
                        break;
                    case "Iso NW":
                        td.RestoreIsoView(IsoViews.NW);
                        break;
                    default:
                        td.RestoreView(viewListBox.SelectedItem.ToString());
                        break;
                }

                td.UpdateGraphics();
            }

            Bitmap bmp = td.CaptureGraphicsArea();
            contourPictureBox.Image = bmp;
        }

        private void ContourFinderDialog_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (td != null)
                try { td.Quit(); } catch { }
        }
    }
}
