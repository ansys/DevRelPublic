using OpenTDv242;

namespace OpenTDv242Demos.ContourFinder
{
    public class ContourFinderDemo : Script
    {
        public override string GetName()
        {
            return "Contour Finder";
        }
        public override string GetDescription()
        {
            return "Finds and returns maximum or minimum color contours by submodel for a transient";
        }
        public override string GetKeywords()
        {
            return "postprocessing post-processing contour results save csr datasets maximum minimum";
        }
        public override void Run()
        {
            ContourFinderDialog d = new ContourFinderDialog();
            d.ShowDialog();
        }
    }
}