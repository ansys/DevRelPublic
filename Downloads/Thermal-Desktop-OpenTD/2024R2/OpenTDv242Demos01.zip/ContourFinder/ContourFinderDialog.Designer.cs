namespace OpenTDv242Demos.ContourFinder
{
    partial class ContourFinderDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ContourFinderDialog));
            this.openDwgButton = new System.Windows.Forms.Button();
            this.submodelListBox1 = new System.Windows.Forms.ListBox();
            this.findMaxButton = new System.Windows.Forms.Button();
            this.findMinButton = new System.Windows.Forms.Button();
            this.contourPictureBox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.viewListBox = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.contourPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // openDwgButton
            // 
            this.openDwgButton.Location = new System.Drawing.Point(8, 20);
            this.openDwgButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.openDwgButton.Name = "openDwgButton";
            this.openDwgButton.Size = new System.Drawing.Size(133, 32);
            this.openDwgButton.TabIndex = 0;
            this.openDwgButton.Text = "Open DWG";
            this.openDwgButton.UseVisualStyleBackColor = true;
            this.openDwgButton.Click += new System.EventHandler(this.openDwgButton_Click);
            // 
            // submodelListBox1
            // 
            this.submodelListBox1.FormattingEnabled = true;
            this.submodelListBox1.Location = new System.Drawing.Point(8, 75);
            this.submodelListBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.submodelListBox1.Name = "submodelListBox1";
            this.submodelListBox1.Size = new System.Drawing.Size(135, 225);
            this.submodelListBox1.TabIndex = 1;
            // 
            // findMaxButton
            // 
            this.findMaxButton.Enabled = false;
            this.findMaxButton.Location = new System.Drawing.Point(8, 569);
            this.findMaxButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.findMaxButton.Name = "findMaxButton";
            this.findMaxButton.Size = new System.Drawing.Size(133, 32);
            this.findMaxButton.TabIndex = 2;
            this.findMaxButton.Text = "Find Max Contour";
            this.findMaxButton.UseVisualStyleBackColor = true;
            this.findMaxButton.Click += new System.EventHandler(this.findMaxButton_Click);
            // 
            // findMinButton
            // 
            this.findMinButton.Enabled = false;
            this.findMinButton.Location = new System.Drawing.Point(8, 621);
            this.findMinButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.findMinButton.Name = "findMinButton";
            this.findMinButton.Size = new System.Drawing.Size(133, 32);
            this.findMinButton.TabIndex = 3;
            this.findMinButton.Text = "Find Min Contour";
            this.findMinButton.UseVisualStyleBackColor = true;
            this.findMinButton.Click += new System.EventHandler(this.findMinButton_Click);
            // 
            // contourPictureBox
            // 
            this.contourPictureBox.Location = new System.Drawing.Point(161, 20);
            this.contourPictureBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.contourPictureBox.Name = "contourPictureBox";
            this.contourPictureBox.Size = new System.Drawing.Size(1023, 668);
            this.contourPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.contourPictureBox.TabIndex = 4;
            this.contourPictureBox.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 58);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(107, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Submodels - Select 1";
            // 
            // viewListBox
            // 
            this.viewListBox.FormattingEnabled = true;
            this.viewListBox.Location = new System.Drawing.Point(8, 340);
            this.viewListBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.viewListBox.Name = "viewListBox";
            this.viewListBox.Size = new System.Drawing.Size(135, 212);
            this.viewListBox.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 325);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(104, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Views - Select 0 or 1";
            // 
            // ContourFinderDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1210, 705);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.viewListBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.contourPictureBox);
            this.Controls.Add(this.findMinButton);
            this.Controls.Add(this.findMaxButton);
            this.Controls.Add(this.submodelListBox1);
            this.Controls.Add(this.openDwgButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "ContourFinderDialog";
            this.Text = "Contour Finder";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ContourFinderDialog_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.contourPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button openDwgButton;
        private System.Windows.Forms.ListBox submodelListBox1;
        private System.Windows.Forms.Button findMaxButton;
        private System.Windows.Forms.Button findMinButton;
        private System.Windows.Forms.PictureBox contourPictureBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox viewListBox;
        private System.Windows.Forms.Label label2;
    }
}