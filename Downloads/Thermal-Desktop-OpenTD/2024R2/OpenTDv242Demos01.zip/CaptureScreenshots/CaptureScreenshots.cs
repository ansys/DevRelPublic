using OpenTDv242;

namespace OpenTDv242Demos
{
    public class CaptureScreenshots : Script
    {
        public override string GetName()
        {
            return "Screenshot capture";
        }
        public override string GetDescription()
        {
            return "Create pics of model at various angles";
        }
        public override string GetKeywords()
        {
            return "postprocessing post-processing view bmp png bitmap picture";
        }

        public override void Run()
        {
            CaptureScreenshotsDialog d = new CaptureScreenshotsDialog();
            d.ShowDialog();
        }
    }
}
