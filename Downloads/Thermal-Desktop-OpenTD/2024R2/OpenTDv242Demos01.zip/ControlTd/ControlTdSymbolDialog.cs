using System;
using System.Windows.Forms;
using OpenTDv242;

namespace OpenTDv242Demos
{
    public partial class ControlTdSymbolDialog : Form
    {
        public ControlTdSymbolDialog(ThermalDesktop TD, Symbol Symbol)
        {
            InitializeComponent();
            td = TD;
            symbol = Symbol;
            SymbolName = symbol.Name;
            SymbolValue = symbol.Value;
        }

        private ThermalDesktop td { get; set; }
        private Symbol symbol { get; set; }
        private string SymbolName { get { return SymbolNameLabel.Text; } set { SymbolNameLabel.Text = value; } }
        private string SymbolValue { get { return ValueTextBox.Text; } set { ValueTextBox.Text = value; } }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            symbol.Value = SymbolValue;
            symbol.Update();
            Close();
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
