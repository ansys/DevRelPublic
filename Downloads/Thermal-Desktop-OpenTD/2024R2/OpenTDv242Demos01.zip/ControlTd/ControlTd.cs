using OpenTDv242;

namespace OpenTDv242Demos
{
    public class ControlTd : Script
    {
        public override string GetDescription()
        {
            return "Update symbols, run cases, and issue AutoCAD commands (similar to old COM controller)";
        }

        public override string GetName()
        {
            return "Control TD";
        }
        public override string GetKeywords()
        {
            return "sinda symbol matlab com";
        }
        public override void Run()
        {
            ControlTdDialog d = new ControlTdDialog();
            d.ShowDialog();
        }
    }
}
