using System;

namespace OpenTDv242Demos.Snake
{
    class PelletsEatenEventArgs : EventArgs
    {
        public PelletsEatenEventArgs(int pelletsEaten)
        {
            PelletsEaten = pelletsEaten;
        }

        public int PelletsEaten { get; set; }
    }
}
