using System;

namespace OpenTDv242Demos.Snake
{
    class TickEventArgs : EventArgs
    {
        public TickEventArgs(long total_ms, long timeSincePrev_ms)
        {
            TotalElapsedTime_ms = total_ms;
            TimeSincePreviousTick_ms = timeSincePrev_ms;
        }

        public long TotalElapsedTime_ms { get; set; }
        public long TimeSincePreviousTick_ms { get; set; }
    }
}
