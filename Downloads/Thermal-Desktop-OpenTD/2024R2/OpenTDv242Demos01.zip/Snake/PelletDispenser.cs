using System;
using OpenTDv242;
using OpenTDv242.Dimension;
using OpenTDv242.RadCAD.FdSolid;

namespace OpenTDv242Demos.Snake
{
    class PelletDispenser
    {
        public PelletDispenser(Board _board, Snake _snake)
        {
            board = _board;
            snake = _snake;
            td = board.td;

            PelletDiameter = 0.9 * board.GridSize;
            PelletColorIndex = 1;
            rand = new Random();
        }

        ~PelletDispenser()
        {
            try
            {
                DeletePellet();
            }
            catch { }
        }

        static Random rand;
        public void Dispense()
        {
            DeletePellet();
            bool foundPosition = false;
            Position pos = new Position();
            while (!foundPosition)
            {
                int U = rand.Next(2, board.GridNumU);
                int V = rand.Next(2, board.GridNumV);
                pos = new Position(U, V);
                if (!snake.IsInSnake(pos))
                    foundPosition = true;
            }
            DrawPellet(pos);
            if (Dispensed != null)
            {
                Dispensed(this, new PositionEventArgs(pos));
            }
        }
        public EventHandler<PositionEventArgs> Dispensed;

        public void OnPelletEaten(object sender, EventArgs e)
        {
            Dispense();
        }

        void DrawPellet(Position pos)
        {
            Point3d origin = board.GetCoordinates(pos)
                    + board.GridSize / 2 * board.Up
                    + board.GridSize / 2 * board.Right
                    + PelletDiameter / 2 * board.Normal;
            pellet = td.CreateSolidSphere();
            pellet.Rmax = PelletDiameter / 2;
            pellet.BaseTrans.SetOrigin(origin);
            pellet.ColorIndex = PelletColorIndex;
            pellet.Update();
        }

        public void DeletePellet()
        {
            if (pellet != null)
            {
                td.DeleteEntity(pellet);
                pellet = null;
            }
        }

        Dimensional<ModelLength> PelletDiameter { get; set; }

        public int PelletColorIndex { get; set; }

        SolidSphere pellet { get; set; }
        Board board { get; set; }
        Snake snake { get; set; }
        ThermalDesktop td { get; set; }
    }
}
