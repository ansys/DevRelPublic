using System;
using System.Diagnostics;
using System.Threading;
using OpenTDv242;

namespace OpenTDv242Demos.Snake
{
    class Game
    {
        public Game(ThermalDesktop _td)
        {
            td = _td;
            Running = false;
        }

        public int PelletsEaten { get; private set; }
        void OnPelletEaten(object sender, EventArgs e)
        {
            PelletsEaten++;
            if (PelletEaten != null)
            {
                PelletEaten(this, new PelletsEatenEventArgs(PelletsEaten));
            }
        }
        public EventHandler<PelletsEatenEventArgs> PelletEaten;

        public void Reset()
        {
            if (pelletDispenser != null)
            {
                try { pelletDispenser.DeletePellet(); }
                catch { }
            }
            if (snake != null)
            {
                try { snake.Delete(); }
                catch { }
            }
            if (board != null)
            {
                try { board.Delete(); }
                catch { }
            }

            PelletsEaten = 0;
            if (PelletEaten != null)
            {
                PelletEaten(this, new PelletsEatenEventArgs(PelletsEaten));
            }

            board = new Board(td);
            board.Draw();

            snake = new Snake(board, new Position(5, 5), 8);
            snake.Facing = Directions.UP;
            snake.MovePeriodms = 300; // move snake 1 grid every MovePeriodms ms
            snake.SpeedUpPeriodms = 25000; // every SpeedUpPeriodms ms, speed up snake
            snake.SpeedUpAmountms = 50; // decrease snake move period by this amount to speed up
            snake.MinMovePeriodms = 150;

            tickPeriod_ms = (int)(0.5 * snake.MinMovePeriodms);
            Tick += snake.OnTick;

            pelletDispenser = new PelletDispenser(board, snake);
            pelletDispenser.Dispensed += board.OnPelletDispensed;
            snake.AtePellet += pelletDispenser.OnPelletEaten;
            snake.AtePellet += OnPelletEaten;
            pelletDispenser.Dispense();

            td.SetVisualStyle(VisualStyles.THERMAL);
            td.RestoreIsoView(IsoViews.SW);
            td.ZoomExtents();

            StopRequested = false;
        }

        public void Run()
        {
            Stopwatch sw = new Stopwatch();
            sw.Restart();
            previousTickTime_ms = 0;

            if (GameStart != null)
            {
                GameStart(this, new EventArgs());
            }

            // game loop
            Running = true;
            while (!snake.Dead && !StopRequested)
            {
                long t = sw.ElapsedMilliseconds;

                // if it's a long time until next tick, sleep thread to avoid busy spin:
                long timeUntilNextTick_ms = nextTickTime_ms - t;
                long minWaitTime = (long)(minWaitTimeFactor * tickPeriod_ms);
                if (timeUntilNextTick_ms > minWaitTime)
                {
                    int waitTime = (int)(maxWaitTimeFactor * timeUntilNextTick_ms);
                    Thread.Sleep(waitTime);
                }

                if (t >= nextTickTime_ms)
                    DoTick(t);
            }
            Running = false;

            if (GameOver != null)
            {
                GameOver(this, new PelletsEatenEventArgs(PelletsEaten));
            }
        }

        public bool Running { get; set; }

        public EventHandler GameStart;
        public EventHandler<TickEventArgs> Tick;
        public EventHandler<PelletsEatenEventArgs> GameOver;

        public void OnStopRequested(object sender, EventArgs e)
        {
            StopRequested = true;
        }
        bool StopRequested { get; set; }

        public void Up(object sender, EventArgs e)
        {
            if (snake != null)
                snake.Facing = Directions.UP;
        }
        public void Down(object sender, EventArgs e)
        {
            if (snake != null)
                snake.Facing = Directions.DOWN;
        }
        public void Left(object sender, EventArgs e)
        {
            if (snake != null)
                snake.Facing = Directions.LEFT;
        }
        public void Right(object sender, EventArgs e)
        {
            if (snake != null)
                snake.Facing = Directions.RIGHT;
        }

        Board board { get; set; }
        Snake snake { get; set; }
        PelletDispenser pelletDispenser { get; set; }
        ThermalDesktop td { get; set; }

        int tickPeriod_ms;
        long previousTickTime_ms;
        long nextTickTime_ms;
        double minWaitTimeFactor = 0.2; // minimum allowed waiting time; fraction of tickPeriod
        double maxWaitTimeFactor = 0.8; // maximum allowed waiting time; fraction of time until next tick     

        void DoTick(long currentTime)
        {
            if (Tick != null)
            {
                Tick(this, new TickEventArgs(currentTime, currentTime - previousTickTime_ms));
            }
            previousTickTime_ms = currentTime;
            nextTickTime_ms = currentTime + tickPeriod_ms;
        }
    }
}
