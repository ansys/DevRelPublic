using System;
using System.IO;
using OpenTDv242;
using OpenTDv242.UserInterface;

namespace OpenTDv242Demos
{
    public class Truss : Script
    {
        public override string GetName()
        {
            return "Truss";
        }
        public override string GetDescription()
        {
            return "Vary the topology of a model";
        }
        public override string GetKeywords()
        {
            return "nodes conductors topology symbols";
        }

        public override void Run()
        {
            Console.WriteLine("Connecting to Thermal Desktop...");
            ThermalDesktop td = new ThermalDesktop(Path.Combine(Script.WorkingDirectory, "common.dwg"));
            td.Connect();

            Console.WriteLine("Passing control to Truss dialog...");
            TrussDialog d = new TrussDialog();
            d.td = td;
            d.ShowDialog();
        }
    }
}
