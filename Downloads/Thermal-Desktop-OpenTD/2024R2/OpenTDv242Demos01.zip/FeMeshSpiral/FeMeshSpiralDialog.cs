using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using OpenTDv242;

namespace OpenTDv242Demos.FeMeshSpiral
{
    public partial class FeMeshSpiralDialog : Form
    {
        public FeMeshSpiralDialog()
        {
            InitializeComponent();
            textBoxIR.Text = (trackBarIR.Value / 10f).ToString();
            textBoxTh.Text = (trackBarTh.Value / 10f).ToString();
            textBoxHeight.Text = (trackBarHeight.Value / 100f).ToString();
            textBoxPitch.Text = (trackBarPitch.Value / 10f).ToString();
            textBoxRots.Text = trackBarRots.Value.ToString();            
        }
        public ThermalDesktop td { get; set; }

        private void buttonCreateMesh_Click(object sender, EventArgs e)
        {
            
            double irad = double.Parse(textBoxIR.Text);
            int rots = int.Parse(textBoxRots.Text);
            double thick = double.Parse(textBoxTh.Text);
            double pitch = double.Parse(textBoxPitch.Text);
            double height = double.Parse(textBoxHeight.Text);
            
            td = new ThermalDesktop(Path.Combine(Script.WorkingDirectory, "common.dwg"));            
            td.Connect();

            DeleteModel();
            var femesh = new OpenTDv242.RadCAD.FEModel.FEMesh();

            // This For loop is building the mesh network. Elements are not created yet. The mesh spirals about the Z axis.
            // See associated project image NodeLocations.jpg. Each curved solid element will consist of 8 "full" nodes and 12 "midside" nodes.
            // Full nodes are given small numbers (1-8) while the midside nodes are given node numbers of over 10000. 
            // Each solid element will share 4 real nodes and 4 midside nodes with the next/previous element. 
            // The mesh network is constructed one verical "slice" (Z axis and line from origin) at a time. This will NOT be the same for creating the elements.

            // This For loop will create two such vertical slices each iteration since the pattern will be:
            // Slice 1 contains 4 full nodes and 4 midside nodes. Slice 2 contains 4 midside nodes.

            // The image shows the nodes of the first two elements created. The first element has thicker lines. 
            // The first slice will be nodes 1, 10001, 2, 10002, 3, 10003, 4, 10004.
            // The second slice will be 10005, 10006, 10007, 10008.

            for (int i = 0; i <= rots * 20; i++)
            {

                var node1 = new OpenTDv242.RadCAD.FEModel.Node()
                { x = irad * Math.Cos(d2r(i * 18)), y = irad * Math.Sin(d2r(i * 18)), z = pitch * 0.05 * i, id = 4 * i + 1 };
                femesh.nodes.Add(node1);

                var node2 = new OpenTDv242.RadCAD.FEModel.Node()
                { x = (irad + thick) * Math.Cos(d2r(i * 18)), y = (irad + thick) * Math.Sin(d2r(i * 18)), z = pitch * 0.05 * i, id = 4 * i + 2 };
                femesh.nodes.Add(node2);

                var node3 = new OpenTDv242.RadCAD.FEModel.Node()
                { x = (irad + thick) * Math.Cos(d2r(i * 18)), y = (irad + thick) * Math.Sin(d2r(i * 18)), z = height + pitch * 0.05 * i, id = 4 * i + 3 };
                femesh.nodes.Add(node3);

                var node4 = new OpenTDv242.RadCAD.FEModel.Node()
                { x = irad * Math.Cos(d2r(i * 18)), y = irad * Math.Sin(d2r(i * 18)), z = height + pitch * 0.05 * i, id = 4 * i + 4 };
                femesh.nodes.Add(node4);

                var node10001 = new OpenTDv242.RadCAD.FEModel.Node()
                { x = (irad + thick / 2) * Math.Cos(d2r(i * 18)), y = (irad + thick / 2) * Math.Sin(d2r(i * 18)), z = pitch * 0.05 * i, id = 8 * i + 10001 };
                femesh.nodes.Add(node10001);

                var node10002 = new OpenTDv242.RadCAD.FEModel.Node()
                { x = (irad + thick) * Math.Cos(d2r(i * 18)), y = (irad + thick) * Math.Sin(d2r(i * 18)), z = height / 2 + pitch * 0.05 * i, id = 8 * i + 10002 };
                femesh.nodes.Add(node10002);

                var node10003 = new OpenTDv242.RadCAD.FEModel.Node()
                { x = (irad + thick / 2) * Math.Cos(d2r(i * 18)), y = (irad + thick / 2) * Math.Sin(d2r(i * 18)), z = height + pitch * 0.05 * i, id = 8 * i + 10003 };
                femesh.nodes.Add(node10003);

                var node10004 = new OpenTDv242.RadCAD.FEModel.Node()
                { x = irad * Math.Cos(d2r(i * 18)), y = irad * Math.Sin(d2r(i * 18)), z = height / 2 + pitch * 0.05 * i, id = 8 * i + 10004 };
                femesh.nodes.Add(node10004);

                // The very last part of the mesh does not need a "slice 2" since the mesh will end on a "slice 1"
                if (i != rots * 20)
                {
                    var node10005 = new OpenTDv242.RadCAD.FEModel.Node()
                    { x = irad * Math.Cos(d2r(i * 18 + 9)), y = irad * Math.Sin(d2r(i * 18 + 9)), z = pitch * (.025 + 0.05 * i), id = 8 * i + 10005 };
                    femesh.nodes.Add(node10005);

                    var node10006 = new OpenTDv242.RadCAD.FEModel.Node()
                    { x = (irad + thick) * Math.Cos(d2r(i * 18 + 9)), y = (irad + thick) * Math.Sin(d2r(i * 18 + 9)), z = pitch * (.025 + 0.05 * i), id = 8 * i + 10006 };
                    femesh.nodes.Add(node10006);

                    var node10007 = new OpenTDv242.RadCAD.FEModel.Node()
                    { x = (irad + thick) * Math.Cos(d2r(i * 18 + 9)), y = (irad + thick) * Math.Sin(d2r(i * 18 + 9)), z = height + pitch * (.025 + 0.05 * i), id = 8 * i + 10007 };
                    femesh.nodes.Add(node10007);

                    var node10008 = new OpenTDv242.RadCAD.FEModel.Node()
                    { x = irad * Math.Cos(d2r(i * 18 + 9)), y = irad * Math.Sin(d2r(i * 18 + 9)), z = height + pitch * (.025 + 0.05 * i), id = 8 * i + 10008 };
                    femesh.nodes.Add(node10008);
                }

            }


            // This For loop will create the repeating elements. First are brick elements. Note the order of the node selection. 
            // The order begins with the full nodes, which follow the right-hand rule in a loop from the bottom and then the top.
            // Then the midside nodes are added. These also follow the right hand rule starting either between full nodes 1 and 2 or above node 1. 
            for (int i = 0; i < rots * 20; i++)
            {
                var brick = new OpenTDv242.RadCAD.FEModel.SolidElement();
                brick.numNodes = 8;
                brick.order = 2;
                brick.id = i + 1;
                brick.material = "aluminum";
                brick.nodeIds.Add(4 * i + 1);
                brick.nodeIds.Add(4 * i + 2);
                brick.nodeIds.Add(4 * i + 6);
                brick.nodeIds.Add(4 * i + 5);
                brick.nodeIds.Add(4 * i + 4);
                brick.nodeIds.Add(4 * i + 3);
                brick.nodeIds.Add(4 * i + 7);
                brick.nodeIds.Add(4 * i + 8);
                brick.midSideNodeIds.Add(8 * i + 10001);
                brick.midSideNodeIds.Add(8 * i + 10006);
                brick.midSideNodeIds.Add(8 * i + 10009);
                brick.midSideNodeIds.Add(8 * i + 10005);
                brick.midSideNodeIds.Add(8 * i + 10004);
                brick.midSideNodeIds.Add(8 * i + 10002);
                brick.midSideNodeIds.Add(8 * i + 10010);
                brick.midSideNodeIds.Add(8 * i + 10012);
                brick.midSideNodeIds.Add(8 * i + 10003);
                brick.midSideNodeIds.Add(8 * i + 10007);
                brick.midSideNodeIds.Add(8 * i + 10011);
                brick.midSideNodeIds.Add(8 * i + 10008);

                femesh.solidElements.Add(brick);

                // These surface elements just follow the right hand rule, full nodes followed by midside nodes.
                var top = new OpenTDv242.RadCAD.FEModel.SurfaceElement();
                top.numNodes = 4;
                top.order = 2;
                top.id = i + 10001;
                top.nodeIds.Add(4 * i + 4);
                top.nodeIds.Add(4 * i + 3);
                top.nodeIds.Add(4 * i + 7);
                top.nodeIds.Add(4 * i + 8);
                top.midSideNodeIds.Add(8 * i + 10003);
                top.midSideNodeIds.Add(8 * i + 10007);
                top.midSideNodeIds.Add(8 * i + 10011);
                top.midSideNodeIds.Add(8 * i + 10008);
                femesh.surfaceElements.Add(top);

                var bottom = new OpenTDv242.RadCAD.FEModel.SurfaceElement();
                bottom.numNodes = 4;
                bottom.order = 2;
                bottom.id = i + 20001;
                bottom.nodeIds.Add(4 * i + 1);
                bottom.nodeIds.Add(4 * i + 5);
                bottom.nodeIds.Add(4 * i + 6);
                bottom.nodeIds.Add(4 * i + 2);
                bottom.midSideNodeIds.Add(8 * i + 10005);
                bottom.midSideNodeIds.Add(8 * i + 10009);
                bottom.midSideNodeIds.Add(8 * i + 10006);
                bottom.midSideNodeIds.Add(8 * i + 10001);
                femesh.surfaceElements.Add(bottom);

                var inner = new OpenTDv242.RadCAD.FEModel.SurfaceElement();
                inner.numNodes = 4;
                inner.order = 2;
                inner.id = i + 30001;
                inner.nodeIds.Add(4 * i + 1);
                inner.nodeIds.Add(4 * i + 4);
                inner.nodeIds.Add(4 * i + 8);
                inner.nodeIds.Add(4 * i + 5);
                inner.midSideNodeIds.Add(8 * i + 10004);
                inner.midSideNodeIds.Add(8 * i + 10008);
                inner.midSideNodeIds.Add(8 * i + 10012);
                inner.midSideNodeIds.Add(8 * i + 10005);
                femesh.surfaceElements.Add(inner);

                var outer = new OpenTDv242.RadCAD.FEModel.SurfaceElement();
                outer.numNodes = 4;
                outer.order = 2;
                outer.id = i + 40001;
                outer.nodeIds.Add(4 * i + 2);
                outer.nodeIds.Add(4 * i + 6);
                outer.nodeIds.Add(4 * i + 7);
                outer.nodeIds.Add(4 * i + 3);
                outer.midSideNodeIds.Add(8 * i + 10006);
                outer.midSideNodeIds.Add(8 * i + 10010);
                outer.midSideNodeIds.Add(8 * i + 10007);
                outer.midSideNodeIds.Add(8 * i + 10002);
                femesh.surfaceElements.Add(outer);
            }

            // The first and last surface elements are simple rectangles.
            var first = new OpenTDv242.RadCAD.FEModel.SurfaceElement();
            first.numNodes = 4;
            first.order = 1;
            first.id = 50001;
            first.nodeIds.Add(1);
            first.nodeIds.Add(2);
            first.nodeIds.Add(3);
            first.nodeIds.Add(4);
            femesh.surfaceElements.Add(first);

            var last = new OpenTDv242.RadCAD.FEModel.SurfaceElement();
            last.numNodes = 4;
            last.order = 1;
            last.id = 60001;
            last.nodeIds.Add(rots * 80 + 1);
            last.nodeIds.Add(rots * 80 + 4);
            last.nodeIds.Add(rots * 80 + 3);
            last.nodeIds.Add(rots * 80 + 2);
            femesh.surfaceElements.Add(last);

            var meshImporter = td.CreateFEMeshImporter("Spiral", false);
            meshImporter.SetMesh(femesh);       
            
            // FACETRES is an AutoCAD variable with a default value of 0.5, which will make the mesh appear to have straight edges. 2.0 will show the curves
            td.SetAutocadVariable("FACETRES", 2.0);
            td.UpdateGraphics();
            td.RestoreIsoView(IsoViews.NE);
            td.SetVisualStyle(VisualStyles.THERMAL);
            td.ZoomExtents();


        }
        /// <summary>
        /// C# wants radians, not degrees
        /// </summary>
        /// <param name="degrees"></param>
        /// <returns></returns>
        double d2r(double degrees)
        {
            return degrees * Math.PI / 180.0;
        }

        private void trackBarIR_ValueChanged(object sender, EventArgs e)
        {
            textBoxIR.Text = (trackBarIR.Value / 10f).ToString();
        }

        private void trackBarTh_ValueChanged(object sender, EventArgs e)
        {
            textBoxTh.Text = (trackBarTh.Value / 10f).ToString();
        }

        private void trackBarHeight_ValueChanged(object sender, EventArgs e)
        {
            textBoxHeight.Text = (trackBarHeight.Value / 100f).ToString();
        }

        private void trackBarPitch_ValueChanged(object sender, EventArgs e)
        {
            textBoxPitch.Text = (trackBarPitch.Value / 10f).ToString();
        }

        private void trackBarRots_ValueChanged(object sender, EventArgs e)
        {
            textBoxRots.Text = trackBarRots.Value.ToString();
        }

        private void DeleteModel()
        {
            if (td == null)
                return;

           // delete existing mesh
            List<OpenTDv242.RadCAD.FEMeshImporter> meshes = td.GetFEMeshImporters();
            if (meshes.Count != 0)
            {
                foreach (OpenTDv242.RadCAD.FEMeshImporter mesh in meshes)
                  td.DeleteEntity(mesh);
            }
            td.UpdateGraphics();
        }

        private void FeMeshSpiralDialog_FormClosing(object sender, FormClosingEventArgs e)
        {
            DeleteModel();
        }
    }
}
