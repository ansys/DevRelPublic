namespace OpenTDv242Demos.FeMeshSpiral
{
    partial class FeMeshSpiralDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FeMeshSpiralDialog));
            this.trackBarIR = new System.Windows.Forms.TrackBar();
            this.trackBarTh = new System.Windows.Forms.TrackBar();
            this.trackBarHeight = new System.Windows.Forms.TrackBar();
            this.trackBarPitch = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.trackBarRots = new System.Windows.Forms.TrackBar();
            this.textBoxIR = new System.Windows.Forms.TextBox();
            this.textBoxTh = new System.Windows.Forms.TextBox();
            this.textBoxHeight = new System.Windows.Forms.TextBox();
            this.textBoxPitch = new System.Windows.Forms.TextBox();
            this.textBoxRots = new System.Windows.Forms.TextBox();
            this.buttonCreateMesh = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarIR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarTh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarPitch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarRots)).BeginInit();
            this.SuspendLayout();
            // 
            // trackBarIR
            // 
            this.trackBarIR.Location = new System.Drawing.Point(280, 40);
            this.trackBarIR.Maximum = 100;
            this.trackBarIR.Minimum = 10;
            this.trackBarIR.Name = "trackBarIR";
            this.trackBarIR.Size = new System.Drawing.Size(240, 69);
            this.trackBarIR.SmallChange = 10;
            this.trackBarIR.TabIndex = 0;
            this.trackBarIR.Value = 30;
            this.trackBarIR.ValueChanged += new System.EventHandler(this.trackBarIR_ValueChanged);
            // 
            // trackBarTh
            // 
            this.trackBarTh.Location = new System.Drawing.Point(280, 100);
            this.trackBarTh.Maximum = 50;
            this.trackBarTh.Minimum = 1;
            this.trackBarTh.Name = "trackBarTh";
            this.trackBarTh.Size = new System.Drawing.Size(240, 69);
            this.trackBarTh.TabIndex = 1;
            this.trackBarTh.Value = 4;
            this.trackBarTh.ValueChanged += new System.EventHandler(this.trackBarTh_ValueChanged);
            // 
            // trackBarHeight
            // 
            this.trackBarHeight.Location = new System.Drawing.Point(280, 160);
            this.trackBarHeight.Maximum = 50;
            this.trackBarHeight.Minimum = 10;
            this.trackBarHeight.Name = "trackBarHeight";
            this.trackBarHeight.Size = new System.Drawing.Size(240, 69);
            this.trackBarHeight.TabIndex = 2;
            this.trackBarHeight.Value = 25;
            this.trackBarHeight.ValueChanged += new System.EventHandler(this.trackBarHeight_ValueChanged);
            // 
            // trackBarPitch
            // 
            this.trackBarPitch.Location = new System.Drawing.Point(280, 220);
            this.trackBarPitch.Maximum = 50;
            this.trackBarPitch.Minimum = 10;
            this.trackBarPitch.Name = "trackBarPitch";
            this.trackBarPitch.Size = new System.Drawing.Size(240, 69);
            this.trackBarPitch.TabIndex = 3;
            this.trackBarPitch.Value = 14;
            this.trackBarPitch.ValueChanged += new System.EventHandler(this.trackBarPitch_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(40, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Inner Radius (m)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 100);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(223, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Thickness (m) (radial direction)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(192, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Height (m) (axial direction)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(40, 220);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 20);
            this.label4.TabIndex = 7;
            this.label4.Text = "Pitch (m)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(40, 280);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 20);
            this.label5.TabIndex = 8;
            this.label5.Text = "Number of Rotations";
            // 
            // trackBarRots
            // 
            this.trackBarRots.Location = new System.Drawing.Point(280, 280);
            this.trackBarRots.Maximum = 20;
            this.trackBarRots.Minimum = 1;
            this.trackBarRots.Name = "trackBarRots";
            this.trackBarRots.Size = new System.Drawing.Size(240, 69);
            this.trackBarRots.TabIndex = 9;
            this.trackBarRots.Value = 6;
            this.trackBarRots.ValueChanged += new System.EventHandler(this.trackBarRots_ValueChanged);
            // 
            // textBoxIR
            // 
            this.textBoxIR.Location = new System.Drawing.Point(540, 40);
            this.textBoxIR.Name = "textBoxIR";
            this.textBoxIR.ReadOnly = true;
            this.textBoxIR.Size = new System.Drawing.Size(100, 26);
            this.textBoxIR.TabIndex = 10;
            // 
            // textBoxTh
            // 
            this.textBoxTh.Location = new System.Drawing.Point(540, 100);
            this.textBoxTh.Name = "textBoxTh";
            this.textBoxTh.ReadOnly = true;
            this.textBoxTh.Size = new System.Drawing.Size(100, 26);
            this.textBoxTh.TabIndex = 11;
            // 
            // textBoxHeight
            // 
            this.textBoxHeight.Location = new System.Drawing.Point(540, 160);
            this.textBoxHeight.Name = "textBoxHeight";
            this.textBoxHeight.ReadOnly = true;
            this.textBoxHeight.Size = new System.Drawing.Size(100, 26);
            this.textBoxHeight.TabIndex = 12;
            // 
            // textBoxPitch
            // 
            this.textBoxPitch.Location = new System.Drawing.Point(540, 220);
            this.textBoxPitch.Name = "textBoxPitch";
            this.textBoxPitch.ReadOnly = true;
            this.textBoxPitch.Size = new System.Drawing.Size(100, 26);
            this.textBoxPitch.TabIndex = 13;
            // 
            // textBoxRots
            // 
            this.textBoxRots.Location = new System.Drawing.Point(540, 280);
            this.textBoxRots.Name = "textBoxRots";
            this.textBoxRots.ReadOnly = true;
            this.textBoxRots.Size = new System.Drawing.Size(100, 26);
            this.textBoxRots.TabIndex = 14;
            // 
            // buttonCreateMesh
            // 
            this.buttonCreateMesh.Location = new System.Drawing.Point(280, 367);
            this.buttonCreateMesh.Name = "buttonCreateMesh";
            this.buttonCreateMesh.Size = new System.Drawing.Size(233, 58);
            this.buttonCreateMesh.TabIndex = 15;
            this.buttonCreateMesh.Text = "Create Mesh";
            this.buttonCreateMesh.UseVisualStyleBackColor = true;
            this.buttonCreateMesh.Click += new System.EventHandler(this.buttonCreateMesh_Click);
            // 
            // FeMeshSpiralDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(721, 450);
            this.Controls.Add(this.buttonCreateMesh);
            this.Controls.Add(this.textBoxRots);
            this.Controls.Add(this.textBoxPitch);
            this.Controls.Add(this.textBoxHeight);
            this.Controls.Add(this.textBoxTh);
            this.Controls.Add(this.textBoxIR);
            this.Controls.Add(this.trackBarRots);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.trackBarPitch);
            this.Controls.Add(this.trackBarHeight);
            this.Controls.Add(this.trackBarTh);
            this.Controls.Add(this.trackBarIR);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FeMeshSpiralDialog";
            this.Text = "FE Mesh Spiral";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FeMeshSpiralDialog_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.trackBarIR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarTh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarPitch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarRots)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar trackBarIR;
        private System.Windows.Forms.TrackBar trackBarTh;
        private System.Windows.Forms.TrackBar trackBarHeight;
        private System.Windows.Forms.TrackBar trackBarPitch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TrackBar trackBarRots;
        private System.Windows.Forms.TextBox textBoxIR;
        private System.Windows.Forms.TextBox textBoxTh;
        private System.Windows.Forms.TextBox textBoxHeight;
        private System.Windows.Forms.TextBox textBoxPitch;
        private System.Windows.Forms.TextBox textBoxRots;
        private System.Windows.Forms.Button buttonCreateMesh;
    }
}