namespace OpenTDv242Demos
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.demosAvailableListBox = new System.Windows.Forms.ListBox();
            this.programBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.runSelected = new System.Windows.Forms.Button();
            this.form1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SearchTextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.programBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.form1BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // demosAvailableListBox
            // 
            this.demosAvailableListBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.demosAvailableListBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawVariable;
            this.demosAvailableListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.demosAvailableListBox.FormattingEnabled = true;
            this.demosAvailableListBox.HorizontalScrollbar = true;
            this.demosAvailableListBox.ItemHeight = 16;
            this.demosAvailableListBox.Location = new System.Drawing.Point(9, 39);
            this.demosAvailableListBox.Margin = new System.Windows.Forms.Padding(2);
            this.demosAvailableListBox.Name = "demosAvailableListBox";
            this.demosAvailableListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.demosAvailableListBox.Size = new System.Drawing.Size(554, 300);
            this.demosAvailableListBox.TabIndex = 0;
            this.demosAvailableListBox.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.demosAvailableListBox_DrawItem);
            this.demosAvailableListBox.MeasureItem += new System.Windows.Forms.MeasureItemEventHandler(this.demosAvailableListBox_MeasureItem);
            this.demosAvailableListBox.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.demosAvailableListBox_MouseDoubleClick);
            // 
            // runSelected
            // 
            this.runSelected.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.runSelected.Location = new System.Drawing.Point(472, 357);
            this.runSelected.Margin = new System.Windows.Forms.Padding(2);
            this.runSelected.Name = "runSelected";
            this.runSelected.Size = new System.Drawing.Size(91, 27);
            this.runSelected.TabIndex = 4;
            this.runSelected.Text = "Run Selected";
            this.runSelected.UseVisualStyleBackColor = true;
            this.runSelected.Click += new System.EventHandler(this.runSelected_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 12);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Demos Available:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(299, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Search:";
            // 
            // SearchTextBox
            // 
            this.SearchTextBox.Location = new System.Drawing.Point(349, 9);
            this.SearchTextBox.Name = "SearchTextBox";
            this.SearchTextBox.Size = new System.Drawing.Size(214, 20);
            this.SearchTextBox.TabIndex = 10;
            this.SearchTextBox.TextChanged += new System.EventHandler(this.SearchTextBox_TextChanged);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(572, 396);
            this.Controls.Add(this.SearchTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.runSelected);
            this.Controls.Add(this.demosAvailableListBox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimumSize = new System.Drawing.Size(409, 435);
            this.Name = "MainMenu";
            this.Text = "Text";
            ((System.ComponentModel.ISupportInitialize)(this.programBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.form1BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox demosAvailableListBox;
        private System.Windows.Forms.BindingSource programBindingSource;
        private System.Windows.Forms.Button runSelected;
        private System.Windows.Forms.BindingSource form1BindingSource;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox SearchTextBox;
    }
}