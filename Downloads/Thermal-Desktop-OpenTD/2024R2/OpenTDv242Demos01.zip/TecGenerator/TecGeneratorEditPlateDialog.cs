using System;
using System.Windows.Forms;

namespace OpenTDv242Demos
{
    public partial class TecGeneratorEditPlateDialog : Form
    {
        public TecGeneratorEditPlateDialog(Plate x)
        {
            InitializeComponent();
            tecPlate = x;
            UpdateForm();
        }

        private Plate tecPlate;

        private void UpdateForm()
        {
            Xmm = (int)tecPlate.Xmm;
            Ymm = (int)tecPlate.Ymm;
            thickness_mm = (int)tecPlate.thickness_mm;
            material = tecPlate.material;
        }
        private void UpdateTec()
        {
            tecPlate.Xmm = Xmm;
            tecPlate.Ymm = Ymm;
            tecPlate.thickness_mm = thickness_mm;
            tecPlate.material = material;
        }

        private int Xmm
        {
            get { return (int)XmmNumericUpDown.Value; }
            set { XmmNumericUpDown.Value = value; }
        }
        private int Ymm
        {
            get { return (int)YmmNumericUpDown.Value; }
            set { YmmNumericUpDown.Value = value; }
        }
        private int thickness_mm
        {
            get { return (int)Thickness_mmNumericUpDown.Value; }
            set { Thickness_mmNumericUpDown.Value = value; }
        }
        private string material
        {
            get { return MaterialTextBox.Text; }
            set { MaterialTextBox.Text = value; }
        }

        private void OkButton_Click(object sender, EventArgs e)
        {
            UpdateTec();
            Close();
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
