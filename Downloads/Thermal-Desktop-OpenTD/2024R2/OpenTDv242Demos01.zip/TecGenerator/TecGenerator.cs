using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

using OpenTDv242;
using OpenTDv242.RadCAD;

namespace OpenTDv242Demos
{
    public class TecGenerator : Script
    {
        public override string GetDescription()
        {
            return "Create thermal models of thermoelectric coolers";
        }

        public override string GetName()
        {
            return "TEC Generator";
        }

        public override string GetKeywords()
        {
            return "finite difference fd surface tec thermoelectric cooler";
        }

        public override void Run()
        {
            TecGeneratorDialog d = new TecGeneratorDialog();
            d.ShowDialog();
        }

        public static void MakeTec(ThermalDesktop td, TecSpec tec, Point3d origin)
        {
            UnitsData tecWorkingUnits = new UnitsData();
            tecWorkingUnits.SetToSI();
            tecWorkingUnits.modelLength = UnitsData.ModelLength.MM;
            td.SetUnits(tecWorkingUnits);

            td.CreateLayer(tec.LayerName);
            td.CreateSubmodel(tec.SubmodelName);

            // materials
            TecGeneratorThermoPropsMaker.MakeMaterials(td);

            // keep track of our position in the stack
            Point3d currentOrigin = new Point3d(origin);
            Plate currentLowerPlateDef = tec.BasePlate;
            Rectangle currentLowerPlate = null;

            // create baseplate
            bool sameSideNumbering = true;
            currentLowerPlate = makePlate(td, tec.BasePlate, currentOrigin, tec.SubmodelName, tec.LayerName, sameSideNumbering);

            // create plates and TEC internals for each stage
            Queue<string> stageNames = new Queue<string>
                (new[] { "first", "second", "third", "fourth", "fifth", "sixth", "seventh", "eighth" });
            for (int i = 0; i < tec.Stages.Count; ++i)
            {
                Stage s = tec.Stages[i];
                string stageName = stageNames.Dequeue();
                currentOrigin += new Point3d(0, 0, s.Couples.Height_mm);
                // mid plates must not use sameSideNumbering
                if (i < tec.Stages.Count - 1)
                    sameSideNumbering = false;
                else
                    sameSideNumbering = true;
                Rectangle topPlate = makePlate(td, s.TopPlate, currentOrigin, tec.SubmodelName, tec.LayerName, sameSideNumbering);

                // create TD TEC entity
                Tec tdtec = td.CreateTec(new Connection(topPlate, 2), (Connection)currentLowerPlate);
                tdtec.Name = string.Format("{0} {1} stage", tec.Name, stageName);
                tdtec.CondSubmodel = tec.SubmodelName;
                tdtec.Layer = tec.LayerName;
                tdtec.TecNumCouples = s.Couples.N;
                tdtec.TecAspectRatioExp.units.modelLength = UnitsData.ModelLength.CM;
                tdtec.TecAspectRatioExp.Value = string.Format("{0}", s.Couples.GeometryFactorCM);
                tdtec.Update();

                // create contactor for epoxy fill
                if (tec.useEpoxy)
                {
                    // using the smaller of the two plates to calculate epoxy area:
                    double area_mm2 = Math.Min(currentLowerPlateDef.Area_mm2, s.TopPlate.Area_mm2);
                    // assuming all area not taken up by couples is epoxy:
                    double epoxyGeometryFactor_mm = area_mm2 / s.Couples.Height_mm
                                                  - 2 * s.Couples.N * s.Couples.GeometryFactorCM * 10;

                    Contactor epoxy = td.CreateContactor(new Connection(topPlate, 2), (Connection)currentLowerPlate);
                    epoxy.Name = string.Format("{0} {1} stage epoxy", tec.Name, stageName);
                    epoxy.CondSubmodel = tec.SubmodelName;
                    epoxy.Layer = tec.LayerName;
                    epoxy.UseMaterial = 1;
                    epoxy.ThermoMaterial = "Epoxy";
                    epoxy.InputValueType = Contactor.ContactorInputValueTypes.ABSOLUTE_ADJUST_FOR_UNCONNECTED;
                    epoxy.ContactCond = epoxyGeometryFactor_mm;
                    epoxy.Update();
                }

                currentLowerPlateDef = s.TopPlate;
                currentLowerPlate = topPlate;
            }

            // label TEC assembly
            Text label = td.CreateText(tec.Name);
            label.Origin = (origin
                + new Point3d(-tec.BasePlate.Xmm / 2, 0, -tec.Stages[0].Couples.Height_mm / 2));
            label.Layer = tec.LayerName;
            label.TextPercent = 3.0;
            label.Update();
        }

        private static Rectangle makePlate(ThermalDesktop td, Plate plateDef, Point3d center, string submodelName, string layerName, bool SameSideNumbering)
        {
            Units.SaveWorkingUnits();
            Units.WorkingUnits.modelLength = UnitsData.ModelLength.MM;

            Rectangle plate = td.CreateRectangle();
            plate.Layer = layerName;
            plate.CondSubmodel = submodelName;
            plate.TopStartSubmodel = submodelName;
            plate.XMax = plateDef.Xmm;
            plate.YMax = plateDef.Ymm;
            if (SameSideNumbering)
            {
                plate.SameSideNumbering = 1;
                plate.TopMaterial = plateDef.material;
                plate.TopThickness = plateDef.thickness_mm;
            }
            else
            {
                plate.SameSideNumbering = 0;
                plate.TopBotMaterial = plateDef.material;
                plate.TopBotSepDist = plateDef.thickness_mm;
                plate.TopThickness = 0;
                plate.BotThickness = 0;

            }
            plate.BreakdownU.Num = 1;
            plate.BreakdownV.Num = 1;
            plate.BaseTrans.SetOrigin(center + new Point3d(-plateDef.Xmm / 2, -plateDef.Ymm / 2, 0.0));
            plate.Update();

            Units.RestoreWorkingUnits();
            return plate;
        }

        public static void Serialize(TecSpec Tec, string fileName)
        {
            XmlDocument xmlDocument = new XmlDocument();
            XmlSerializer serializer = new XmlSerializer(Tec.GetType());
            using (MemoryStream stream = new MemoryStream())
            {
                serializer.Serialize(stream, Tec);
                stream.Position = 0;
                xmlDocument.Load(stream);
                xmlDocument.Save(fileName);
                stream.Close();
            }
        }

        public static TecSpec Deserialize(string fileName)
        {
            if (string.IsNullOrEmpty(fileName)) { return null; }

            TecSpec Tec = new TecSpec();
            XmlDocument xmlDocument = new XmlDocument();
            xmlDocument.Load(fileName);
            string xmlString = xmlDocument.OuterXml;
            using (StringReader read = new StringReader(xmlString))
            {
                XmlSerializer serializer = new XmlSerializer(Tec.GetType());
                using (XmlReader reader = new XmlTextReader(read))
                {
                    Tec = (TecSpec)serializer.Deserialize(reader);
                    reader.Close();
                }
                read.Close();
            }
            return Tec;
        }
    }

    [Serializable]
    public class TecSpec
    {
        public TecSpec()
        {
            Name = "TEC";
            BasePlate = new Plate();
            Stages = new List<Stage>();
            useEpoxy = false;
            SubmodelName = "TEC";
            LayerName = "TEC";
        }

        public string Name { get; set; }
        public Plate BasePlate { get; set; }
        public List<Stage> Stages { get; set; }
        public bool useEpoxy { get; set; }
        public string SubmodelName { get; set; }
        public string LayerName { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }

    [Serializable]
    public class Stage
    {
        public Stage()
        {
            TopPlate = new Plate();
            Couples = new Couples();
        }
        public Stage(Stage x)
        {
            TopPlate = new Plate(x.TopPlate);
            Couples = new Couples(x.Couples);
        }

        public Plate TopPlate { get; set; }
        public Couples Couples { get; set; }

        public void Clear()
        {
            TopPlate.Clear();
            Couples.Clear();
        }
    }

    [Serializable]
    public class Couples
    {
        public Couples()
        {
            N = 1;
            GeometryFactorCM = 1.0;
            Height_mm = 1.0;
        }
        public Couples(Couples x)
        {
            N = x.N;
            GeometryFactorCM = x.GeometryFactorCM;
            Height_mm = x.Height_mm;
        }

        public int N { get; set; }
        public double GeometryFactorCM { get; set; }
        public double Height_mm { get; set; }

        public void Clear()
        {
            N = 0;
            GeometryFactorCM = 0;
            Height_mm = 0;
        }

        public override string ToString()
        {
            return string.Format("Couples: N = {0}, GF = {1} cm, h = {2} mm",
                N, GeometryFactorCM, Height_mm);
        }
    }

    [Serializable]
    public class Plate
    {
        public Plate()
        {
            Xmm = 1.0;
            Ymm = 1.0;
            thickness_mm = 1.0;
            material = "Alumina10";
        }
        public Plate(Plate x)
        {
            Xmm = x.Xmm;
            Ymm = x.Ymm;
            thickness_mm = x.thickness_mm;
            material = x.material;
        }

        public double Xmm { get; set; }
        public double Ymm { get; set; }
        public double thickness_mm { get; set; }
        public string material { get; set; }

        public void Clear()
        {
            Xmm = 0;
            Ymm = 0;
            thickness_mm = 0;
            material = string.Empty;
        }

        public double Area_mm2
        {
            get { return Xmm * Ymm; }
        }

        public override string ToString()
        {
            return string.Format("Plate: {0} x {1} x {2} mm {3}", Xmm, Ymm, thickness_mm, material);
        }
    }
}
