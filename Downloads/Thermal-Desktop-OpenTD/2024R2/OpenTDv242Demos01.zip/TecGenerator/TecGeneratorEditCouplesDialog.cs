using System;
using System.Windows.Forms;

namespace OpenTDv242Demos
{
    public partial class TecGeneratorEditCouplesDialog : Form
    {
        public TecGeneratorEditCouplesDialog(Couples x)
        {
            InitializeComponent();
            tecCouples = x;
            UpdateForm();
        }

        private Couples tecCouples;

        private void UpdateForm()
        {
            N = tecCouples.N;
            GeometryFactorCM = tecCouples.GeometryFactorCM;
            Height_mm = tecCouples.Height_mm;
        }
        private void UpdateTec()
        {
            tecCouples.N = N;
            tecCouples.GeometryFactorCM = GeometryFactorCM;
            tecCouples.Height_mm = Height_mm;
        }

        private int N
        {
            get { return (int)N_NumericUpDown.Value; }
            set { N_NumericUpDown.Value = value; }
        }
        private double GeometryFactorCM
        {
            get { return (double)GeometryFactorNumericUpDown.Value; }
            set { GeometryFactorNumericUpDown.Value = (decimal)value; }
        }
        private double Height_mm
        {
            get { return (double)HeightNumericUpDown.Value; }
            set { HeightNumericUpDown.Value = (decimal)value; }
        }

        private void OkButton_Click(object sender, EventArgs e)
        {
            UpdateTec();
            Close();
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
