namespace OpenTDv242Demos
{
    partial class TecGeneratorDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TecGeneratorDialog));
            this.LoadButton = new System.Windows.Forms.Button();
            this.SaveAsButton = new System.Windows.Forms.Button();
            this.EpoxyFillCheckBox = new System.Windows.Forms.CheckBox();
            this.SubmodelTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.LayerTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.MakeButton = new System.Windows.Forms.Button();
            this.TecDetailsGroupBox = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.EditButton = new System.Windows.Forms.Button();
            this.LayupListBox = new System.Windows.Forms.ListBox();
            this.SaveButton = new System.Windows.Forms.Button();
            this.DeleteStageButton = new System.Windows.Forms.Button();
            this.AddStageButton = new System.Windows.Forms.Button();
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TecDetailsGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // LoadButton
            // 
            this.LoadButton.Location = new System.Drawing.Point(300, 537);
            this.LoadButton.Name = "LoadButton";
            this.LoadButton.Size = new System.Drawing.Size(83, 27);
            this.LoadButton.TabIndex = 1;
            this.LoadButton.Text = "Load";
            this.LoadButton.UseVisualStyleBackColor = true;
            this.LoadButton.Click += new System.EventHandler(this.LoadButton_Click);
            // 
            // SaveAsButton
            // 
            this.SaveAsButton.Location = new System.Drawing.Point(471, 537);
            this.SaveAsButton.Name = "SaveAsButton";
            this.SaveAsButton.Size = new System.Drawing.Size(82, 27);
            this.SaveAsButton.TabIndex = 4;
            this.SaveAsButton.Text = "Save As";
            this.SaveAsButton.UseVisualStyleBackColor = true;
            this.SaveAsButton.Click += new System.EventHandler(this.SaveAsButton_Click);
            // 
            // EpoxyFillCheckBox
            // 
            this.EpoxyFillCheckBox.AutoSize = true;
            this.EpoxyFillCheckBox.Location = new System.Drawing.Point(8, 401);
            this.EpoxyFillCheckBox.Name = "EpoxyFillCheckBox";
            this.EpoxyFillCheckBox.Size = new System.Drawing.Size(89, 21);
            this.EpoxyFillCheckBox.TabIndex = 8;
            this.EpoxyFillCheckBox.Text = "Epoxy Fill";
            this.EpoxyFillCheckBox.UseVisualStyleBackColor = true;
            // 
            // SubmodelTextBox
            // 
            this.SubmodelTextBox.Location = new System.Drawing.Point(87, 444);
            this.SubmodelTextBox.Name = "SubmodelTextBox";
            this.SubmodelTextBox.Size = new System.Drawing.Size(174, 22);
            this.SubmodelTextBox.TabIndex = 3;
            this.SubmodelTextBox.Text = "TEC";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 447);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Submodel:";
            // 
            // LayerTextBox
            // 
            this.LayerTextBox.Location = new System.Drawing.Point(87, 477);
            this.LayerTextBox.Name = "LayerTextBox";
            this.LayerTextBox.Size = new System.Drawing.Size(174, 22);
            this.LayerTextBox.TabIndex = 1;
            this.LayerTextBox.Text = "TEC";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 480);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Layer:";
            // 
            // MakeButton
            // 
            this.MakeButton.Location = new System.Drawing.Point(447, 609);
            this.MakeButton.Name = "MakeButton";
            this.MakeButton.Size = new System.Drawing.Size(124, 27);
            this.MakeButton.TabIndex = 5;
            this.MakeButton.Text = "Make TEC";
            this.MakeButton.UseVisualStyleBackColor = true;
            this.MakeButton.Click += new System.EventHandler(this.MakeButton_Click);
            // 
            // TecDetailsGroupBox
            // 
            this.TecDetailsGroupBox.Controls.Add(this.label4);
            this.TecDetailsGroupBox.Controls.Add(this.EditButton);
            this.TecDetailsGroupBox.Controls.Add(this.LayupListBox);
            this.TecDetailsGroupBox.Controls.Add(this.SaveButton);
            this.TecDetailsGroupBox.Controls.Add(this.DeleteStageButton);
            this.TecDetailsGroupBox.Controls.Add(this.AddStageButton);
            this.TecDetailsGroupBox.Controls.Add(this.EpoxyFillCheckBox);
            this.TecDetailsGroupBox.Controls.Add(this.NameTextBox);
            this.TecDetailsGroupBox.Controls.Add(this.label3);
            this.TecDetailsGroupBox.Controls.Add(this.SaveAsButton);
            this.TecDetailsGroupBox.Controls.Add(this.SubmodelTextBox);
            this.TecDetailsGroupBox.Controls.Add(this.label2);
            this.TecDetailsGroupBox.Controls.Add(this.LayerTextBox);
            this.TecDetailsGroupBox.Controls.Add(this.LoadButton);
            this.TecDetailsGroupBox.Controls.Add(this.label1);
            this.TecDetailsGroupBox.Location = new System.Drawing.Point(12, 12);
            this.TecDetailsGroupBox.Name = "TecDetailsGroupBox";
            this.TecDetailsGroupBox.Size = new System.Drawing.Size(559, 572);
            this.TecDetailsGroupBox.TabIndex = 6;
            this.TecDetailsGroupBox.TabStop = false;
            this.TecDetailsGroupBox.Text = "TEC Config";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 17);
            this.label4.TabIndex = 14;
            this.label4.Text = "Layup:";
            // 
            // EditButton
            // 
            this.EditButton.Location = new System.Drawing.Point(348, 363);
            this.EditButton.Name = "EditButton";
            this.EditButton.Size = new System.Drawing.Size(77, 27);
            this.EditButton.TabIndex = 13;
            this.EditButton.Text = "Edit";
            this.EditButton.UseVisualStyleBackColor = true;
            this.EditButton.Click += new System.EventHandler(this.EditButton_Click);
            // 
            // LayupListBox
            // 
            this.LayupListBox.FormattingEnabled = true;
            this.LayupListBox.ItemHeight = 16;
            this.LayupListBox.Location = new System.Drawing.Point(9, 81);
            this.LayupListBox.Name = "LayupListBox";
            this.LayupListBox.Size = new System.Drawing.Size(544, 276);
            this.LayupListBox.TabIndex = 12;
            this.LayupListBox.DoubleClick += new System.EventHandler(this.LayupListBox_DoubleClick);
            // 
            // SaveButton
            // 
            this.SaveButton.Location = new System.Drawing.Point(389, 537);
            this.SaveButton.Name = "SaveButton";
            this.SaveButton.Size = new System.Drawing.Size(76, 27);
            this.SaveButton.TabIndex = 11;
            this.SaveButton.Text = "Save";
            this.SaveButton.UseVisualStyleBackColor = true;
            this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
            // 
            // DeleteStageButton
            // 
            this.DeleteStageButton.Location = new System.Drawing.Point(431, 363);
            this.DeleteStageButton.Name = "DeleteStageButton";
            this.DeleteStageButton.Size = new System.Drawing.Size(122, 27);
            this.DeleteStageButton.TabIndex = 10;
            this.DeleteStageButton.Text = "Delete Stage";
            this.DeleteStageButton.UseVisualStyleBackColor = true;
            this.DeleteStageButton.Click += new System.EventHandler(this.DeleteStageButton_Click);
            // 
            // AddStageButton
            // 
            this.AddStageButton.Location = new System.Drawing.Point(224, 363);
            this.AddStageButton.Name = "AddStageButton";
            this.AddStageButton.Size = new System.Drawing.Size(118, 27);
            this.AddStageButton.TabIndex = 9;
            this.AddStageButton.Text = "Add Stage";
            this.AddStageButton.UseVisualStyleBackColor = true;
            this.AddStageButton.Click += new System.EventHandler(this.AddStageButton_Click);
            // 
            // NameTextBox
            // 
            this.NameTextBox.Location = new System.Drawing.Point(61, 27);
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(174, 22);
            this.NameTextBox.TabIndex = 6;
            this.NameTextBox.Text = "TBD";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 30);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Name:";
            // 
            // TecGeneratorDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(583, 646);
            this.Controls.Add(this.TecDetailsGroupBox);
            this.Controls.Add(this.MakeButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TecGeneratorDialog";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "TEC Generator";
            this.TecDetailsGroupBox.ResumeLayout(false);
            this.TecDetailsGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button LoadButton;
        private System.Windows.Forms.TextBox SubmodelTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox LayerTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button MakeButton;
        private System.Windows.Forms.GroupBox TecDetailsGroupBox;
        private System.Windows.Forms.CheckBox EpoxyFillCheckBox;
        private System.Windows.Forms.Button SaveAsButton;
        private System.Windows.Forms.Button SaveButton;
        private System.Windows.Forms.Button DeleteStageButton;
        private System.Windows.Forms.Button AddStageButton;
        private System.Windows.Forms.TextBox NameTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListBox LayupListBox;
        private System.Windows.Forms.Button EditButton;
        private System.Windows.Forms.Label label4;
    }
}