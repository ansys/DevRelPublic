namespace OpenTDv242Demos
{
    partial class TecGeneratorEditCouplesDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TecGeneratorEditCouplesDialog));
            this.label1 = new System.Windows.Forms.Label();
            this.N_NumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.GeometryFactorNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.HeightNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.CancelButton1 = new System.Windows.Forms.Button();
            this.OkButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.N_NumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GeometryFactorNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HeightNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(140, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(22, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "N:";
            // 
            // N_NumericUpDown
            // 
            this.N_NumericUpDown.Location = new System.Drawing.Point(168, 12);
            this.N_NumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.N_NumericUpDown.Name = "N_NumericUpDown";
            this.N_NumericUpDown.Size = new System.Drawing.Size(100, 22);
            this.N_NumericUpDown.TabIndex = 1;
            // 
            // GeometryFactorNumericUpDown
            // 
            this.GeometryFactorNumericUpDown.DecimalPlaces = 2;
            this.GeometryFactorNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.GeometryFactorNumericUpDown.Location = new System.Drawing.Point(168, 43);
            this.GeometryFactorNumericUpDown.Name = "GeometryFactorNumericUpDown";
            this.GeometryFactorNumericUpDown.Size = new System.Drawing.Size(100, 22);
            this.GeometryFactorNumericUpDown.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Geometry Factor (cm):";
            // 
            // HeightNumericUpDown
            // 
            this.HeightNumericUpDown.DecimalPlaces = 2;
            this.HeightNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            this.HeightNumericUpDown.Location = new System.Drawing.Point(168, 76);
            this.HeightNumericUpDown.Name = "HeightNumericUpDown";
            this.HeightNumericUpDown.Size = new System.Drawing.Size(100, 22);
            this.HeightNumericUpDown.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(73, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Height (mm):";
            // 
            // CancelButton1
            // 
            this.CancelButton1.Location = new System.Drawing.Point(193, 113);
            this.CancelButton1.Name = "CancelButton1";
            this.CancelButton1.Size = new System.Drawing.Size(75, 27);
            this.CancelButton1.TabIndex = 11;
            this.CancelButton1.Text = "Cancel";
            this.CancelButton1.UseVisualStyleBackColor = true;
            this.CancelButton1.Click += new System.EventHandler(this.CancelButton_Click);
            // 
            // OkButton
            // 
            this.OkButton.Location = new System.Drawing.Point(112, 113);
            this.OkButton.Name = "OkButton";
            this.OkButton.Size = new System.Drawing.Size(75, 27);
            this.OkButton.TabIndex = 10;
            this.OkButton.Text = "OK";
            this.OkButton.UseVisualStyleBackColor = true;
            this.OkButton.Click += new System.EventHandler(this.OkButton_Click);
            // 
            // TecGeneratorEditCouplesDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(276, 152);
            this.Controls.Add(this.CancelButton1);
            this.Controls.Add(this.OkButton);
            this.Controls.Add(this.HeightNumericUpDown);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.GeometryFactorNumericUpDown);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.N_NumericUpDown);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TecGeneratorEditCouplesDialog";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "Edit TEC Couples";
            ((System.ComponentModel.ISupportInitialize)(this.N_NumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GeometryFactorNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HeightNumericUpDown)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown N_NumericUpDown;
        private System.Windows.Forms.NumericUpDown GeometryFactorNumericUpDown;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown HeightNumericUpDown;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button CancelButton1;
        private System.Windows.Forms.Button OkButton;
    }
}