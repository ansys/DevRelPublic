using OpenTDv242;

namespace OpenTDv242Demos
{
    static internal class TecGeneratorThermoPropsMaker
    {
        static internal void MakeMaterials(ThermalDesktop td)
        {
            MakeEpoxy(td);
            MakeAlumina10(td);
        }

        static private void MakeEpoxy(ThermalDesktop td)
        {
            Units.SaveWorkingUnitsAndSetToSI();

            try { td.DeleteThermoProps("Epoxy"); } catch { }
            ThermoProps x = td.CreateThermoProps("Epoxy");
            x.Comment = "EPOXY, Reference:smd_5_bsin_5-98.inp 0.0 Value 10% of last";
            x.SpecificHeat = 1;
            x.Density = 1208.27;
            x.Conductivity = 1.63e-07;
            x.Update();

            Units.RestoreWorkingUnits();
        }


        static private void MakeAlumina10(ThermalDesktop td)
        {
            Units.SaveWorkingUnitsAndSetToSI();

            try { td.DeleteThermoProps("Alumina10"); } catch { }
            ThermoProps x = td.CreateThermoProps("Alumina10");
            x.Comment = @"alumina, https://assets.lairdtech.com/home/brandworld/files/THR-BRO-Thermal%20Handbook%200110.pdf";
            x.SpecificHeat = 837;
            x.Density = 3570;
            x.Conductivity = 35.3;
            x.Update();

            Units.RestoreWorkingUnits();
        }
    }
}    
