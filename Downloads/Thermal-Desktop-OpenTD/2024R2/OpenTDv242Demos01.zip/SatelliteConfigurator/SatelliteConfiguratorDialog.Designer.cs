namespace OpenTDv242Demos.SatelliteConfigurator
{
    partial class SatelliteConfiguratorDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SatelliteConfiguratorDialog));
            this.openDWG = new System.Windows.Forms.Button();
            this.hotCase = new System.Windows.Forms.RadioButton();
            this.coldCase = new System.Windows.Forms.RadioButton();
            this.dispersionBox = new System.Windows.Forms.GroupBox();
            this.configurationBox = new System.Windows.Forms.GroupBox();
            this.configB = new System.Windows.Forms.RadioButton();
            this.configA = new System.Windows.Forms.RadioButton();
            this.orbitControls = new System.Windows.Forms.GroupBox();
            this.minAltLabel = new System.Windows.Forms.Label();
            this.maxAltLabel = new System.Windows.Forms.Label();
            this.aopLabel = new System.Windows.Forms.Label();
            this.minAltTextBox = new System.Windows.Forms.TextBox();
            this.maxAltTextBox = new System.Windows.Forms.TextBox();
            this.aopTextBox = new System.Windows.Forms.TextBox();
            this.raanLabel = new System.Windows.Forms.Label();
            this.raanTextbox = new System.Windows.Forms.TextBox();
            this.incLabel = new System.Windows.Forms.Label();
            this.incTextBox = new System.Windows.Forms.TextBox();
            this.runCaseButton = new System.Windows.Forms.Button();
            this.resultsBox = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.purpleMinBox = new System.Windows.Forms.TextBox();
            this.purpleMaxBox = new System.Windows.Forms.TextBox();
            this.orangeMinBox = new System.Windows.Forms.TextBox();
            this.orangeMaxBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.greenMinBox = new System.Windows.Forms.TextBox();
            this.blueMinBox = new System.Windows.Forms.TextBox();
            this.redMinBox = new System.Windows.Forms.TextBox();
            this.greenMaxBox = new System.Windows.Forms.TextBox();
            this.blueMaxBox = new System.Windows.Forms.TextBox();
            this.redMaxBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.setConfigButton = new System.Windows.Forms.Button();
            this.dispersionBox.SuspendLayout();
            this.configurationBox.SuspendLayout();
            this.orbitControls.SuspendLayout();
            this.resultsBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // openDWG
            // 
            this.openDWG.Location = new System.Drawing.Point(8, 17);
            this.openDWG.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.openDWG.Name = "openDWG";
            this.openDWG.Size = new System.Drawing.Size(133, 27);
            this.openDWG.TabIndex = 0;
            this.openDWG.Text = "Open TD Model";
            this.openDWG.UseVisualStyleBackColor = true;
            this.openDWG.Click += new System.EventHandler(this.openDWG_Click);
            // 
            // hotCase
            // 
            this.hotCase.AutoSize = true;
            this.hotCase.Checked = true;
            this.hotCase.Location = new System.Drawing.Point(21, 21);
            this.hotCase.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.hotCase.Name = "hotCase";
            this.hotCase.Size = new System.Drawing.Size(42, 17);
            this.hotCase.TabIndex = 1;
            this.hotCase.TabStop = true;
            this.hotCase.Text = "Hot";
            this.hotCase.UseVisualStyleBackColor = true;
            // 
            // coldCase
            // 
            this.coldCase.AutoSize = true;
            this.coldCase.Location = new System.Drawing.Point(21, 40);
            this.coldCase.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.coldCase.Name = "coldCase";
            this.coldCase.Size = new System.Drawing.Size(46, 17);
            this.coldCase.TabIndex = 2;
            this.coldCase.Text = "Cold";
            this.coldCase.UseVisualStyleBackColor = true;
            // 
            // dispersionBox
            // 
            this.dispersionBox.Controls.Add(this.hotCase);
            this.dispersionBox.Controls.Add(this.coldCase);
            this.dispersionBox.Enabled = false;
            this.dispersionBox.Location = new System.Drawing.Point(8, 150);
            this.dispersionBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dispersionBox.Name = "dispersionBox";
            this.dispersionBox.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dispersionBox.Size = new System.Drawing.Size(133, 65);
            this.dispersionBox.TabIndex = 3;
            this.dispersionBox.TabStop = false;
            this.dispersionBox.Text = "Dispersions";
            // 
            // configurationBox
            // 
            this.configurationBox.Controls.Add(this.configB);
            this.configurationBox.Controls.Add(this.configA);
            this.configurationBox.Enabled = false;
            this.configurationBox.Location = new System.Drawing.Point(8, 238);
            this.configurationBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.configurationBox.Name = "configurationBox";
            this.configurationBox.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.configurationBox.Size = new System.Drawing.Size(133, 65);
            this.configurationBox.TabIndex = 4;
            this.configurationBox.TabStop = false;
            this.configurationBox.Text = "Geometry Configuration";
            // 
            // configB
            // 
            this.configB.AutoSize = true;
            this.configB.Location = new System.Drawing.Point(21, 37);
            this.configB.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.configB.Name = "configB";
            this.configB.Size = new System.Drawing.Size(97, 17);
            this.configB.TabIndex = 1;
            this.configB.Text = "Configuration B";
            this.configB.UseVisualStyleBackColor = true;
            // 
            // configA
            // 
            this.configA.AutoSize = true;
            this.configA.Checked = true;
            this.configA.Location = new System.Drawing.Point(21, 18);
            this.configA.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.configA.Name = "configA";
            this.configA.Size = new System.Drawing.Size(97, 17);
            this.configA.TabIndex = 0;
            this.configA.TabStop = true;
            this.configA.Text = "Configuration A";
            this.configA.UseVisualStyleBackColor = true;
            // 
            // orbitControls
            // 
            this.orbitControls.Controls.Add(this.minAltLabel);
            this.orbitControls.Controls.Add(this.maxAltLabel);
            this.orbitControls.Controls.Add(this.aopLabel);
            this.orbitControls.Controls.Add(this.minAltTextBox);
            this.orbitControls.Controls.Add(this.maxAltTextBox);
            this.orbitControls.Controls.Add(this.aopTextBox);
            this.orbitControls.Controls.Add(this.raanLabel);
            this.orbitControls.Controls.Add(this.raanTextbox);
            this.orbitControls.Controls.Add(this.incLabel);
            this.orbitControls.Controls.Add(this.incTextBox);
            this.orbitControls.Enabled = false;
            this.orbitControls.Location = new System.Drawing.Point(155, 8);
            this.orbitControls.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.orbitControls.Name = "orbitControls";
            this.orbitControls.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.orbitControls.Size = new System.Drawing.Size(207, 138);
            this.orbitControls.TabIndex = 5;
            this.orbitControls.TabStop = false;
            this.orbitControls.Text = "Orbit Controls";
            // 
            // minAltLabel
            // 
            this.minAltLabel.AutoSize = true;
            this.minAltLabel.Location = new System.Drawing.Point(7, 107);
            this.minAltLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.minAltLabel.Name = "minAltLabel";
            this.minAltLabel.Size = new System.Drawing.Size(86, 13);
            this.minAltLabel.TabIndex = 9;
            this.minAltLabel.Text = "Minimum Altitude";
            // 
            // maxAltLabel
            // 
            this.maxAltLabel.AutoSize = true;
            this.maxAltLabel.Location = new System.Drawing.Point(7, 86);
            this.maxAltLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.maxAltLabel.Name = "maxAltLabel";
            this.maxAltLabel.Size = new System.Drawing.Size(89, 13);
            this.maxAltLabel.TabIndex = 8;
            this.maxAltLabel.Text = "Maximum Altitude";
            // 
            // aopLabel
            // 
            this.aopLabel.AutoSize = true;
            this.aopLabel.Location = new System.Drawing.Point(7, 65);
            this.aopLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.aopLabel.Name = "aopLabel";
            this.aopLabel.Size = new System.Drawing.Size(80, 13);
            this.aopLabel.TabIndex = 7;
            this.aopLabel.Text = "Arg of Peripasis";
            // 
            // minAltTextBox
            // 
            this.minAltTextBox.Location = new System.Drawing.Point(124, 103);
            this.minAltTextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.minAltTextBox.Name = "minAltTextBox";
            this.minAltTextBox.Size = new System.Drawing.Size(68, 20);
            this.minAltTextBox.TabIndex = 6;
            this.minAltTextBox.Text = "500";
            this.minAltTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // maxAltTextBox
            // 
            this.maxAltTextBox.Location = new System.Drawing.Point(124, 82);
            this.maxAltTextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.maxAltTextBox.Name = "maxAltTextBox";
            this.maxAltTextBox.Size = new System.Drawing.Size(68, 20);
            this.maxAltTextBox.TabIndex = 5;
            this.maxAltTextBox.Text = "500";
            this.maxAltTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // aopTextBox
            // 
            this.aopTextBox.Location = new System.Drawing.Point(124, 61);
            this.aopTextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.aopTextBox.Name = "aopTextBox";
            this.aopTextBox.Size = new System.Drawing.Size(68, 20);
            this.aopTextBox.TabIndex = 4;
            this.aopTextBox.Text = "90";
            this.aopTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // raanLabel
            // 
            this.raanLabel.AutoSize = true;
            this.raanLabel.Location = new System.Drawing.Point(7, 44);
            this.raanLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.raanLabel.Name = "raanLabel";
            this.raanLabel.Size = new System.Drawing.Size(37, 13);
            this.raanLabel.TabIndex = 3;
            this.raanLabel.Text = "RAAN";
            // 
            // raanTextbox
            // 
            this.raanTextbox.Location = new System.Drawing.Point(124, 40);
            this.raanTextbox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.raanTextbox.Name = "raanTextbox";
            this.raanTextbox.Size = new System.Drawing.Size(68, 20);
            this.raanTextbox.TabIndex = 2;
            this.raanTextbox.Text = "270";
            this.raanTextbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // incLabel
            // 
            this.incLabel.AutoSize = true;
            this.incLabel.Location = new System.Drawing.Point(7, 23);
            this.incLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.incLabel.Name = "incLabel";
            this.incLabel.Size = new System.Drawing.Size(55, 13);
            this.incLabel.TabIndex = 1;
            this.incLabel.Text = "Inclination";
            // 
            // incTextBox
            // 
            this.incTextBox.Location = new System.Drawing.Point(124, 19);
            this.incTextBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.incTextBox.Name = "incTextBox";
            this.incTextBox.Size = new System.Drawing.Size(68, 20);
            this.incTextBox.TabIndex = 0;
            this.incTextBox.Text = "0";
            this.incTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // runCaseButton
            // 
            this.runCaseButton.Enabled = false;
            this.runCaseButton.Location = new System.Drawing.Point(8, 101);
            this.runCaseButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.runCaseButton.Name = "runCaseButton";
            this.runCaseButton.Size = new System.Drawing.Size(133, 27);
            this.runCaseButton.TabIndex = 6;
            this.runCaseButton.Text = "Run Case";
            this.runCaseButton.UseVisualStyleBackColor = true;
            this.runCaseButton.Click += new System.EventHandler(this.runCaseButton_Click);
            // 
            // resultsBox
            // 
            this.resultsBox.Controls.Add(this.label9);
            this.resultsBox.Controls.Add(this.label8);
            this.resultsBox.Controls.Add(this.purpleMinBox);
            this.resultsBox.Controls.Add(this.purpleMaxBox);
            this.resultsBox.Controls.Add(this.orangeMinBox);
            this.resultsBox.Controls.Add(this.orangeMaxBox);
            this.resultsBox.Controls.Add(this.label7);
            this.resultsBox.Controls.Add(this.label6);
            this.resultsBox.Controls.Add(this.label5);
            this.resultsBox.Controls.Add(this.label4);
            this.resultsBox.Controls.Add(this.greenMinBox);
            this.resultsBox.Controls.Add(this.blueMinBox);
            this.resultsBox.Controls.Add(this.redMinBox);
            this.resultsBox.Controls.Add(this.greenMaxBox);
            this.resultsBox.Controls.Add(this.blueMaxBox);
            this.resultsBox.Controls.Add(this.redMaxBox);
            this.resultsBox.Controls.Add(this.label3);
            this.resultsBox.Controls.Add(this.label2);
            this.resultsBox.Controls.Add(this.label1);
            this.resultsBox.Enabled = false;
            this.resultsBox.Location = new System.Drawing.Point(155, 150);
            this.resultsBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.resultsBox.Name = "resultsBox";
            this.resultsBox.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.resultsBox.Size = new System.Drawing.Size(207, 190);
            this.resultsBox.TabIndex = 9;
            this.resultsBox.TabStop = false;
            this.resultsBox.Text = "Results";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 23);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(54, 13);
            this.label9.TabIndex = 18;
            this.label9.Text = "Submodel";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(58, 171);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(141, 13);
            this.label8.TabIndex = 17;
            this.label8.Text = "Click temperature box to plot";
            // 
            // purpleMinBox
            // 
            this.purpleMinBox.Location = new System.Drawing.Point(143, 146);
            this.purpleMinBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.purpleMinBox.Name = "purpleMinBox";
            this.purpleMinBox.ReadOnly = true;
            this.purpleMinBox.Size = new System.Drawing.Size(58, 20);
            this.purpleMinBox.TabIndex = 16;
            this.purpleMinBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.purpleMinBox.Click += new System.EventHandler(this.purpleMinBox_Click);
            // 
            // purpleMaxBox
            // 
            this.purpleMaxBox.Location = new System.Drawing.Point(71, 146);
            this.purpleMaxBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.purpleMaxBox.Name = "purpleMaxBox";
            this.purpleMaxBox.ReadOnly = true;
            this.purpleMaxBox.Size = new System.Drawing.Size(58, 20);
            this.purpleMaxBox.TabIndex = 15;
            this.purpleMaxBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.purpleMaxBox.Click += new System.EventHandler(this.purpleMaxBox_Click);
            // 
            // orangeMinBox
            // 
            this.orangeMinBox.Location = new System.Drawing.Point(143, 120);
            this.orangeMinBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.orangeMinBox.Name = "orangeMinBox";
            this.orangeMinBox.ReadOnly = true;
            this.orangeMinBox.Size = new System.Drawing.Size(58, 20);
            this.orangeMinBox.TabIndex = 14;
            this.orangeMinBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.orangeMinBox.Click += new System.EventHandler(this.orangeMinBox_Click);
            // 
            // orangeMaxBox
            // 
            this.orangeMaxBox.Location = new System.Drawing.Point(71, 120);
            this.orangeMaxBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.orangeMaxBox.Name = "orangeMaxBox";
            this.orangeMaxBox.ReadOnly = true;
            this.orangeMaxBox.Size = new System.Drawing.Size(58, 20);
            this.orangeMaxBox.TabIndex = 13;
            this.orangeMaxBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.orangeMaxBox.Click += new System.EventHandler(this.orangeMaxBox_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 146);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Purple";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(23, 120);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Orange";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(159, 23);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Min T";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(87, 23);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Max T";
            // 
            // greenMinBox
            // 
            this.greenMinBox.Location = new System.Drawing.Point(143, 94);
            this.greenMinBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.greenMinBox.Name = "greenMinBox";
            this.greenMinBox.ReadOnly = true;
            this.greenMinBox.Size = new System.Drawing.Size(58, 20);
            this.greenMinBox.TabIndex = 8;
            this.greenMinBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.greenMinBox.Click += new System.EventHandler(this.greenMinBox_Click);
            // 
            // blueMinBox
            // 
            this.blueMinBox.Location = new System.Drawing.Point(143, 68);
            this.blueMinBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.blueMinBox.Name = "blueMinBox";
            this.blueMinBox.ReadOnly = true;
            this.blueMinBox.Size = new System.Drawing.Size(58, 20);
            this.blueMinBox.TabIndex = 7;
            this.blueMinBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.blueMinBox.Click += new System.EventHandler(this.blueMinBox_Click);
            // 
            // redMinBox
            // 
            this.redMinBox.Location = new System.Drawing.Point(143, 42);
            this.redMinBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.redMinBox.Name = "redMinBox";
            this.redMinBox.ReadOnly = true;
            this.redMinBox.Size = new System.Drawing.Size(58, 20);
            this.redMinBox.TabIndex = 6;
            this.redMinBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.redMinBox.Click += new System.EventHandler(this.redMinBox_Click);
            // 
            // greenMaxBox
            // 
            this.greenMaxBox.Location = new System.Drawing.Point(71, 94);
            this.greenMaxBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.greenMaxBox.Name = "greenMaxBox";
            this.greenMaxBox.ReadOnly = true;
            this.greenMaxBox.Size = new System.Drawing.Size(58, 20);
            this.greenMaxBox.TabIndex = 5;
            this.greenMaxBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.greenMaxBox.Click += new System.EventHandler(this.greenMaxBox_Click);
            // 
            // blueMaxBox
            // 
            this.blueMaxBox.Location = new System.Drawing.Point(71, 68);
            this.blueMaxBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.blueMaxBox.Name = "blueMaxBox";
            this.blueMaxBox.ReadOnly = true;
            this.blueMaxBox.Size = new System.Drawing.Size(58, 20);
            this.blueMaxBox.TabIndex = 4;
            this.blueMaxBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.blueMaxBox.Click += new System.EventHandler(this.blueMaxBox_Click);
            // 
            // redMaxBox
            // 
            this.redMaxBox.Location = new System.Drawing.Point(71, 42);
            this.redMaxBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.redMaxBox.Name = "redMaxBox";
            this.redMaxBox.ReadOnly = true;
            this.redMaxBox.Size = new System.Drawing.Size(58, 20);
            this.redMaxBox.TabIndex = 3;
            this.redMaxBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.redMaxBox.Click += new System.EventHandler(this.redMaxBox_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(23, 94);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Green";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 68);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label2.Size = new System.Drawing.Size(28, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Blue";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 42);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(27, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Red";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // setConfigButton
            // 
            this.setConfigButton.Enabled = false;
            this.setConfigButton.Location = new System.Drawing.Point(8, 59);
            this.setConfigButton.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.setConfigButton.Name = "setConfigButton";
            this.setConfigButton.Size = new System.Drawing.Size(133, 27);
            this.setConfigButton.TabIndex = 10;
            this.setConfigButton.Text = "Set Model to Config";
            this.setConfigButton.UseVisualStyleBackColor = true;
            this.setConfigButton.Click += new System.EventHandler(this.setConfigButton_Click);
            // 
            // SatelliteConfiguratorDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(375, 356);
            this.Controls.Add(this.setConfigButton);
            this.Controls.Add(this.resultsBox);
            this.Controls.Add(this.runCaseButton);
            this.Controls.Add(this.orbitControls);
            this.Controls.Add(this.configurationBox);
            this.Controls.Add(this.dispersionBox);
            this.Controls.Add(this.openDWG);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "SatelliteConfiguratorDialog";
            this.Text = "Satellite Configurator";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.SatelliteConfiguratorDialog_FormClosing);
            this.dispersionBox.ResumeLayout(false);
            this.dispersionBox.PerformLayout();
            this.configurationBox.ResumeLayout(false);
            this.configurationBox.PerformLayout();
            this.orbitControls.ResumeLayout(false);
            this.orbitControls.PerformLayout();
            this.resultsBox.ResumeLayout(false);
            this.resultsBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button openDWG;
        private System.Windows.Forms.RadioButton hotCase;
        private System.Windows.Forms.RadioButton coldCase;
        private System.Windows.Forms.GroupBox dispersionBox;
        private System.Windows.Forms.GroupBox configurationBox;
        private System.Windows.Forms.RadioButton configB;
        private System.Windows.Forms.RadioButton configA;
        private System.Windows.Forms.GroupBox orbitControls;
        private System.Windows.Forms.Label minAltLabel;
        private System.Windows.Forms.Label maxAltLabel;
        private System.Windows.Forms.Label aopLabel;
        private System.Windows.Forms.TextBox minAltTextBox;
        private System.Windows.Forms.TextBox maxAltTextBox;
        private System.Windows.Forms.TextBox aopTextBox;
        private System.Windows.Forms.Label raanLabel;
        private System.Windows.Forms.TextBox raanTextbox;
        private System.Windows.Forms.Label incLabel;
        private System.Windows.Forms.TextBox incTextBox;
        private System.Windows.Forms.Button runCaseButton;
        private System.Windows.Forms.GroupBox resultsBox;
        private System.Windows.Forms.TextBox greenMinBox;
        private System.Windows.Forms.TextBox blueMinBox;
        private System.Windows.Forms.TextBox redMinBox;
        private System.Windows.Forms.TextBox greenMaxBox;
        private System.Windows.Forms.TextBox blueMaxBox;
        private System.Windows.Forms.TextBox redMaxBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox purpleMinBox;
        private System.Windows.Forms.TextBox purpleMaxBox;
        private System.Windows.Forms.TextBox orangeMinBox;
        private System.Windows.Forms.TextBox orangeMaxBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button setConfigButton;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
    }
}