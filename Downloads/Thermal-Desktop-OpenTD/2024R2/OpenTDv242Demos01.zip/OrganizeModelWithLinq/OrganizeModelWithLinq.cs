using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using OpenTDv242;
using OpenTDv242.RadCAD;
using OpenTDv242.UserInterface;

namespace OpenTDv242Demos
{
    public class OrganizeModelWithLinq : Script
    {
        public override string GetName()
        {
            return "Organize Model with LINQ";
        }

        public override string GetDescription()
        {
            return "Use LINQ to query an existing model and organize it";
        }
        public override string GetKeywords()
        {
            return "query modify search model circuit board electronics avionics heatloads symbols chips motherboard";
        }

        public override void Run()
        {
            // In this demo, we've been given an existing model of an aluminum electronics box with
            // multiple circuit boards with multiple chips on each. For demonstration purposes,
            // there is only one type of chip, with the following dimensions:
            //   1.2" L x 0.4" W x 0.2" H
            // All boards, chips, and the box are modeled as TD FD rectangles. Unfortunately, they have
            // all been placed on the "0" layer and in the MAIN submodel. Instead of using the
            // GUI to painstakingly re-organize the model, we're going to use OpenTD and a powerful
            // .NET feature called LINQ. Together, they allow database-like queries on TD models.

            #region Setup and Start TD

            Console.WriteLine("Starting ModifyModel demo...");

            Console.WriteLine("Starting TD and opening dwg...");
            ThermalDesktop td = new ThermalDesktop(); // one instance of TD
            td.ConnectConfig.DwgPathname = System.IO.Path.Combine(WorkingDirectory, @"organizeModelWithLinq.dwg");
            td.Connect(); // connect to the new instance of TD, or to an existing one if DwgPathname is already open

            // set API WorkingUnits.modelLength to inches to work with all lengths in inches
            Units.WorkingUnits.SetToEng();
            Units.WorkingUnits.modelLength = UnitsData.ModelLength.INCH;

            // for demonstration purposes only, at runtime let's pause here to examine the model as supplied to us
            // note that there are dozens of rectangles, all on layer 0 and in submodel MAIN
            Console.WriteLine("Pausing for user input...");
            MessageBox.Show("Please examine the model and press OK when you are ready to organize it using OpenTD and LINQ.",
                GetName(),
                MessageBoxButtons.OK, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1,
                MessageBoxOptions.DefaultDesktopOnly); // DefaultDesktopOnly brings MessageBox to front
            Console.WriteLine("Organizing model...");

            #endregion

            #region Query Model to Find Components

            // get all rectangles
            List<Rectangle> allRectangles = td.GetRectangles();
            Console.WriteLine(string.Format("Found {0} Rectangle(s).", allRectangles.Count()));

            // find chips with specified dimensions, using LINQ and a helper method
            // called rectHasDimensions (defined below)
            var chips = allRectangles.Where(x => rectHasDimensions(x, 1.2, 0.4, 0.2));
            Console.WriteLine(string.Format("Found {0} chip(s).", chips.Count() ));

            // find boards, assuming all rectangles that aren't chips and have TopMaterial
            // "silicon" are boards (using LINQ)
            // (casting boards to a List, so we can use Remove and Sort methods later)
            List<Rectangle> boards = allRectangles.Where(x => x.TopMaterial == "silicon").Except(chips).ToList();
            Console.WriteLine(string.Format("Found {0} board(s).", boards.Count() ));

            // remove motherboard from boards (using LINQ), based on the fact that we know its handle is "246"
            Rectangle motherboard = boards.Single(x => x.Handle == "246");
            boards.Remove(motherboard);
            
            // find box, assuming all rectangles that have TopMaterial "aluminum" are part of the box (using LINQ)
            var boxRects = allRectangles.Where(x => x.TopMaterial == "aluminum");
            Console.WriteLine(string.Format("Found {0} rectangle(s) comprising the box.", boxRects.Count()));

            #endregion

            #region Update Layers and Submodels

            // give chips their own layers and submodels
            string chipName = "Chip";
            Console.WriteLine("Creating layer and submodel " + chipName);
            Layer chipLayer = td.CreateLayer(chipName);
            chipLayer.ColorIndex = 72;
            chipLayer.Update(); // actually sends the updated data to TD
            foreach (Rectangle rect in chips)
            {
                rect.Layer = chipName;
                rect.TopStartSubmodel = chipName;
                rect.Update(); // actually sends the updated data to TD
                td.UpdateGraphics();
            }

            // number the boards from 1 to n, ordered based on Y position
            SortRectanglesByYPos(boards); // see helper method below
            string boardBaseName = "Board_";
            for (int i = 0; i < boards.Count; ++i)
            {
                string name = boardBaseName + (i + 1).ToString();
                Console.WriteLine("Creating layer and submodel " + boardBaseName);
                Layer layer = td.CreateLayer(name);
                layer.ColorIndex = getNextBoardColor(); // see helper method below
                layer.Update();
                boards[i].Layer = name;
                boards[i].TopStartSubmodel = name;
                boards[i].Update(); // actually sends the updated data to TD
                td.UpdateGraphics();
            }

            // give motherboard its own layer and submodel
            string motherboardName = "Motherboard";
            Console.WriteLine("Creating layer and submodel " + motherboardName);
            Layer motherboardLayer = td.CreateLayer(motherboardName);
            motherboardLayer.ColorIndex = 24;
            motherboardLayer.Update(); // actually sends the updated data to TD
            motherboard.Layer = motherboardName;
            motherboard.TopStartSubmodel = motherboardName;
            motherboard.Update(); // actually sends the updated data to TD
            td.UpdateGraphics();

            // give box rectangles their own layers and submodels
            string boxName = "Box";
            Console.WriteLine("Creating layer and submodel " + boxName);
            Layer boxLayer = td.CreateLayer(boxName);
            boxLayer.ColorIndex = 8;
            boxLayer.Update(); // actually sends the updated data to TD
            foreach (Rectangle rect in boxRects)
            {
                rect.Layer = boxName;
                rect.TopStartSubmodel = boxName;
                rect.Update(); // actually sends the updated data to TD
                td.UpdateGraphics();
            }

            #endregion

            #region Create Parametric Heatloads on Chips

            // create symbol for chip heatloads
            Console.WriteLine("Creating symbol for chip heatloads...");
            Symbol heatloadSym = td.CreateSymbol("heatload", "0.1");
            heatloadSym.Description = "heatload applied to each chip, Watts";
            heatloadSym.Update(); // actually sends the updated data to TD

            // create heatloads for chips
            Console.WriteLine("Creating heatloads for chips...");
            foreach (Rectangle rect in chips)
            {
                HeatLoad heatload = td.CreateHeatLoad(new List<Connection> { rect.Handle });
                heatload.Layer = chipName;
                heatload.Submodel = chipName;
                heatload.ValueExp.units.energy = UnitsData.Energy.J;
                heatload.ValueExp.units.time = UnitsData.Time.SEC;
                heatload.ValueExp.Value = "heatload";
                heatload.AppliedType = HeatLoad.AppliedTypeBoundaryConds.SURFACE;
                heatload.Update(); // actually sends the updated data to TD
                td.UpdateGraphics();
            }

            #endregion

            Console.WriteLine("Done.");
        }


        #region Helper Methods

        private int nextBoardColorIndex = 0;
        private List<int> BoardColors = new List<int> { 40, 152, 230, 202, 130 };
        private int getNextBoardColor()
        {
            if (nextBoardColorIndex >= BoardColors.Count)
                nextBoardColorIndex = 0;
            return BoardColors[nextBoardColorIndex++];
        }

        private bool rectHasDimensions(Rectangle rect, double L, double W, double H)
        {
            // If TopThickness doesn't equal H, return false.
            // If TopThickness equals H, then check if
            // XMax and YMax equal L and W, in either order
            // and return true if they do.

            if (!equalWithinTolerance(rect.TopThickness, H))
                return false;
            else if (equalWithinTolerance(rect.XMax, L) &&
                     equalWithinTolerance(rect.YMax, W))
                return true;
            else if (equalWithinTolerance(rect.XMax, W) &&
                     equalWithinTolerance(rect.YMax, L))
                return true;
            else
                return false;
        }

        private bool equalWithinTolerance(double d1, double d2, double tol = 0.001)
        {
            // we can't compare doubles with "d1 == d2" because they're rarely exactly equal
            // so we compare them to within a tolerance
            return System.Math.Abs(d1 - d2) < tol;
        }

        private void SortRectanglesByYPos(List<Rectangle> rectangles)
        {
            if (rectangles == null) return;
            rectangles.Sort(CompareRectsByYPos); // Sort method takes a comparison function,
                                                 // defined below, to define how to order
                                                 // items in the list
        }

        private static int CompareRectsByYPos(Rectangle rect1, Rectangle rect2)
        // implements Comparison<T> generic delegate for Comparison<Rectangle>, see MSDN
        // returns:
        //          1 if rect1 Y pos > rect2 Y pos
        //          0 if rect1 Y pos = rect2 Y pos
        //         -1 if rect1 Y pos < rect2 Y pos
        //    (null rect is considered less than any Y pos)
        {
            if (rect1 == null)
            {
                if (rect2 == null)
                    return 0;
                else
                    return -1;
            }
            else
            {
                if (rect2 == null)
                    return 1;
                else
                {
                    double rect1YPos = rect1.BaseTrans.GetOrigin().Y;
                    double rect2YPos = rect2.BaseTrans.GetOrigin().Y;
                    if (rect1YPos > rect2YPos)
                        return 1;
                    else if (rect1YPos < rect2YPos)
                        return -1;
                    else
                        return 0;
                }
            }
        }

        #endregion

    }
}
