using System;

namespace OpenTDDemos.Snake
{
    class PelletsEatenEventArgs : EventArgs
    {
        public PelletsEatenEventArgs(int pelletsEaten)
        {
            PelletsEaten = pelletsEaten;
        }

        public int PelletsEaten { get; set; }
    }
}
