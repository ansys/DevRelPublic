using OpenTD;
using OpenTD.RadCAD.FdSolid;

namespace OpenTDDemos.Marquee
{
    class SolidUpperL : SolidCharacter
    {
        public SolidUpperL(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height)
        {
            DrawUpright();
            DrawLow();
        }

        SolidBrick Upright;
        SolidBrick Low;

        void DrawUpright()
        {
            Upright = TD.CreateSolidBrick();
            Upright.ColorIndex = ColorIndex;
            Upright.XMax = Thickness;
            Upright.ZMax = Thickness;
            Upright.YMax = Height;
            Upright.BaseTrans = new Matrix3d(CS);

            Upright.Update();
        }

        void DrawLow()
        {
            Low = TD.CreateSolidBrick();
            Low.ColorIndex = ColorIndex;
            Low.XMax = 0.4 * Height;
            Low.ZMax = Thickness;
            Low.YMax = Thickness;
            Low.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(Thickness, 0, 0));
            Low.BaseTrans.PostMultBy(trans);

            Low.Update();
        }

        public override double Width => Thickness + 0.4 * Height;

        public override void Delete()
        {
            TD.DeleteEntity(Upright);
            TD.DeleteEntity(Low);
        }
    }
}
