using OpenTD;
using OpenTD.RadCAD.FdSolid;

namespace OpenTDDemos.Marquee
{
    class SolidUpperC : SolidCharacter
    {
        public SolidUpperC(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height)
        {
            DrawCyl();
        }

        SolidCylinder Cyl;

        void DrawCyl()
        {
            Cyl = TD.CreateSolidCylinder();
            Cyl.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(Height / 2, Height / 2, 0));
            Cyl.BaseTrans.PostMultBy(trans);
            Cyl.Height = Thickness;
            Cyl.Rmax = Height / 2;
            Cyl.Rmin = Cyl.Rmax - Thickness;
            Cyl.StartAngle = 60;
            Cyl.EndAngle = 300;
            Cyl.ColorIndex = ColorIndex;
            Cyl.Update();
        }

        public override double Width => 0.75 * Height;

        public override void Delete()
        {
            TD.DeleteEntity(Cyl);
        }
    }
}
