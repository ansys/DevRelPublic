using OpenTD;
using OpenTD.RadCAD.FdSolid;

namespace OpenTDDemos.Marquee
{
    class SolidUpperD : SolidCharacter
    {
        public SolidUpperD(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height)
        {
            DrawUpright();
            DrawCyl();
        }

        SolidBrick Upright;
        SolidCylinder Cyl;

        void DrawUpright()
        {
            Upright = TD.CreateSolidBrick();
            Upright.ColorIndex = ColorIndex;
            Upright.XMax = Thickness;
            Upright.ZMax = Thickness;
            Upright.YMax = Height;
            Upright.BaseTrans = new Matrix3d(CS);

            Upright.Update();
        }

        void DrawCyl()
        {
            Cyl = TD.CreateSolidCylinder();
            Cyl.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(Thickness, 0.5 * Height, 0));
            Cyl.BaseTrans.PostMultBy(trans);
            Cyl.Height = Thickness;
            Cyl.Rmax = 0.5 * Height;
            Cyl.Rmin = Cyl.Rmax - Thickness;
            Cyl.StartAngle = 270;
            Cyl.EndAngle = 90;
            Cyl.ColorIndex = ColorIndex;
            Cyl.Update();
        }

        public override double Width => Thickness + 0.5 * Height;

        public override void Delete()
        {
            TD.DeleteEntity(Upright);
            TD.DeleteEntity(Cyl);
        }
    }
}
