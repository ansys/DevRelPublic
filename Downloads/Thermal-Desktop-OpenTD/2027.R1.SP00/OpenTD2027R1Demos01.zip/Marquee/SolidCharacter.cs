using OpenTD;

namespace OpenTDDemos.Marquee
{
    abstract class SolidCharacter : Character
    {
        public SolidCharacter(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height) { }

        public double Thickness => Height / 5;
    }
}
