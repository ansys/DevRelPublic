namespace OpenTDDemos.Robot
{
    partial class RobotDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RobotDialog));
            this.RightShoulderPitchTrackBar = new System.Windows.Forms.TrackBar();
            this.RightShoulderYawTrackBar = new System.Windows.Forms.TrackBar();
            this.RightElbowPitchTrackBar = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.LeftShoulderPitchTrackBar = new System.Windows.Forms.TrackBar();
            this.label6 = new System.Windows.Forms.Label();
            this.LeftShoulderYawTrackBar = new System.Windows.Forms.TrackBar();
            this.LeftElbowPitchTrackBar = new System.Windows.Forms.TrackBar();
            this.label7 = new System.Windows.Forms.Label();
            this.NeckYawTrackBar = new System.Windows.Forms.TrackBar();
            this.label8 = new System.Windows.Forms.Label();
            this.WaistPitchTrackBar = new System.Windows.Forms.TrackBar();
            this.WaistYawTrackBar = new System.Windows.Forms.TrackBar();
            this.label9 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.RightShoulderPitchTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RightShoulderYawTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.RightElbowPitchTrackBar)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LeftShoulderPitchTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftShoulderYawTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftElbowPitchTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NeckYawTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WaistPitchTrackBar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.WaistYawTrackBar)).BeginInit();
            this.SuspendLayout();
            // 
            // RightShoulderPitchTrackBar
            // 
            this.RightShoulderPitchTrackBar.Location = new System.Drawing.Point(47, 135);
            this.RightShoulderPitchTrackBar.Maximum = 90;
            this.RightShoulderPitchTrackBar.Minimum = -90;
            this.RightShoulderPitchTrackBar.Name = "RightShoulderPitchTrackBar";
            this.RightShoulderPitchTrackBar.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.RightShoulderPitchTrackBar.Size = new System.Drawing.Size(56, 184);
            this.RightShoulderPitchTrackBar.TabIndex = 0;
            this.RightShoulderPitchTrackBar.Scroll += new System.EventHandler(this.RightShoulderPitchTrackBar_Scroll);
            // 
            // RightShoulderYawTrackBar
            // 
            this.RightShoulderYawTrackBar.Location = new System.Drawing.Point(14, 55);
            this.RightShoulderYawTrackBar.Maximum = 90;
            this.RightShoulderYawTrackBar.Minimum = -90;
            this.RightShoulderYawTrackBar.Name = "RightShoulderYawTrackBar";
            this.RightShoulderYawTrackBar.Size = new System.Drawing.Size(104, 56);
            this.RightShoulderYawTrackBar.TabIndex = 1;
            this.RightShoulderYawTrackBar.Scroll += new System.EventHandler(this.RightShoulderYawTrackBar_Scroll);
            // 
            // RightElbowPitchTrackBar
            // 
            this.RightElbowPitchTrackBar.Location = new System.Drawing.Point(47, 354);
            this.RightElbowPitchTrackBar.Maximum = 150;
            this.RightElbowPitchTrackBar.Name = "RightElbowPitchTrackBar";
            this.RightElbowPitchTrackBar.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.RightElbowPitchTrackBar.Size = new System.Drawing.Size(56, 128);
            this.RightElbowPitchTrackBar.TabIndex = 2;
            this.RightElbowPitchTrackBar.Scroll += new System.EventHandler(this.RightElbowPitchTrackBar_Scroll);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Shoulder Yaw";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Shoulder Pitch";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 336);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 17);
            this.label3.TabIndex = 5;
            this.label3.Text = "Elbow Pitch";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.RightShoulderPitchTrackBar);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.RightShoulderYawTrackBar);
            this.groupBox1.Controls.Add(this.RightElbowPitchTrackBar);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(127, 493);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Right Arm";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.LeftShoulderPitchTrackBar);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.LeftShoulderYawTrackBar);
            this.groupBox2.Controls.Add(this.LeftElbowPitchTrackBar);
            this.groupBox2.Location = new System.Drawing.Point(323, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(127, 493);
            this.groupBox2.TabIndex = 7;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Left Arm";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 35);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Shoulder Yaw";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 336);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Elbow Pitch";
            // 
            // LeftShoulderPitchTrackBar
            // 
            this.LeftShoulderPitchTrackBar.Location = new System.Drawing.Point(47, 135);
            this.LeftShoulderPitchTrackBar.Maximum = 90;
            this.LeftShoulderPitchTrackBar.Minimum = -90;
            this.LeftShoulderPitchTrackBar.Name = "LeftShoulderPitchTrackBar";
            this.LeftShoulderPitchTrackBar.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.LeftShoulderPitchTrackBar.Size = new System.Drawing.Size(56, 184);
            this.LeftShoulderPitchTrackBar.TabIndex = 0;
            this.LeftShoulderPitchTrackBar.Scroll += new System.EventHandler(this.LeftShoulderPitchTrackBar_Scroll);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 115);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(100, 17);
            this.label6.TabIndex = 4;
            this.label6.Text = "Shoulder Pitch";
            // 
            // LeftShoulderYawTrackBar
            // 
            this.LeftShoulderYawTrackBar.Location = new System.Drawing.Point(14, 55);
            this.LeftShoulderYawTrackBar.Maximum = 90;
            this.LeftShoulderYawTrackBar.Minimum = -90;
            this.LeftShoulderYawTrackBar.Name = "LeftShoulderYawTrackBar";
            this.LeftShoulderYawTrackBar.Size = new System.Drawing.Size(104, 56);
            this.LeftShoulderYawTrackBar.TabIndex = 1;
            this.LeftShoulderYawTrackBar.Scroll += new System.EventHandler(this.LeftShoulderYawTrackBar_Scroll);
            // 
            // LeftElbowPitchTrackBar
            // 
            this.LeftElbowPitchTrackBar.Location = new System.Drawing.Point(47, 354);
            this.LeftElbowPitchTrackBar.Maximum = 150;
            this.LeftElbowPitchTrackBar.Name = "LeftElbowPitchTrackBar";
            this.LeftElbowPitchTrackBar.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.LeftElbowPitchTrackBar.Size = new System.Drawing.Size(56, 128);
            this.LeftElbowPitchTrackBar.TabIndex = 2;
            this.LeftElbowPitchTrackBar.Scroll += new System.EventHandler(this.LeftElbowPitchTrackBar_Scroll);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(192, 12);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 17);
            this.label7.TabIndex = 7;
            this.label7.Text = "Neck Yaw";
            // 
            // NeckYawTrackBar
            // 
            this.NeckYawTrackBar.Location = new System.Drawing.Point(175, 32);
            this.NeckYawTrackBar.Maximum = 90;
            this.NeckYawTrackBar.Minimum = -90;
            this.NeckYawTrackBar.Name = "NeckYawTrackBar";
            this.NeckYawTrackBar.Size = new System.Drawing.Size(104, 56);
            this.NeckYawTrackBar.TabIndex = 6;
            this.NeckYawTrackBar.Scroll += new System.EventHandler(this.NeckYawTrackBar_Scroll);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(192, 141);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 17);
            this.label8.TabIndex = 10;
            this.label8.Text = "Waist Yaw";
            // 
            // WaistPitchTrackBar
            // 
            this.WaistPitchTrackBar.Location = new System.Drawing.Point(209, 241);
            this.WaistPitchTrackBar.Maximum = 30;
            this.WaistPitchTrackBar.Minimum = -90;
            this.WaistPitchTrackBar.Name = "WaistPitchTrackBar";
            this.WaistPitchTrackBar.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.WaistPitchTrackBar.Size = new System.Drawing.Size(56, 184);
            this.WaistPitchTrackBar.TabIndex = 8;
            this.WaistPitchTrackBar.Scroll += new System.EventHandler(this.WaistPitchTrackBar_Scroll);
            // 
            // WaistYawTrackBar
            // 
            this.WaistYawTrackBar.Location = new System.Drawing.Point(176, 161);
            this.WaistYawTrackBar.Maximum = 90;
            this.WaistYawTrackBar.Minimum = -90;
            this.WaistYawTrackBar.Name = "WaistYawTrackBar";
            this.WaistYawTrackBar.Size = new System.Drawing.Size(104, 56);
            this.WaistYawTrackBar.TabIndex = 9;
            this.WaistYawTrackBar.Scroll += new System.EventHandler(this.WaistYawTrackBar_Scroll);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(192, 221);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(78, 17);
            this.label9.TabIndex = 6;
            this.label9.Text = "Waist Pitch";
            // 
            // RobotDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(462, 517);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.WaistPitchTrackBar);
            this.Controls.Add(this.WaistYawTrackBar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.NeckYawTrackBar);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "RobotDialog";
            this.Text = "Robot Demo";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.RobotDialog_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.RightShoulderPitchTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RightShoulderYawTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.RightElbowPitchTrackBar)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LeftShoulderPitchTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftShoulderYawTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LeftElbowPitchTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NeckYawTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WaistPitchTrackBar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.WaistYawTrackBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar RightShoulderPitchTrackBar;
        private System.Windows.Forms.TrackBar RightShoulderYawTrackBar;
        private System.Windows.Forms.TrackBar RightElbowPitchTrackBar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TrackBar LeftShoulderPitchTrackBar;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TrackBar LeftShoulderYawTrackBar;
        private System.Windows.Forms.TrackBar LeftElbowPitchTrackBar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TrackBar NeckYawTrackBar;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TrackBar WaistPitchTrackBar;
        private System.Windows.Forms.TrackBar WaistYawTrackBar;
        private System.Windows.Forms.Label label9;
    }
}