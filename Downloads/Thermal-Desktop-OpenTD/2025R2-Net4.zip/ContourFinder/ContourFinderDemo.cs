// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using OpenTD;

namespace OpenTDDemos.ContourFinder
{
    public class ContourFinderDemo : Script
    {
        public override string GetName()
        {
            return "Contour Finder";
        }
        public override string GetDescription()
        {
            return "Finds and returns maximum or minimum color contours by submodel for a transient";
        }
        public override string GetKeywords()
        {
            return "postprocessing post-processing contour results save csr datasets maximum minimum";
        }
        public override void Run()
        {
            ContourFinderDialog d = new ContourFinderDialog();
            d.ShowDialog();
        }
    }
}