// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using OpenTD;
using OpenTD.RadCAD.FdSolid;

namespace OpenTDDemos.Marquee
{
    class SolidUpperO : SolidCharacter
    {
        public SolidUpperO(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height)
        {
            DrawCyl();
        }

        SolidCylinder Cyl;

        void DrawCyl()
        {
            Cyl = TD.CreateSolidCylinder();
            Cyl.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(Height / 2, Height / 2, 0));
            Cyl.BaseTrans.PostMultBy(trans);
            Cyl.Height = Thickness;
            Cyl.Rmax = Height / 2;
            Cyl.Rmin = Cyl.Rmax - Thickness;
            Cyl.StartAngle = 0;
            Cyl.EndAngle = 360;
            Cyl.ColorIndex = ColorIndex;
            Cyl.Update();
        }

        public override double Width => Height;

        public override void Delete()
        {
            TD.DeleteEntity(Cyl);
        }
    }
}
