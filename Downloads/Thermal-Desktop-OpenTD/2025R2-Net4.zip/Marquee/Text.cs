// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using OpenTD;

namespace OpenTDDemos.Marquee
{
    abstract class Text : TextEntity
    {
        public Text(string _value, ThermalDesktop _td, Matrix3d _cs, int _colorIndex,
            double _height = 1.0, Matrix3d _characterTransition = null)
            : base(_td, _cs, _colorIndex, _height)
        {
            Value = _value;
            Cursor = new Matrix3d(CS);
            if (_characterTransition == null)
            {
                CharacterTransition = new Matrix3d();
                CharacterTransition.SetOrigin(new Point3d(0.1 * Height, 0, 0));
            }
            else
                CharacterTransition = new Matrix3d(_characterTransition);
        }

        public string Value { get; private set; }
        public Matrix3d CharacterTransition { get; private set; }

        protected Matrix3d Cursor;

        protected void AdvanceCursor(double characterWidth)
        {
            Matrix3d charTrans = new Matrix3d();
            charTrans.SetOrigin(new Point3d(characterWidth, 0, 0));
            Cursor.PostMultBy(charTrans).PostMultBy(CharacterTransition);
        }
    }
}
