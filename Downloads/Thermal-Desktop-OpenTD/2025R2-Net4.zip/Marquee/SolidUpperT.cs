// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using OpenTD;
using OpenTD.RadCAD.FdSolid;

namespace OpenTDDemos.Marquee
{
    class SolidUpperT : SolidCharacter
    {
        public SolidUpperT(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height)
        {
            DrawUpright();
            DrawUp();
        }

        SolidBrick Upright;
        SolidBrick Up;

        void DrawUpright()
        {
            Upright = TD.CreateSolidBrick();
            Upright.ColorIndex = ColorIndex;
            Upright.XMax = Thickness;
            Upright.ZMax = Thickness;
            Upright.YMax = Height - Thickness;
            Upright.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(0.5 * (Width - Thickness), 0, 0));
            Upright.BaseTrans.PostMultBy(trans);

            Upright.Update();
        }

        void DrawUp()
        {
            Up = TD.CreateSolidBrick();
            Up.ColorIndex = ColorIndex;
            Up.XMax = 0.75 * Height;
            Up.ZMax = Thickness;
            Up.YMax = Thickness;
            Up.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(0, Height - Thickness, 0));
            Up.BaseTrans.PostMultBy(trans);

            Up.Update();
        }

        public override double Width => 0.75 * Height;

        public override void Delete()
        {
            TD.DeleteEntity(Upright);
            TD.DeleteEntity(Up);
        }
    }
}
