// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using OpenTD;
using OpenTD.RadCAD.FdSolid;

namespace OpenTDDemos.Marquee
{
    class SolidUpperM : SolidCharacter
    {
        public SolidUpperM(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height)
        {
            DrawUpright();
            DrawUpright2();
            DrawLeft();
            DrawRight();
        }

        const double angleDeg = 35;
        const double angleRad = angleDeg * Math.PI / 180;

        SolidBrick Upright;
        SolidBrick Upright2;
        SolidBrick Left;
        SolidBrick Right;

        void DrawUpright()
        {
            Upright = TD.CreateSolidBrick();
            Upright.ColorIndex = ColorIndex;
            Upright.XMax = Thickness;
            Upright.ZMax = Thickness;
            Upright.YMax = Height;
            Upright.BaseTrans = new Matrix3d(CS);

            Upright.Update();
        }

        void DrawUpright2()
        {
            Upright2 = TD.CreateSolidBrick();
            Upright2.ColorIndex = ColorIndex;
            Upright2.XMax = Thickness;
            Upright2.ZMax = Thickness;
            Upright2.YMax = Height;
            Upright2.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetOrigin(new Point3d(Thickness + 0.3 * Height, 0, 0));
            Upright2.BaseTrans.PostMultBy(trans);

            Upright2.Update();
        }

        void DrawLeft()
        {
            Left = TD.CreateSolidBrick();
            Left.ColorIndex = ColorIndex;
            Left.XMax = Thickness;
            Left.ZMax = Thickness;
            Left.YMax = 0.5 * Height;
            Left.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetToRotZ(-180 + angleDeg);
            trans.SetOrigin(new Point3d(Thickness, Height, 0));
            Left.BaseTrans.PostMultBy(trans);

            Left.Update();
        }

        void DrawRight()
        {
            Right = TD.CreateSolidBrick();
            Right.ColorIndex = ColorIndex;
            Right.XMax = Thickness;
            Right.ZMax = Thickness;
            Right.YMax = 0.5 * Height;
            Right.BaseTrans = new Matrix3d(CS);
            Matrix3d trans = new Matrix3d();
            trans.SetToRotZ(180 - angleDeg);
            trans.SetOrigin(new Point3d(Thickness + 0.3 * Height + Thickness * Math.Cos(angleRad),
                                       Height - Thickness * Math.Sin(angleRad),
                                       0));
            Right.BaseTrans.PostMultBy(trans);

            Right.Update();
        }

        public override double Width => 2 * Thickness + 0.3 * Height;

        public override void Delete()
        {
            TD.DeleteEntity(Upright);
            TD.DeleteEntity(Upright2);
            TD.DeleteEntity(Left);
            TD.DeleteEntity(Right);
        }
    }
}
