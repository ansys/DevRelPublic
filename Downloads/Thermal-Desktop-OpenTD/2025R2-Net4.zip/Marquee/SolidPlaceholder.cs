// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using OpenTD;
using OpenTD.RadCAD.FdSolid;

namespace OpenTDDemos.Marquee
{
    class SolidPlaceholder : SolidCharacter
    {
        public SolidPlaceholder(ThermalDesktop _td, Matrix3d _cs, int _colorIndex, double _height = 1.0)
            : base(_td, _cs, _colorIndex, _height)
        {
            DrawBox();
        }

        SolidBrick box { get; set; }

        void DrawBox()
        {
            box = TD.CreateSolidBrick();
            box.ColorIndex = ColorIndex;
            box.BaseTrans = new Matrix3d(CS);
            box.XMax = Width;
            box.YMax = Height;
            box.ZMax = Thickness;
            box.Update();
        }

        public override double Width => Height / 1.7;

        public override void Delete()
        {
            TD.DeleteEntity(box);
        }
    }
}
