// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System.Collections.Generic;
using OpenTD;
using OpenTD.RadCAD;

namespace OpenTDDemos.Robot
{
    public class Head : IRobotPart
    {
        public Head(ThermalDesktop tdInstance)
        {
            Units.SaveWorkingUnitsAndSetToSI();
            try
            {
                double diaM = 0.3;

                td = tdInstance;

                head = td.CreateDisk();
                head.MaxRadius = diaM/2;
                head.BaseTrans.SetOrigin(new Point3d(0, diaM / 2, 0)); // align with waist
                head.Update();

                neck = td.CreateAssembly(new Point3d(0, 0, 0));
                neck.AxisSize = 0.1;
                neck.DisplayBaseCS = false;
                neck.AttachedObjectHandles.Add(head.Handle);

                Update();

            }
            finally
            {
                Units.RestoreWorkingUnits();
            }
        }


        public List<string> AttachedObjectHandles
        {
            get
            {
                return neck.AttachedObjectHandles;
            }
        }

        public Matrix3d BaseTrans
        {
            get
            {
                return neck.BaseTrans;
            }
        }

        public string Handle
        {
            get
            {
                return neck.Handle;
            }
        }

        public Transformation LocalTrans
        {
            get
            {
                return neck.LocalTrans;
            }
        }

        public void Update()
        {
            neck.Update();
            head.UpdateFromTD();
        }

        public void UpdateFromTD()
        {
            neck.UpdateFromTD();
            head.UpdateFromTD();
        }

        public double NeckYawDeg
        {
            get
            {
                neck.UpdateFromTD();
                return neck.LocalTrans.Rot2;
            }
            set
            {
                neck.UpdateFromTD();
                neck.LocalTrans.Axis2 = 1; // y-axis
                neck.LocalTrans.Rot2 = value;
                neck.Update();
                td.UpdateGraphics();
            }
        }

        public void Delete()
        {
            td.DeleteEntity(head);
            td.DeleteEntity(neck);
        }

        Disk head { get; set; }
        Assembly neck { get; set; }
        ThermalDesktop td { get; set; }
    }
}
