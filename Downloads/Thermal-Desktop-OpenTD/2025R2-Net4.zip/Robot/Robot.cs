// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using OpenTD;

namespace OpenTDDemos.Robot
{
    public class Robot
    {
        public Robot(ThermalDesktop tdInstance)
        {
            Units.SaveWorkingUnitsAndSetToSI();
            try
            {
                td = tdInstance;

                Torso = new Torso(td);

                Head = new Head(td);
                Head.BaseTrans.SetOrigin
                    (new Point3d(0, Torso.Height, 0));
                Head.Update();

                RightArm = new Arm(td);
                RightArm.BaseTrans.SetOrigin
                    (new Point3d(-Torso.Width / 2 - RightArm.UpperArmWidth / 2, Torso.Height, 0));
                RightArm.Update();

                LeftArm = new Arm(td);
                LeftArm.BaseTrans.SetOrigin
                    (new Point3d(Torso.Width / 2 + LeftArm.UpperArmWidth / 2, Torso.Height, 0));
                LeftArm.Update();

                LowerBody = new LowerBody(td);

                Torso.AttachedObjectHandles.Add(Head.Handle);
                Torso.AttachedObjectHandles.Add(RightArm.Handle);
                Torso.AttachedObjectHandles.Add(LeftArm.Handle);
                Torso.BaseTrans.SetToRotX(90);
                Torso.BaseTrans.SetOrigin(new Point3d(0, 0, LowerBody.PedestalHeight));
                Torso.Update();

                LowerBody.AttachedObjectHandles.Add(Torso.Handle);

                Update();

            }
            finally
            {
                Units.RestoreWorkingUnits();
            }
        }

        public void Update()
        {
            LowerBody.Update();
            Torso.UpdateFromTD();
            Head.UpdateFromTD();
            RightArm.UpdateFromTD();
            LeftArm.UpdateFromTD();
        }

        public void Delete()
        {
            Head.Delete();
            RightArm.Delete();
            LeftArm.Delete();
            Torso.Delete();
            LowerBody.Delete();
            td.UpdateGraphics();
        }

        public Head Head { get; set; }
        public Arm RightArm { get; set; }
        public Arm LeftArm { get; set; }
        public Torso Torso { get; set; }
        public LowerBody LowerBody { get; set; }

        ThermalDesktop td { get; set; }
    }
}
