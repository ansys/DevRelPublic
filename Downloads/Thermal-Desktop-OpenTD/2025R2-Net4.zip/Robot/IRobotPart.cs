// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System.Collections.Generic;
using OpenTD;

namespace OpenTDDemos.Robot
{
    internal interface IRobotPart
    {
        Matrix3d BaseTrans { get; }
        Transformation LocalTrans { get; }
        string Handle { get; }
        List<string> AttachedObjectHandles { get; }
        void Update();
        void UpdateFromTD();
    }
}
