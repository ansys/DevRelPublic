// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System.IO;
using OpenTD;
using OpenTD.Results.Dataset;
using OpenTD.Results.Plot;

namespace OpenTDDemos.ExploringResultsExamples
{
    class ConcatenatedDataSetExample : Example
    {
        public override string Description
        {
            get
            {
                return "A ConcatenatedDataSet is a type of DerivedDataSet. DerivedDataSets act just like DataSets, but " +
                       "instead of getting their data from a save file or CSR, they contain a list of other DataSets and combine " +
                       "that data somehow. In this example, a ConcatenatedDataSet takes a list of two datasets and stitches their " +
                       "data together, one after the other. Each DataSet contains 1 hr of data, but note that the resultant series " +
                       "is 2 hr long.";
            }
        }

        public override string Name { get { return "Stitch together two cases using a ConcatenatedDataset"; } }

        public override void Run()
        {
            string resultsDir = Path.Combine(Script.WorkingDirectory, "exploringResultsSav");
            var tvac1a = DatasetFactory.Load(Path.Combine(resultsDir, "TVAC1A.sav"));
            var tvac1b = DatasetFactory.Load(Path.Combine(resultsDir, "TVAC1B.sav"));
            var tvac = new ConcatenatedDataset();
            tvac.InputDatasets.Add(tvac1a);
            tvac.InputDatasets.Add(tvac1b);
            var TandQ = tvac.GetData("AVIONICS1.T1", "AVIONICS1.Q1");
            var plot = new SimplePlot("AVIONICS1.1 TVAC Results");
            plot.AddSeries(TandQ);
            plot.Show();
        }
    }
}
