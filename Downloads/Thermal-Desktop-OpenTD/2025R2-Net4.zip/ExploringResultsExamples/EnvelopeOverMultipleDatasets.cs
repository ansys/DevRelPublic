// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System.Collections.Generic;
using System.Drawing;
using System.IO;
using OpenTD;
using OpenTD.Results.Dataset;
using OpenTD.Results.Plot;

namespace OpenTDDemos.ExploringResultsExamples
{
    public class EnvelopeOverMultipleDatasets : Example
    {
        public override string Description
        {
            get
            {
                return "Iterates through a list of 3 cases to create a DataArrayCollection containing all the temperature data for one submodel. " +
                       "Then it uses a SelectMaxDataArray and a SelectMinDataArray to find the nodes/cases with the hottest and coldest T's and " +
                       "plots them. SelectMaxDataArray and SelectMinDataArray are types of DerivedDataArray. A DerivedDataArray acts like a " +
                       "DataArray but contains a list of DataArrays which it combines in some way to produce its data. The SelectMaxDataArray " +
                       "just returns the DataArray with the highest value. The SelectMinDataArray does the same for the DataArray with the lowest value.";
            }
        }

        public override string Name { get { return "Plot hottest and coldest AVIONICS2 T's from 3 cases using SelectMax- and SelectMinDataArrays"; } }

        public override void Run()
        {
            string resultsDir = Path.Combine(Script.WorkingDirectory, "exploringResultsSav");

            var datasets = new List<IDataset>
            {
                DatasetFactory.Load(Path.Combine(resultsDir, "hot_beta0.sav")),
                DatasetFactory.Load(Path.Combine(resultsDir, "hot_beta30.sav")),
                DatasetFactory.Load(Path.Combine(resultsDir, "hot_beta60.sav")),
            };
            var allTs = new DataArrayCollection();
            foreach (var dataset in datasets)
            {
                var nodesInSubmodel = new ItemIdentifierCollection(DataTypes.NODE, "AVIONICS2", dataset);
                allTs.AddRange(dataset.GetData(nodesInSubmodel, StandardDataSubtypes.T));
            }
            var max = new SelectMaxDataArray(allTs);
            var min = new SelectMinDataArray(allTs);
            var plot = new SimplePlot("AVIONICS2 Temperature Envelope for all Orbital Cases");
            plot.AddSeries(max);
            plot.AddSeries(min);
            plot.Series[0].Series2dStyle.LineColor = Color.Red;
            plot.Series[1].Series2dStyle.LineColor = Color.Blue;
            plot.Show();
        }
    }
}
