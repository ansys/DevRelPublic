// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System.IO;
using OpenTD;
using OpenTD.Results.Dataset;
using OpenTD.Results.Plot;

namespace OpenTDDemos.ExploringResultsExamples
{
    public class AverageSubmodel : Example
    {
        public override string Description
        {
            get
            {
                return "Uses an AverageDataArray to plot the piecewise average temperature for all nodes in a submodel. " +
                       "An AverageDataArray is a type of DerivedDataArray, which acts like a DataArray but contains a list " +
                       "of DataArrays which it combines in some way to produce its data. An AverageDataArray finds the mean " +
                       "of the data for each record.";
            }
        }

        public override string Name { get { return "Plot average submodel T using AverageDataArray"; } }

        public override void Run()
        {
            string resultsDir = Path.Combine(Script.WorkingDirectory, "exploringResultsSav");
            var beta0 = DatasetFactory.Load(Path.Combine(resultsDir, "hot_beta0.sav"));
            var nodeNames = new ItemIdentifierCollection(DataTypes.NODE, "AVIONICS2", beta0);
            var submodelTs = beta0.GetData(nodeNames, StandardDataSubtypes.T);
            var averageSubmodelT = new AverageDataArray(submodelTs);
            var plot = new SimplePlot();
            plot.AddSeries(averageSubmodelT);
            plot.Show();
        }
    }
}
