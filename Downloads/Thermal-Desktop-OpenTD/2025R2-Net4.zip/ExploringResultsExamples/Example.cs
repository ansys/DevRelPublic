// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

namespace OpenTDDemos.ExploringResultsExamples
{
    public abstract class Example
    {
        public abstract string Name { get; }
        public abstract string Description { get; }
        public abstract void Run();
        public override string ToString()
        {
            return Name;
        }
    }
}
