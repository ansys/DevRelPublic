// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using OpenTD;

namespace OpenTDDemos.Snake
{
    public partial class SnakeDialog : Form
    {
        public SnakeDialog()
        {
            InitializeComponent();
        }

        private void SnakeDialog_Load(object sender, EventArgs e)
        {
            td = new ThermalDesktop();
            td.Connect();
            game = new Game(td);
            game.GameStart += OnGameStart;
            game.PelletEaten += OnPelletEaten;
            game.GameOver += OnGameOver;
            ControlUp += game.Up;
            ControlDown += game.Down;
            ControlLeft += game.Left;
            ControlRight += game.Right;
            StopRequested += game.OnStopRequested;
        }

        ThermalDesktop td { get; set; }
        Game game { get; set; }

        public EventHandler ControlUp;
        public EventHandler ControlDown;
        public EventHandler ControlLeft;
        public EventHandler ControlRight;
        public EventHandler StopRequested;

        void OnGameStart(object sender, EventArgs e)
        {
            WriteStatus("Move with WASD or the buttons below");
        }

        void OnPelletEaten(object sender, PelletsEatenEventArgs e)
        {
            WritePelletsEaten(e.PelletsEaten);
        }

        void OnGameOver(object sender, PelletsEatenEventArgs e)
        {
            WriteStatus("Game Over");
            WritePelletsEaten(e.PelletsEaten);
        }

        delegate void SafeCallDelegateString(string msg);
        void WriteStatus(string msg)
        {
            if (StatusLabel.InvokeRequired)
            {
                var d = new SafeCallDelegateString(WriteStatus);
                StatusLabel.Invoke(d, new object[] { msg });
            }
            else
                StatusLabel.Text = msg;
        }

        delegate void SafeCallDelegateInt(int num);
        void WritePelletsEaten(int num)
        {
            if (PelletsEatenLabel.InvokeRequired)
            {
                var d = new SafeCallDelegateInt(WritePelletsEaten);
                PelletsEatenLabel.Invoke(d, new object[] { num });
            }
            else
                PelletsEatenLabel.Text = num.ToString();
        }

        private void StartButton_Click(object sender, EventArgs e)
        {
            while (game.Running == true)
            {
                StopButton_Click(sender, e);
            }
            game.Reset();
            Task.Factory.StartNew(() =>
            {
                game.Run();
            });
        }

        private void UpButton_Click(object sender, EventArgs e)
        {
            if (ControlUp != null)
            {
                ControlUp(this, new EventArgs());
            }
        }

        private void DownButton_Click(object sender, EventArgs e)
        {
            if (ControlDown != null)
            {
                ControlDown(this, new EventArgs());
            }
        }

        private void LeftButton_Click(object sender, EventArgs e)
        {
            if (ControlLeft != null)
            {
                ControlLeft(this, new EventArgs());
            }
        }

        private void RightButton_Click(object sender, EventArgs e)
        {
            if (ControlDown != null)
            {
                ControlRight(this, new EventArgs());
            }
        }

        private void StopButton_Click(object sender, EventArgs e)
        {
            if (StopRequested != null)
            {
                StopRequested(this, new EventArgs());
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.W)
            {
                UpButton_Click(this, new EventArgs());
                return true;
            }
            else if (keyData == Keys.S)
            {
                DownButton_Click(this, new EventArgs());
                return true;
            }
            else if (keyData == Keys.A)
            {
                LeftButton_Click(this, new EventArgs());
                return true;
            }
            else if (keyData == Keys.D)
            {
                RightButton_Click(this, new EventArgs());
                return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void SnakeDialog_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (td != null)
                try { td.Quit(); } catch { }
        }
    }
}
