// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;

namespace OpenTDDemos.Snake
{
    class PelletsEatenEventArgs : EventArgs
    {
        public PelletsEatenEventArgs(int pelletsEaten)
        {
            PelletsEaten = pelletsEaten;
        }

        public int PelletsEaten { get; set; }
    }
}
