// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using OpenTD;
using OpenTD.Dimension;
using OpenTD.RadCAD;

namespace OpenTDDemos.Snake
{
    class Board
    {
        public Board(ThermalDesktop _td)
        {
            td = _td;

            Units.WorkingUnits.SetToSI();
            Origin = new Point3d(0, 0, 0);
            GridSize = 0.01;
            GridNumU = 15;
            GridNumV = 20;
            ColorIndex = 5; // blue
            ObjectHeightAboveFloor = 0.002;

            Up = new Vector3d(0, 1, 0);
            Right = new Vector3d(1, 0, 0);
        }

        ~Board()
        {
            Delete();
        }
        public void Delete()
        {
            try
            {
                td.DeleteEntity(floor);
            }
            catch { }
        }

        public void Draw()
        {
            floor = td.CreateRectangle();
            floor.BreakdownU.Num = GridNumU;
            floor.BreakdownV.Num = GridNumV;
            floor.ColorIndex = ColorIndex;
            floor.XMax = GridNumU * GridSize;
            floor.YMax = GridNumV * GridSize;
            floor.BaseTrans.SetCoordSystem(Origin, Right, Up, Normal);
            floor.Update();
        }

        public ThermalDesktop td { get; private set; }

        public Point3d Origin { get; set; }
        public Dimensional<ModelLength> GridSize { get; set; }
        public int GridNumU { get; set; }
        public int GridNumV { get; set; }
        public int ColorIndex { get; set; }
        public Dimensional<ModelLength> ObjectHeightAboveFloor { get; set; }

        public Vector3d GetDirection(Directions direction)
        {
            switch (direction)
            {
                case Directions.UP:
                    return Up;
                case Directions.DOWN:
                    return -Up;
                case Directions.LEFT:
                    return -Right;
                case Directions.RIGHT:
                    return Right;
                default:
                    throw new Exception("Unknown direction: '" + direction + "'.");
            }
        }

        public Vector3d Up { get; set; }
        public Vector3d Right { get; set; }
        public Vector3d Normal
        {
            get { return GetDirection(Directions.RIGHT).CrossProduct(GetDirection(Directions.UP)); }
        }

        public bool IsWithinBoard(Position pos)
        {
            if (pos.U < 1 || pos.U > GridNumU)
                return false;
            if (pos.V < 1 || pos.V > GridNumV)
                return false;

            return true;
        }

        public Point3d GetCoordinates(Position pos)
        {
            return Origin
                + (pos.U - 1) * GridSize * Right
                + (pos.V - 1) * GridSize * Up
                + ObjectHeightAboveFloor * Normal;
        }

        public void OnPelletDispensed(object sender, PositionEventArgs e)
        {
            PelletPosition = e.pos;
        }
        public Position PelletPosition { get; set; }

        Rectangle floor { get; set; }
    }
}
