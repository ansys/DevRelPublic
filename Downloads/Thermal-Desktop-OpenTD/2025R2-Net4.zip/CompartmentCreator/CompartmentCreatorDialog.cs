// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using OpenTD;
using OpenTD.FloCAD;

namespace OpenTDDemos.CompartmentCreator
{
    public partial class CompartmentCreatorDialog : Form
    {
        public CompartmentCreatorDialog()
        {
            InitializeComponent();
        }

        ThermalDesktop td = new ThermalDesktop();

        private void openModel_Click(object sender, EventArgs e)
        {

            string dwg = @"Compartment.dwg";
            string dwgPathname = System.IO.Path.Combine(Script.WorkingDirectory, dwg);
            if (!System.IO.File.Exists(dwgPathname))
            {
                MessageBox.Show("Could not find " + dwg + " in directory " + Script.WorkingDirectory);
                return;
            }

            td.ConnectConfig.DwgPathname = dwgPathname;            
            td.Connect();
            textBoxAirTemp.Text = trackBarAirTemp.Value.ToString();
            textBoxWaterTemp.Text = trackBarWaterTemp.Value.ToString();
            textBoxVoidFraction.Text = trackBarVoidFraction.Value.ToString();
            groupBoxSettings.Enabled = true;
            buttonCreateUpdate.Enabled = true;
        }

        private void buttonCreateUpdate_Click(object sender, EventArgs e)
        {
            Units.WorkingUnits.temp = UnitsData.Temp.C;
            Units.WorkingUnits.modelLength = UnitsData.ModelLength.MET;

            // Check for existing compartment and select correct subroutine
            List<Compartment> existingCompartments = td.GetCompartments();
            if (existingCompartments.Count > 0) { UpdateOldCompartment(); }
            else { CreateNewCompartment(); }
        }

        private void CreateNewCompartment()
        {
            Lump watersource = td.CreateLump();
            watersource.Origin = new Point3d(0, -1, -0.5);
            watersource.Comment = "Water source";
            watersource.LumpType = RcLumpData.LumpTypes.PLENUM;
            watersource.InitialTemp = trackBarWaterTemp.Value;
            watersource.Layer = "FloCAD_Parts";
            watersource.Update();

            Lump airlump = td.CreateLump();
            airlump.Origin = new Point3d(0, -1, 0.5);
            airlump.Comment = "Air";
            airlump.LumpType = RcLumpData.LumpTypes.PLENUM;
            airlump.InitialTemp = trackBarAirTemp.Value;
            airlump.UseAl = 1;
            airlump.Al = 1;
            airlump.Layer = "FloCAD_Parts";
            airlump.Update();

            // Air node could be selected by handle, but that can change. This uses the submodel.
            var airnodes = td.GetNodes().Where(x => x.Submodel == "AMBIENT");
            Node airnode = airnodes.First();
            airnode.InitialTemp = trackBarAirTemp.Value;
            airnode.Update();

            // Domains to use in compartment creation
            List<List<Connection>> tankVolumeSolids = new List<List<Connection>>
            {
                new List<Connection> { new Connection("TANK_VOLUME_SOLIDS", -999) }
            };
            List<List<Connection>> tankInnerSurfaces = new List<List<Connection>>
            {
                new List<Connection> {new Connection("INNER_WALLS_SURFACES", -999) }
            };

            Compartment tankCompartment = td.CreateCompartment(tankVolumeSolids, tankInnerSurfaces);

            Lump complump = td.GetLump(tankCompartment.LumpHandle);
            complump.Comment = "Twinned compartment lump";
            complump.UseAl = 1;
            complump.Al = 1.0 - (trackBarVoidFraction.Value / 100.0);
            complump.Hldlmp = true;
            complump.TCode.Flogic2 = ("      if(vol#this/(vol#this+vol#twin) .gt. 0.95) timend = timen");
            complump.Update();

            Port ventport = td.CreatePort(tankCompartment);
            ventport.Origin = new Point3d(0, 0, 0.5);
            ventport.Comment = "Vent Port";
            ventport.Layer = "FloCAD_Parts";
            ventport.Update();

            Port fillport = td.CreatePort(tankCompartment);
            fillport.Origin = new Point3d(0, 0, -.5);
            fillport.Comment = "Air Vent";
            fillport.Layer = "FloCAD_Parts";
            fillport.Update();

            Path fillline = td.CreatePath(watersource, fillport, RcPathData.PathTypes.SETFLOW, false);
            fillline.Comment = "Water fill line";
            fillline.PumpType = RcPathData.PumpTypes.SVFR;
            fillline.VolumeFlowRate = 0.002;
            fillline.Layer = "FloCAD_Parts";
            fillline.Update();

            Path ventline = td.CreatePath(ventport, airlump, RcPathData.PathTypes.ORIFICE, false);
            ventline.Comment = "Air vent";
            ventline.Modo = -1;
            ventline.Moda = -1;
            ventline.PSet = 400000;
            ventline.Aori_h = 0.0004;
            ventline.Aori_t = 1;
            ventline.FlowArea = 0.0005;
            ventline.Layer = "FloCAD_Parts";
            ventline.Update();

            td.UpdateGraphics();
            MessageBox.Show("  Complete!");
        }

        private void UpdateOldCompartment()
        {
            Node airnode = td.GetNodes().Where(x => x.Submodel == "AMBIENT").First();
            airnode.InitialTemp = trackBarAirTemp.Value;
            airnode.Update();

            Lump watersource = td.GetLumps().Where(x => x.Comment == "Water source").First();
            watersource.InitialTemp = trackBarWaterTemp.Value;
            watersource.Update();

            Lump airlump = td.GetLumps().Where(x => x.Comment == "Air").First();
            airlump.InitialTemp = trackBarAirTemp.Value;
            airlump.Update();

            Lump complump = td.GetLumps().Where(x => x.Comment == "Twinned compartment lump").First();
            complump.Al = 1.0 - (trackBarVoidFraction.Value / 100.0);
            complump.Update();

            td.UpdateGraphics();
            MessageBox.Show("Update complete");
        }
        #region Change value of text box when slider moves
        private void trackBarWaterTemp_ValueChanged(object sender, EventArgs e)
        {
            textBoxWaterTemp.Text = trackBarWaterTemp.Value.ToString();
        }

        private void trackBarAirTemp_ValueChanged(object sender, EventArgs e)
        {
            textBoxAirTemp.Text = trackBarAirTemp.Value.ToString();
        }

        private void trackBarVoidFraction_ValueChanged(object sender, EventArgs e)
        {
            textBoxVoidFraction.Text = trackBarVoidFraction.Value.ToString();
        }
        #endregion

        private void CompartmentCreatorDialog_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (td != null)
                try { td.Quit(); } catch { }
        }
    }
}
