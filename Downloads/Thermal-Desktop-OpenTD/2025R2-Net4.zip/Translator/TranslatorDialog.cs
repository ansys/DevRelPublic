// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using OpenTD;

namespace OpenTDDemos
{
    public partial class TranslatorDialog : Form
    {
        public TranslatorDialog()
        {
            InitializeComponent();
            translateButton.Enabled = false;
            td = new ThermalDesktop(Path.Combine(Script.WorkingDirectory, "common.dwg"));
            td.Connect();
            translateButton.Enabled = true;
        }

        private string InputDeck { get { return inputDeckTextBox.Text; } set { inputDeckTextBox.Text = value; } }
        private ThermalDesktop td;

        private void DeleteModel()
        {
            // Delete all nodes and conductors
            foreach (Node n in td.GetNodes())
                td.DeleteEntity(n);
            td.UpdateGraphics();
        }

        private void translateButton_Click(object sender, EventArgs e)
        {
            DeleteModel();

            // Create regex's to match the NODE and COND lines
            Regex node = new Regex(@"NODE\s+(.+)\s+(\d+)\s+\((\d+)\s+(\d+)\s+(\d+)\)\s+(\d+)\s+(\d+)");
            Regex cond = new Regex(@"COND\s+(.+)\s+(\d+)\s+(\d+)\s+(\d+)");

            // Create the nodes
            foreach (Match match in node.Matches(InputDeck))
            {
                // parse the text
                string Submodel = match.Groups[1].Value;
                int Id = int.Parse(match.Groups[2].Value);
                double X = double.Parse(match.Groups[3].Value);
                double Y = double.Parse(match.Groups[4].Value);
                double Z = double.Parse(match.Groups[5].Value);
                double MassVol = double.Parse(match.Groups[6].Value);
                double InitialTemp = double.Parse(match.Groups[7].Value);

                // use OpenTD to create the node
                Node x = td.CreateNode();
                x.Submodel = Submodel;
                x.Id = Id;
                x.Origin = new Point3d(X, Y, Z);
                x.MassVol = MassVol;
                x.InitialTemp = InitialTemp;
                x.Update();
            }

            // Get the nodes from TD. These will have handles/connections that match what's in the TD db
            List<Node> nodes = td.GetNodes();

            // Create the conductors, finding the node handles that match the node id's provided
            foreach (Match match in cond.Matches(InputDeck))
            {
                // parse the text
                string Submodel = match.Groups[1].Value;
                int NodeId1 = int.Parse(match.Groups[2].Value);
                int NodeId2 = int.Parse(match.Groups[3].Value);
                double Value = double.Parse(match.Groups[4].Value);

                // use OpenTD to make the conductor
                Conductor x = td.CreateConductor(nodes.Single(n => n.Submodel == Submodel
                                                 && n.Id == NodeId1),
                                                 nodes.Single(n => n.Submodel == Submodel
                                                 && n.Id == NodeId2));
                x.Submodel = Submodel;
                x.Value = Value;
                x.Update();
            }
            
            // Zoom and center the view
            td.ZoomExtents();
            td.ZoomExtents();
        }

        private void TranslatorDialog_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (td != null)
                try { DeleteModel(); } catch { }
        }
    }
}
