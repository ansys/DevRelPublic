// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Windows.Forms;
using OpenTD;
using OpenTDDemos.ContourFinder;
using OpenTDDemos.SatelliteConfigurator;
using OpenTDDemos.UDFACreator;
using OpenTDDemos.CompartmentCreator;
using OpenTDDemos.QFlowPlotter;
using OpenTDDemos.FeMeshSpiral;

namespace OpenTDDemos
{
    static class OpenTDDemos
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Version v = System.Reflection.Assembly.GetEntryAssembly().GetName().Version;
            string title = string.Format("OpenTD Demos - Version {0}.{1}", v.Major, v.Minor);
            Console.WriteLine("Welcome to " + title);
            Console.WriteLine("Please use the menu dialog to run the demos.");
            Console.WriteLine("Additional information and prompts will be displayed here.");
            Console.WriteLine();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Script.WorkingDirectory = @".\model";

            List<Script> demos = new List<Script>();
            demos.Add(new Translator());
            demos.Add(new Robot.RobotDemo());
            demos.Add(new FEMeshExample.FEMeshExample());
            demos.Add(new FeMeshSpiralDemo());
            demos.Add(new Truss());
            demos.Add(new Marquee.Marquee());
            demos.Add(new Snake.SnakeDemo());
            demos.Add(new CompartmentCreatorDemo());
            demos.Add(new CaptureScreenshots());
            demos.Add(new OrganizeModelWithLinq());
            demos.Add(new ReducedModel());
            demos.Add(new ExploringResultsExamples.ExploringResultsExamples());
            demos.Add(new SatelliteConfiguratorDemo());
            demos.Add(new ContourFinderDemo());
            demos.Add(new QFlowPlotterDemo());
            demos.Add(new UDFACreatorDemo());
            demos.Add(new ControlTd());
            demos.Add(new ControlSindaFluint.ControlSindaFluint());
            demos.Add(new TecGenerator());
            demos.Add(new Comprehensive());

            Application.Run(new MainMenu(demos));
        }
    }
}
