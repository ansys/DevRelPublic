// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using OpenTD;

namespace OpenTDDemos.UDFACreator
{
    public class UDFACreatorDemo : Script
    {
        public override string GetName()
        {
            return "UDFA Creator";
        }
        public override string GetDescription()
        {
            return "Use User-Defined Fortan Arrays (UDFA's) and logic to apply heat to a specified region";
        }

        public override string GetKeywords()
        {
            return "postprocessing post-processing contour results save csr datasets plots";
        }

        public override void Run()
        {
            UDFACreatorDialog d = new UDFACreatorDialog();
            d.ShowDialog();
        }
    }
}