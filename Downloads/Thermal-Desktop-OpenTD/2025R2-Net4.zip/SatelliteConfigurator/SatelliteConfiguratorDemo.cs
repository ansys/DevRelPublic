// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using OpenTD;

namespace OpenTDDemos.SatelliteConfigurator
{
    public class SatelliteConfiguratorDemo : Script
    {
        public override string GetName()
        {
            return "Satellite Configurator";
        }
        public override string GetDescription()
        {
            return "Configure satellite with FD and FE components, adjust orbit, run case, post processing";
        }
        public override string GetKeywords()
        {
            return "finite element difference fd solid surface basetrans localtrans matrix position transform geometry enabled";
        }
        public override void Run()
        {
            SatelliteConfiguratorDialog d = new SatelliteConfiguratorDialog();
            d.ShowDialog();
        }
    }
}