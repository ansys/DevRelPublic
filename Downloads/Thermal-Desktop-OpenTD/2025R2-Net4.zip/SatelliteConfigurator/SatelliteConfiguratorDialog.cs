// ------------------------------------------------------------------------------------------
//  Copyright 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
// ------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using OpenTD;
using OpenTD.RadCAD;
using OpenTD.RadCAD.FdSolid;
using OpenTD.UserInterface;
using OpenTD.Results;
using OpenTD.Results.Dataset;
using OpenTD.Results.Plot;
using OpenTD.RadCAD.FEModel;
using OpenTD.RadCAD.FEM;
using Node = OpenTD.Node;

namespace OpenTDDemos.SatelliteConfigurator
{
    public partial class SatelliteConfiguratorDialog : Form
    {
        public SatelliteConfiguratorDialog()
        {
            InitializeComponent();
        }

        #region Defining variables necessary for wide scope
        ThermalDesktop td = new ThermalDesktop();
        SolidBrick blueBrick { get; set; }
        SolidCone redCone { get; set; }
        SolidCylinder greenCyl { get; set; }
        Contactor greenContactor { get; set; }
        Contactor purpleContactor { get; set; }
        HeatLoad greenHeatload { get; set; }
        HeatLoad purpleHeatload { get; set; }

        // Finite elements use ienumerables instead of individual variables
        // Note this includes all the element types though some are not present in the model
        IEnumerable<LinearBrick> purpleBricks { get; set; }
        IEnumerable<LinearPyramid> purplePyramids { get; set; }
        IEnumerable<LinearTet> purpleTets { get; set; }
        IEnumerable<LinearWedge> purpleWedges { get; set; }
        IEnumerable<LinearTri> purpleTris { get; set; }
        IEnumerable<LinearQuad> purpleQuads { get; set; }
        IEnumerable<Node> purpleNodes { get; set; }
        Assembly orangeAssembly { get; set; }

        Orbit orbitOTD { get; set; }

        // Variable for determining the existing geometry configuration (varies on whether green cylinder is generated)
        int geomConfig { get; set; }

        // Data arrays used for displaying results
        IDataset dataOutput { get; set; }
        MaxDataArray maxRedArray { get; set; }
        MaxDataArray maxBlueArray { get; set; }
        MaxDataArray maxGreenArray { get; set; }
        MaxDataArray maxOrangeArray { get; set; }
        MaxDataArray maxPurpleArray { get; set; }
        MinDataArray minRedArray { get; set; }
        MinDataArray minBlueArray { get; set; }
        MinDataArray minGreenArray { get; set; }
        MinDataArray minOrangeArray { get; set; }
        MinDataArray minPurpleArray { get; set; }

        string saveFilePath;
        #endregion

        /// <summary>
        /// Select and open DWG. Also stores path for save file.
        /// </summary>
        private void openDWG_Click(object sender, EventArgs e)
        {
            resultsBox.Enabled = false;
            setConfigButton.Enabled = false;

            string dwg = @"SatelliteConfigurator.dwg";
            string dwgPathname = Path.Combine(Script.WorkingDirectory, dwg);
            if (!File.Exists(dwgPathname))
            {
                MessageBox.Show("Could not find " + dwg + " in directory " + Script.WorkingDirectory);
                return;
            }

            td.ConnectConfig.DwgPathname = dwgPathname;
            //path name is saved for used with save file in post processing
            saveFilePath = Path.GetDirectoryName(dwgPathname);
            td.Connect();

            InitalizeModelData();

            setConfigButton.Enabled = true;

        }

        /// <summary>
        /// Sets parameters, runs case, loads results
        /// </summary>
        private void runCaseButton_Click(object sender, EventArgs e)
        {
            resultsBox.Enabled = false;
            openDWG.Enabled = false;
            setConfigButton.Enabled = false;
            CaseSet case1 = td.GetCaseSet("OpenTD Case");
            case1.Run();
            resultsBox.Enabled = true;
            openDWG.Enabled = true;
            setConfigButton.Enabled = true;
            LoadMaxMin();
        }

        /// <summary>
        /// Checks valid entry of the forms
        /// </summary>
        private static double ConvertTextToDouble(string input, double defaultVal, string window)
        {
            double m;
            try
            {
                m = Convert.ToDouble(input);
            }
            catch
            {
                MessageBox.Show("Invalid entry for " + window + "Using " + defaultVal);
                m = defaultVal;
            }
            return m;
        }

        /// <summary>
        /// Gets information from the existing model and loads into variables. Called at end of Open File
        /// </summary>
        private void InitalizeModelData()
        {
            #region Initialize FD solids
            // GetSolidBrick with the handle could be used instead, but this method shows how to select if the handle is not known (or may change)
            var allBricks = td.GetSolidBricks();
            string blueHandle = string.Empty;
            foreach (var b in allBricks)
            {
                if (b.StartSubmodel == "BLUE") blueHandle = b.Handle;
            }
            blueBrick = td.GetSolidBrick(blueHandle);

            var allCones = td.GetSolidCones();
            string redHandle = string.Empty;
            foreach (var r in allCones)
            {
                if (r.StartSubmodel == "RED") redHandle = r.Handle;
            }
            redCone = td.GetSolidCone(redHandle);


            var allCylinders = td.GetSolidCylinders();
            string greenHandle = string.Empty;
            foreach (var g in allCylinders)
            {
                if (g.StartSubmodel == "GREEN") greenHandle = g.Handle;
            }
            greenCyl = td.GetSolidCylinder(greenHandle);
            #endregion

            greenContactor = td.GetContactor("612");
            purpleContactor = td.GetContactor("F26");
            greenHeatload = td.GetHeatLoad("616");
            purpleHeatload = td.GetHeatLoad("F2A");
            orangeAssembly = td.GetAssembly("F9B");

            #region Initialize finite elements and nodes
            List<LinearBrick> allLinearBricks = td.GetLinearBricks();
            purpleBricks = allLinearBricks.Where(x => x.CondSubmodel == "PURPLE");

            List<LinearPyramid> allLinearPyramids = td.GetLinearPyramids();
            purplePyramids = allLinearPyramids.Where(x => x.CondSubmodel == "PURPLE");

            List<LinearTet> allLinearTets = td.GetLinearTets();
            purpleTets = allLinearTets.Where(x => x.CondSubmodel == "PURPLE");

            List<LinearWedge> allLinearWedges = td.GetLinearWedges();
            purpleWedges = allLinearWedges.Where(x => x.CondSubmodel == "PURPLE");

            List<LinearTri> allLinearTris = td.GetLinearTris();
            purpleTris = allLinearTris.Where(x => x.CondSubmodel == "PURPLE");

            List<LinearQuad> allLinearQuads = td.GetLinearQuads();
            purpleQuads = allLinearQuads.Where(x => x.CondSubmodel == "PURPLE");

            List<Node> allFemNodes = td.GetNodes();
            purpleNodes = allFemNodes.Where(x => x.Submodel == "PURPLE");
            #endregion

            #region Initialize orbit and values in the windows form
            orbitOTD = td.GetOrbit("orbitOpenTD");
            incTextBox.Text = orbitOTD.OrbitData.Inclination.GetValueSI().ToString();
            raanTextbox.Text = orbitOTD.OrbitData.RaAscending.GetValueSI().ToString();
            aopTextBox.Text = orbitOTD.OrbitData.PeriapArgument.GetValueSI().ToString();
            minAltTextBox.Text = orbitOTD.OrbitData.AltMin.GetValueSI().ToString();
            maxAltTextBox.Text = orbitOTD.OrbitData.AltMax.GetValueSI().ToString();
            #endregion

            #region Determine existing configuration based on whether green cylinder is active
            if (greenCyl.GenerateCondCapExp.Value == "0")
            {
                geomConfig = 1;
                configA.Checked = true;
            }
            else
            {
                geomConfig = 2;
                configB.Checked = true;
            }
            #endregion


            dispersionBox.Enabled = true;
            configurationBox.Enabled = true;
            orbitControls.Enabled = true;
            setConfigButton.Enabled = true;
            runCaseButton.Enabled = true;
        }

        /// <summary>
        /// Enabled or disables purple elements
        /// </summary>
        private void SetPurple(string toggle)
        {
            foreach (LinearBrick lb in purpleBricks)
            {
                lb.GenerateCondCapExp.Value = toggle;
            }
            foreach (LinearPyramid lp in purplePyramids)
            {
                lp.GenerateCondCapExp.Value = toggle;
            }
            foreach (LinearTet lt in purpleTets)
            {
                lt.GenerateCondCapExp.Value = toggle;
            }
            foreach (LinearWedge lw in purpleWedges)
            {
                lw.GenerateCondCapExp.Value = toggle;
            }
            foreach (Node node in purpleNodes)
            {
                node.EnabledExp.Value = toggle;

            }

        }

        /// <summary>
        /// Send update command for each type of Purple element
        /// </summary>
        private void UpdatePurple()
        {
            foreach (LinearBrick lb in purpleBricks)
            {
                lb.Update();
            }
            foreach (LinearPyramid lp in purplePyramids)
            {
                lp.Update();
            }
            foreach (LinearTet lt in purpleTets)
            {
                lt.Update();
            }
            foreach (LinearWedge lw in purpleWedges)
            {
                lw.Update();
            }
            foreach (LinearQuad lq in purpleQuads)
            {
                lq.Update();
            }
            foreach (LinearTri lt in purpleTris)
            {
                lt.Update();
            }
            foreach (Node node in purpleNodes)
            {
                node.Update();
            }
        }

        /// <summary>
        /// Sets the values for the temperature boxes
        /// </summary>
        private void LoadMaxMin()
        {
            try { dataOutput = DatasetFactory.Load(saveFilePath + @"\caseOpenTD.sav"); }
            catch { dataOutput = null; return; }
            var redNodes = new ItemIdentifierCollection(DataTypes.NODE, "RED", dataOutput);
            var blueNodes = new ItemIdentifierCollection(DataTypes.NODE, "BLUE", dataOutput);
            var orangeNodes = new ItemIdentifierCollection(DataTypes.NODE, "ORANGE", dataOutput);
            var redTs = dataOutput.GetData(redNodes, StandardDataSubtypes.T);
            var blueTs = dataOutput.GetData(blueNodes, StandardDataSubtypes.T);
            var orangeTs = dataOutput.GetData(orangeNodes, StandardDataSubtypes.T);
            maxRedArray = new MaxDataArray(redTs);
            maxBlueArray = new MaxDataArray(blueTs);
            maxOrangeArray = new MaxDataArray(orangeTs);
            redMaxBox.Text = Math.Round(maxRedArray.GetValues().Max(), 2).ToString();
            blueMaxBox.Text = Math.Round(maxBlueArray.GetValues().Max(), 2).ToString();
            orangeMaxBox.Text = Math.Round(maxOrangeArray.GetValues().Max(), 2).ToString();
            minRedArray = new MinDataArray(redTs);
            minBlueArray = new MinDataArray(blueTs);
            minOrangeArray = new MinDataArray(orangeTs);
            redMinBox.Text = Math.Round(minRedArray.GetValues().Min(), 2).ToString();
            blueMinBox.Text = Math.Round(minBlueArray.GetValues().Min(), 2).ToString();
            orangeMinBox.Text = Math.Round(minOrangeArray.GetValues().Min(), 2).ToString();

            if (geomConfig == 2)
            {
                var greenNodes = new ItemIdentifierCollection(DataTypes.NODE, "GREEN", dataOutput);
                var greenTs = dataOutput.GetData(greenNodes, StandardDataSubtypes.T);
                maxGreenArray = new MaxDataArray(greenTs);
                minGreenArray = new MinDataArray(greenTs);
                greenMaxBox.Text = Math.Round(maxGreenArray.GetValues().Max(), 2).ToString();
                greenMinBox.Text = Math.Round(minGreenArray.GetValues().Min(), 2).ToString();
                purpleMaxBox.Text = "NA";
                purpleMinBox.Text = "NA";
            }
            else
            {
                var purpleNodes = new ItemIdentifierCollection(DataTypes.NODE, "PURPLE", dataOutput);
                var purpleTs = dataOutput.GetData(purpleNodes, StandardDataSubtypes.T);
                maxPurpleArray = new MaxDataArray(purpleTs);
                minPurpleArray = new MinDataArray(purpleTs);
                purpleMaxBox.Text = Math.Round(maxPurpleArray.GetValues().Max(), 2).ToString();
                purpleMinBox.Text = Math.Round(minPurpleArray.GetValues().Min(), 2).ToString();
                greenMaxBox.Text = "NA";
                greenMinBox.Text = "NA";
            }
        }

        #region Plot controls
        private void PlotBox(DerivedDataArray dda)
        {
            var plot = new SimplePlot();
            plot.AddSeries(dda);
            plot.Show();
        }

        private void redMaxBox_Click(object sender, EventArgs e)
        {
            PlotBox(maxRedArray);
        }

        private void blueMaxBox_Click(object sender, EventArgs e)
        {
            PlotBox(maxBlueArray);
        }

        private void greenMaxBox_Click(object sender, EventArgs e)
        {
            if (geomConfig != 2) return;
            PlotBox(maxGreenArray);
        }

        private void redMinBox_Click(object sender, EventArgs e)
        {
            PlotBox(minRedArray);
        }

        private void blueMinBox_Click(object sender, EventArgs e)
        {
            PlotBox(minBlueArray);
        }

        private void greenMinBox_Click(object sender, EventArgs e)
        {
            if (geomConfig != 2) return;
            PlotBox(minGreenArray);
        }

        private void orangeMaxBox_Click(object sender, EventArgs e)
        {
            PlotBox(maxOrangeArray);
        }

        private void orangeMinBox_Click(object sender, EventArgs e)
        {
            PlotBox(minOrangeArray);
        }

        private void purpleMaxBox_Click(object sender, EventArgs e)
        {
            if (geomConfig != 1) return;
            PlotBox(maxPurpleArray);
        }

        private void purpleMinBox_Click(object sender, EventArgs e)
        {
            if (geomConfig != 1) return;
            PlotBox(minPurpleArray);
        }
        #endregion

        /// <summary>
        /// Applies the control in the form to the TD model
        /// </summary>
        private void setConfigButton_Click(object sender, EventArgs e)
        {

            openDWG.Enabled = false;
            runCaseButton.Enabled = false;

            // Check desired configuration
            if (configA.Checked == true)
            {
                // If the model is not already in the desired configuration, change it
                #region Set to configuration 1(A)
                if (geomConfig != 1)
                {
                    blueBrick.LocalTrans.Rot2 = 0;
                    blueBrick.LocalTrans.Tx = 0;
                    // The blue brick is rotated, so the active sides will change (Add replaces existing)
                    blueBrick.AnalysisGroups.Add(new AnalysisGroupSolidInfo(
                        "Internal", RcFdSolidData.Active.OUTSIDE, new List<int> { 1, 1, 1, 1, 0, 1 }));
                    redCone.LocalTrans.Rot3 = 0;
                    redCone.LocalTrans.Ty = 0;
                    greenCyl.GenerateCondCapExp.Value = "0";
                    greenCyl.AnalysisGroups.RemoveAll(x => x.Name =="Internal");
                    greenContactor.EnabledExp.Value = "0";
                    purpleContactor.EnabledExp.Value = "1";
                    greenHeatload.EnabledExp.Value = "0";
                    purpleHeatload.EnabledExp.Value = "1";

                    geomConfig = 1; // Keep track of what the current configuration is
                    SetPurple("1");

                    // Where the optical property is DEFAULT, purple surfaces should be set to NONE
                    // Where the optical property is other than DEFAULT, purple surfaces should be TOP
                    #region Activate purple FE surfaces for radiation
                    foreach (LinearTri lt in purpleTris)
                    {
                        if (lt.TopOpticalProp != "DEFAULT")
                            lt.AnalysisGroups.Add(new AnalysisGroupSurfaceInfo("External", RcEntityData.Active.TOP));
                        else
                            lt.AnalysisGroups.Add(new AnalysisGroupSurfaceInfo("External", RcEntityData.Active.NONE));
                    }
                    foreach (LinearQuad lq in purpleQuads)
                    {
                        if (lq.TopOpticalProp != "DEFAULT")
                            lq.AnalysisGroups.Add(new AnalysisGroupSurfaceInfo("External", RcEntityData.Active.TOP));
                        else
                            lq.AnalysisGroups.Add(new AnalysisGroupSurfaceInfo("External", RcEntityData.Active.NONE));
                    }
                    #endregion

                    orangeAssembly.LocalTrans.Tx = 0;
                    orangeAssembly.LocalTrans.Ty = 0;

                    Layer greenLayer = td.GetLayerByName("Green");
                    greenLayer.Frozen = true;
                    greenLayer.Update();
                    Layer purpleLayer = td.GetLayerByName("Purple");
                    purpleLayer.Frozen = false;
                    purpleLayer.Update();
                }
                #endregion

            }
            else
            {
                #region Set to Configuration 2(B)
                if (geomConfig != 2)
                {
                    // Move and rotate blue, change active blue faces, move red
                    blueBrick.LocalTrans.Rot2 = -90;
                    blueBrick.LocalTrans.Tx = 1.10;
                    blueBrick.AnalysisGroups.Add(new AnalysisGroupSolidInfo(
                        "Internal", RcFdSolidData.Active.OUTSIDE, new List<int> { 0, 1, 1, 1, 1, 1 }));
                    redCone.LocalTrans.Rot3 = 90;
                    redCone.LocalTrans.Ty = -0.7;

                    // Enable green, add active sides to radiation
                    greenCyl.GenerateCondCapExp.Value = "1";
                    greenCyl.AnalysisGroups.Add(new AnalysisGroupSolidInfo(
                        "Internal", RcFdSolidData.Active.OUTSIDE, new List<int> { 0, 0, 0, 1, 1, 1 }));
                    geomConfig = 2;

                    // Contactor and heat load controls
                    greenContactor.EnabledExp.Value = "1";
                    purpleContactor.EnabledExp.Value = "0";
                    greenHeatload.EnabledExp.Value = "1";
                    purpleHeatload.EnabledExp.Value = "0";

                    // Method used to activate/deactive purple elements
                    SetPurple("0");

                    #region Deactivate purple FE surfaces from radiation
                    foreach (LinearTri lt in purpleTris)
                    {
                        lt.AnalysisGroups.Add(new AnalysisGroupSurfaceInfo("External", RcEntityData.Active.NOTINCONFIG));
                    }
                    foreach (LinearQuad lq in purpleQuads)
                    {
                        lq.AnalysisGroups.Add(new AnalysisGroupSurfaceInfo("External", RcEntityData.Active.NOTINCONFIG));
                    }
                    #endregion

                    // OpenTD cannot directory move a Mesh Controller, but the Mesh Controller is attached to an assembly
                    orangeAssembly.LocalTrans.Tx = -.5;
                    orangeAssembly.LocalTrans.Ty = -.5;

                    Layer greenLayer = td.GetLayerByName("Green");
                    greenLayer.Frozen = false;
                    greenLayer.Update();
                    Layer purpleLayer = td.GetLayerByName("Purple");
                    purpleLayer.Frozen = true;
                    purpleLayer.Update();
                }
                #endregion
            }

            #region Send Update commands
            blueBrick.Update();
            redCone.Update();
            greenCyl.Update();
            greenContactor.Update();
            purpleContactor.Update();
            orangeAssembly.Update();
            UpdatePurple();
            purpleHeatload.Update();
            greenHeatload.Update();
            #endregion

            #region Get symbols
            Symbol qblue = td.GetSymbol("Q_Blue");
            Symbol qred = td.GetSymbol("Q_Red");
            Symbol qgreen = td.GetSymbol("Q_Green");
            Symbol qorange = td.GetSymbol("Q_Orange");
            Symbol qpurple = td.GetSymbol("Q_Purple");
            Symbol solarFluxX = td.GetSymbol("Solar_Flux_Factor");
            #endregion

            #region Adjust symbol values based on Hot or Cold selection
            if (hotCase.Checked == true)
            {
                qblue.Value = "130";
                qred.Value = "100";
                qgreen.Value = "25";
                qorange.Value = "40";
                qpurple.Value = "50";
                solarFluxX.Value = "1.05";
            }
            else
            {
                qblue.Value = "120";
                qred.Value = "90";
                qgreen.Value = "15";
                qorange.Value = "25";
                qpurple.Value = "30";
                solarFluxX.Value = "0.95";
            }
            #endregion

            #region Update objects
            qblue.Update();
            qred.Update();
            qgreen.Update();
            qorange.Update();
            qpurple.Update();
            solarFluxX.Update();
            #endregion

            #region Check values and apply orbit changes to existing orbit
            try
            {
                orbitOTD.OrbitData.Inclination = Double.Parse(incTextBox.Text);
                orbitOTD.OrbitData.RaAscending = Double.Parse(raanTextbox.Text);
                orbitOTD.OrbitData.PeriapArgument = Double.Parse(aopTextBox.Text);
                orbitOTD.OrbitData.AltMin = Double.Parse(minAltTextBox.Text);
                orbitOTD.OrbitData.AltMax = Double.Parse(maxAltTextBox.Text);
            }
            catch
            {
                MessageBox.Show("Orbit parameters must be real numbers.");
                return;
            }

            if (orbitOTD.OrbitData.Inclination < 0 || orbitOTD.OrbitData.Inclination > 180)
            {
                MessageBox.Show("Inclination must be between 0 and 180 degrees");
                return;
            }
            if (orbitOTD.OrbitData.RaAscending < 0 || orbitOTD.OrbitData.RaAscending > 360)
            {
                MessageBox.Show("Right Ascention of the Ascending Node must be between 0 and 360 degrees");
                return;
            }
            if (orbitOTD.OrbitData.PeriapArgument < 0 || orbitOTD.OrbitData.PeriapArgument > 360)
            {
                MessageBox.Show("Argument of Periapsis must be between 0 and 360 degrees");
                return;
            }
            if (orbitOTD.OrbitData.AltMin < 0)
            {
                MessageBox.Show("Minimum altitude must be greater than 0.");
                return;
            }
            if (orbitOTD.OrbitData.AltMax < orbitOTD.OrbitData.AltMin)
            {
                MessageBox.Show("Maximum altitude must be greater than or equal to minimum altitude.");
                return;
            }


            try
            {
                orbitOTD.Update();
            }
            catch
            {
                MessageBox.Show("Invalid orbit.");
                return;
            }
            #endregion 

            td.UpdateGraphics();

            openDWG.Enabled = true;
            runCaseButton.Enabled = true;
        }

        private void SatelliteConfiguratorDialog_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (td != null)
                try { td.Quit(); } catch { }
        }
    }
}
