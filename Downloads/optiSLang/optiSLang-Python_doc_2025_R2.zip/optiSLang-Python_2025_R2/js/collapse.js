function do_for_all(element_name, func) {
    var items = document.getElementsByClassName(element_name);
    for (var i = 0, len = items.length; i < len; i++) {
        func(items[i]);
    }
};


/*
 * Make a function which toggles a specific element
 */
function make_item_toggler(expander_item) {
    return function() {
        var arrow_down = '\u25BC';
        var arrow_up = '\u25B2';

        expander_item.text = expander_item.text === arrow_down
            ? arrow_up
            : arrow_down;

        var area_to_collapse = expander_item.nextElementSibling;
        if (area_to_collapse.style.display == 'none') {
            area_to_collapse.style.display = 'block';
        } else {
            area_to_collapse.style.display = 'none';
        }
    }
};

// Initialize visibility on page load
do_for_all('expander', function(expander_item) {
    expander_item.text = '\u25BC';
});

// Issign a function to toggle to each item
do_for_all('expander', function(expander_item) {
    expander_item.onclick = make_item_toggler(expander_item);
});
