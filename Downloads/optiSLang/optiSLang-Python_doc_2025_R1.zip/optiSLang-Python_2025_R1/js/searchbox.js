var searchbox = document.querySelector(".searchbox");
var input = document.querySelector(".searchbox__input");
var results = document.querySelector(".searchbox__results");


function hide() {
    results.style.display = "none";
}


function show() {
    results.style.display = "block";
}

function clear() {
    while (results.children.length) {
        results.removeChild(results.firstChild);
    }

    hide();
}

function adaptWidth() {
    results.style.width = input.offsetWidth + "px";
}

function fill(tags) {
    for (const tag of tags) {
        var link = document.createElement("a")
        link.classList.add("tag-item");
        link.innerText = tag[0];
        link.href = tag[1];

        var item = document.createElement("li");
        item.appendChild(link);

        results.appendChild(item);
    }
}

function update(ev) {
    clear();

    var text = ev.target.value;

    var hits = tags
        .filter(function(tag) {
            if (!text.length) {
                return true;
            }

            var query = text.split(" ");

            // Each query item must match
            return query.reduce(
                (acc, query_item) => acc & RegExp(query_item, "i").test(tag[0]),
                true);
        });

    fill(hits);

    if (hits.length) {
        show();
    }
}

// 
input.addEventListener("input", update);
input.addEventListener("focus", update);

input.addEventListener("blur", function(ev) {
    if (ev.relatedTarget
        && ev.relatedTarget.matches("a.tag-item")) {
        return
    }

    clear();
});

results.addEventListener("click", function(ev) {
    if (ev.target.matches("a.tag-item")) {
        clear();
    }
});

adaptWidth();
hide();
