function for_all_deprecated(func) {
    var items = document.querySelectorAll('.deprecated');
    for (var i = 0, len = items.length; i < len; i++) {
        func(items[i]);
    }
};

function toggle_deprecated() {
    for_all_deprecated(function(depr_item) {
        if (depr_item.style.display == 'none') {
            depr_item.style.display = 'block';
        } else {
            depr_item.style.display = 'none';
        }
    });
};

/*
 * initialize visibility of deprecated items
 */
for_all_deprecated(function(depr_item) {
    depr_item.style.display = 'none';
});

var deprecated_checkbox = document.getElementById('depr_checkbox');
deprecated_checkbox.checked = false;

deprecated_checkbox.addEventListener('click', toggle_deprecated);
