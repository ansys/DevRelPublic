/*
 * © 2025 ANSYS, Inc. Unauthorized use, distribution, or duplication is prohibited.
 */

#pragma once

#include <string>
#include <vector>

enum class SolutionProfile {
  Linear,
  Quadratic,
  Sinusoidal
};

// Define structure to hold mesh properties.
struct PipeMeshProperties {
  int quadRefine{20};
  int triRefine{30};
  double pipeOffset{0.0};
  double quadPipeRadius{0.05};
  double triPipeRadius{0.05};
  int overlapLayers{0};
  double pipeLength{1.0};
  int myrank{0};
  int numranks{1};
  bool isNodal{true};
  SolutionProfile solutionProfile{SolutionProfile::Linear};
};

PipeMeshProperties& getMeshProperties();

void initializeMesh();

const std::vector<double>& getNodeCoords(const std::string& regionName);

const std::vector<int>& getElemNodeCounts(const std::string& regionName);

const std::vector<int>& getElemNodeIds(const std::string& regionName);

std::vector<double>& getSolutionData(
  const std::string& regionName, const std::string& variableName);
