#!/bin/sh

# Set version-specific environment variables
export ANSYS_INSTALL_DIR="$AWP_ROOT271"
export FLUENT_MULTIPORT_VERSION=27.1.0

# Get value for "--write" command line argument, if provided.
# Get parallel execution arguments, if provided.
NPROCS=1

set -- "$@" "--"

while [ $# -gt 0 ]; do
    case "$1" in
    -np)
        NPROCS=$2
        shift
    ;;
    -hostlist)
        MACHINES=$2
        shift
    ;;
    --)
        shift
        break
    ;;
    *)
        set -- "$@" "$1"
    ;;
    esac
    shift
done

# Set up Intel MPI environment.
export LD_LIBRARY_PATH="${ANSYS_INSTALL_DIR}"/SystemCoupling/runTime/linx64/bin/compiler:"$LD_LIBRARY_PATH"
export LD_LIBRARY_PATH="${ANSYS_INSTALL_DIR}"/SystemCoupling/runTime/linx64/bin:"$LD_LIBRARY_PATH"
export LD_LIBRARY_PATH="${ANSYS_INSTALL_DIR}"/SystemCoupling/runTime/linx64/cnlauncher/fluent/fluent${FLUENT_MULTIPORT_VERSION}/multiport/mpi_wrapper/lnamd64/intel:"$LD_LIBRARY_PATH"

unset -v I_MPI_ONEAPI_ROOT
export I_MPI_ROOT="${ANSYS_INSTALL_DIR}"/SystemCoupling/runTime/linx64/cnlauncher/fluent/fluent${FLUENT_MULTIPORT_VERSION}/multiport/mpi/lnamd64/intel
. "${I_MPI_ROOT}"/env/vars.sh

if [ -z "$MACHINES" ]; then
    # Local parallel
    export SYSC_MPI_CMD="${I_MPI_ROOT}/bin/mpiexec -n ${NPROCS}"
else
    # Distributed parallel
    # Write hosts to Intel MPI-compatible machines file
    INTEL_MPI_MACHINESFILE="intel_mpi_machines.txt"
    if [ -f $INTEL_MPI_MACHINESFILE ]; then
        echo "${INTEL_MPI_MACHINESFILE} exists - removing it"
        rm $INTEL_MPI_MACHINESFILE
    fi
    (IFS=','; for HOST in $MACHINES; do echo "$HOST" >> $INTEL_MPI_MACHINESFILE; done)
    export SYSC_MPI_CMD="${I_MPI_ROOT}/bin/mpiexec -machinefile ${INTEL_MPI_MACHINESFILE}"
fi

# Run the application
$SYSC_MPI_CMD ./PipeMapping "$@"

# Exit.
exit $?
