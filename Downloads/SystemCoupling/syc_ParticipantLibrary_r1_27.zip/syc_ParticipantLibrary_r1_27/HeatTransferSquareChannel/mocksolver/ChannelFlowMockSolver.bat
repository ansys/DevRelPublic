@ECHO OFF
SETLOCAL

REM Set version-specific environment variables
set ANSYS_INSTALL_DIR=%AWP_ROOT271%
set FLUENT_MULTIPORT_VERSION=27.1.0

REM Setup run-time environment
set PATH=%ANSYS_INSTALL_DIR%\SystemCoupling\runTime\winx64\bin\compiler;%PATH%
set PATH=%ANSYS_INSTALL_DIR%\SystemCoupling\runTime\winx64\bin;%PATH%
set PATH=%ANSYS_INSTALL_DIR%\SystemCoupling\runTime\winx64\cnlauncher\fluent\fluent%FLUENT_MULTIPORT_VERSION%\multiport\mpi_wrapper\win64\stub;%PATH%

REM Run the application.
ChannelFlowMockSolver.exe %*
exit /B %errorlevel%
